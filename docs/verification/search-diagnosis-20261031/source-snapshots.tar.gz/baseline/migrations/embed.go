package migrations

import _ "embed"

//go:embed 001_init.sql
var SQL string

//go:embed 002_visibility.sql
var VisibilitySQL string

//go:embed 003_release_repair.sql
var ReleaseSQL string

//go:embed 004_job_radar.sql
var RadarSQL string

//go:embed 005_matching.sql
var MatchingSQL string

//go:embed 006_backend_upgrade.sql
var BackendSQL string

//go:embed 007_local_reliability.sql
var LocalReliabilitySQL string

//go:embed 008_source_import.sql
var SourceImportSQL string

//go:embed 009_holistic_matching.sql
var HolisticSQL string

//go:embed 010_agent_workspace.sql
var AgentWorkspaceSQL string

//go:embed 011_agent_harness.sql
var AgentHarnessSQL string

//go:embed 012_knowledge_retrieval.sql
var KnowledgeRetrievalSQL string

//go:embed 013_assessment_schedule.sql
var AssessmentScheduleSQL string

//go:embed 014_application_journey.sql
var ApplicationJourneySQL string

//go:embed 015_task_scheduling.sql
var TaskSchedulingSQL string

//go:embed 016_model_control.sql
var ModelControlSQL string

//go:embed 017_search.sql
var SearchSQL string

//go:embed 018_job_events.sql
var JobEventsSQL string

//go:embed 019_job_dataset_recovery.sql
var JobDatasetRecoverySQL string

//go:embed 020_search_rebuild.sql
var SearchRebuildSQL string
