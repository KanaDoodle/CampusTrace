import json,os,re,shutil,signal,subprocess,sys,threading,time
from pathlib import Path
from types import SimpleNamespace
root=Path('/Users/kana/Projects/campustrace');sys.path.insert(0,str(root/'scripts/performance'))
from diagnose import Diagnosis
import lab
work=Path(__file__).parent

class HostInterference(Exception):pass

def external_load():
    found=[]
    for line in subprocess.check_output(['ps','-eo','pid=,args='],text=True).splitlines():
        pid,_,args=line.strip().partition(' ')
        if int(pid)==os.getpid():continue
        if re.search(r'(?:^|/)resource-lab(?:\s|$)|(?:^|\s)scripts/verify-(?:resources|network|transports)\.py(?:\s|$)|(?:^|[ /])go\s+(?:test|build)\s|/go-build[^ ]*/[^ ]+\.test(?:\s|$)',args):
            found.append({'pid':int(pid),'command':args})
    return found

class AdaptiveDiagnosis(Diagnosis):
    def __init__(self,args):
        super().__init__(args);self.stop=threading.Event();self.events=[];self.accepted_windows=[]
        self.accepted_instances=[];self.attempts={};self.diag_tag='';self.diag_mark=0;self.diag_pending={}
        self.report['excluded_measurements']=[]
    def seed(self):
        super().seed()
        def watch():
            while not self.stop.wait(1):
                busy=external_load()
                if busy:self.events.append({'time':time.time(),'processes':busy})
        self.thread=threading.Thread(target=watch,daemon=True);self.thread.start()
    def quiet(self):
        since=None;last=0;deadline=time.monotonic()+7200
        while time.monotonic()<deadline:
            busy=external_load();now=time.time()
            if busy:since=None
            elif since is None:since=now
            elif now-since>=60:return
            if now-last>=30:
                print('Waiting for a clean measurement window; frozen data retained',flush=True);last=now
            time.sleep(2)
        raise TimeoutError('No clean host window; no performance pass')
    def interference(self,start):
        return [e for e in self.events if e['time']>=start] or external_load()
    def exclude(self,actual,summary,reason):
        self.report['phases'].pop(actual,None)
        self.report['excluded_measurements'].append({'directory':actual,'reason':reason,'summary':summary})
        self.save()
    def load(self,label,mode,seconds=None):
        if label.startswith('diagnostic-'):
            actual=label+'-'+self.diag_tag
            if self.interference(self.diag_mark):raise HostInterference('during diagnostic warmup')
            summary=super().load(actual,mode,seconds)
            if self.interference(self.diag_mark):
                self.exclude(actual,summary,'external host load during diagnostic')
                raise HostInterference('during diagnostic load')
            self.diag_pending[label]=(actual,summary)
            return summary
        # Only external interference is retryable. Application failures remain
        # in the selected result and fail the strict candidate acceptance gate.
        while True:
            self.quiet();mark=time.time()
            variant=label.split('-')[1]
            self.trace_label=variant
            self.switch(variant,tracing=False);self.mode(mode)
            if self.interference(mark):continue
            attempt=self.attempts.get(label,0)+1;self.attempts[label]=attempt
            actual=f'{label}-attempt{attempt}'
            summary=super().load(actual,mode,seconds)
            if self.interference(mark):
                self.exclude(actual,summary,'external host load during timing')
                continue
            self.report['phases'].pop(actual,None);self.report['phases'][label]=summary
            shutil.copytree(self.evidence/actual,self.evidence/label)
            self.accepted_windows.append({'label':label,'start':mark,'end':time.time(),'source_directory':actual,'observed_interference':False})
            self.save();return summary
    def diagnostics(self,variant):
        attempt=0
        while True:
            self.quiet();attempt+=1;self.diag_tag=f'd{attempt}';self.diag_mark=time.time();self.diag_pending={}
            self.trace_label=variant+'-'+self.diag_tag
            try:
                super().diagnostics(variant)
                if self.interference(self.diag_mark):raise HostInterference('after diagnostic load')
                for canonical,(actual,summary) in self.diag_pending.items():
                    self.report['phases'].pop(actual,None);self.report['phases'][canonical]=summary
                    shutil.copytree(self.evidence/actual,self.evidence/canonical)
                self.accepted_instances.append(self.id+'-'+self.trace_label)
                self.accepted_windows.append({'label':'diagnostic-'+variant,'start':self.diag_mark,'end':time.time(),'observed_interference':False})
                self.save();return
            except HostInterference as error:
                excluded=self.evidence/f'excluded-diagnostic-{variant}-{self.diag_tag}';excluded.mkdir()
                for path in self.evidence.glob(variant+'-*'):
                    if path.is_file():shutil.move(str(path),excluded/path.name)
                for canonical,(actual,summary) in self.diag_pending.items():
                    self.exclude(actual,summary,str(error))
                print('Diagnostic interference retained; waiting to recapture this variant',flush=True)
    def finish(self):
        self.stop.set();self.thread.join(timeout=3)
        self.report['host_load_guard']={'accepted_windows':self.accepted_windows,'observed_external_events':self.events,
            'overlap_during_accepted_measurements':[],
            'scope':'Observed native resource/network/transport verification and build/test processes; no physical CPU exclusivity claim'}
        trace=self.evidence/'traces.jsonl'
        if trace.exists():
            all_trace=self.evidence/'traces-all-attempts.jsonl';trace.rename(all_trace)
            with trace.open('w') as out:
                for line in all_trace.read_text().splitlines(True):
                    if json.loads(line).get('instance') in self.accepted_instances:out.write(line)
        self.save()

lab.LIMITS={**lab.LIMITS,'mysql':(1,'1536m')}
def interrupted(signum,frame):raise KeyboardInterrupt('Adaptive measurement interrupted')
for sig in (signal.SIGTERM,signal.SIGHUP):signal.signal(sig,interrupted)
for jobs in (1000,5000,10000):
    args=SimpleNamespace(jobs=jobs-1,seconds=40,rate=12,write_rate=1,max_vus=16,revision=None,
      source=work/'baseline',candidate=work/'candidate-v2',diagnostics=True,
      output=root/f'bin/verification/search-diagnosis-20261031/accepted-v2-{jobs}')
    experiment=AdaptiveDiagnosis(args)
    try:experiment.execute()
    finally:
        if hasattr(experiment,'thread'):experiment.finish()
    subprocess.run(['python3','scripts/performance/diagnosis_report.py',str(args.output)],cwd=root,check=True)
    print('ACCEPTED_SCALE_COMPLETE',jobs,flush=True)
