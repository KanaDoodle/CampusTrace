import json,os,re,signal,subprocess,sys,threading,time
from pathlib import Path
from types import SimpleNamespace
root=Path('/Users/kana/Projects/campustrace');sys.path.insert(0,str(root/'scripts/performance'))
from diagnose import Diagnosis
import lab
work=Path(__file__).parent

# This experiment-specific host guard does not stop or modify other sessions.
def external_load():
    found=[]
    for line in subprocess.check_output(['ps','-eo','pid=,args='],text=True).splitlines():
        pid,_,args=line.strip().partition(' ')
        if int(pid)==os.getpid():continue
        if re.search(r'(?:^|/)resource-lab(?:\s|$)|(?:^|\s)scripts/verify-(?:resources|network|transports)\.py(?:\s|$)|(?:^|[ /])go\s+(?:test|build)\s|/go-build[^ ]*/[^ ]+\.test(?:\s|$)',args):
            found.append({'pid':int(pid),'command':args})
    return found

class GuardedDiagnosis(Diagnosis):
    def __init__(self,args):
        super().__init__(args);self.guard_stop=threading.Event();self.overlap=[];self.guard_thread=None
    def seed(self):
        super().seed();started=time.time();observed=[];last=0;quiet_since=None
        while True:
            found=external_load();now=time.time()
            if found:quiet_since=None
            elif quiet_since is None:quiet_since=now
            elif now-quiet_since>=60:break
            if now-last>=30:
                observed.append({'time':now,'processes':found});last=now
                print('Waiting for 60 seconds without other host verification loads; no timings yet',flush=True)
            if now-started>7200:raise TimeoutError('Host remained busy; timings not started')
            time.sleep(2)
        self.report['host_load_guard']={'wait_seconds':time.time()-started,'observations':observed,
            'overlap_during_measurement':self.overlap,'scope':'Observed resource/network/transport and Go test/build processes; not physical CPU exclusivity'}
        def watch():
            while not self.guard_stop.wait(1):
                found=external_load()
                if found:self.overlap.append({'time':time.time(),'processes':found})
        self.guard_thread=threading.Thread(target=watch,daemon=True);self.guard_thread.start()
        print('Host guard clear; starting frozen-source measurement',flush=True)
    def load(self,*args,**kwargs):
        if self.overlap or external_load():raise RuntimeError('External workload before measurement')
        result=super().load(*args,**kwargs)
        if self.overlap:raise RuntimeError('External workload overlapped measurement; retained as failed')
        return result
    def close_guard(self):
        self.guard_stop.set()
        if self.guard_thread:self.guard_thread.join(timeout=3)

lab.LIMITS={**lab.LIMITS,'mysql':(1,'1536m')}
def interrupted(signum,frame):raise KeyboardInterrupt('Guarded matrix interrupted')
for sig in (signal.SIGTERM,signal.SIGHUP):signal.signal(sig,interrupted)
for jobs in (1000,5000,10000):
    output=root/(f'bin/verification/search-diagnosis-20261031/final-v2-{jobs}'+('-retry1' if jobs==1000 else ''))
    args=SimpleNamespace(jobs=jobs-1,seconds=40,rate=12,write_rate=1,max_vus=16,revision=None,
        source=work/'baseline',candidate=work/'candidate-v2',diagnostics=True,output=output)
    experiment=GuardedDiagnosis(args)
    try:experiment.execute()
    finally:experiment.close_guard()
    subprocess.run(['python3','scripts/performance/diagnosis_report.py',str(output)],cwd=root,check=True)
    print('FINAL_SCALE_COMPLETE',jobs,flush=True)
