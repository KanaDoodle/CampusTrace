package domain

func IsCampusSource(adapter string) bool {
	switch adapter {
	case "sczq_securities", "nrec", "hec", "transsion", "digitalchina", "beisen_hr", "pylontech", "galaxyspace", "dcits", "intsig", "whalecloud", "starnet", "venustech", "hand", "mediatek", "yealink", "h3c", "yusys", "cksic", "whxmc", "neusoft", "kedacom", "games37", "sangfor", "yonyou", "mthreads", "nexchip":
		return true
	case "xiaohongshu", "baidu", "meituan", "jd", "netease", "alibaba", "bilibili", "kuaishou", "oppo", "siemens", "haier", "lenovo", "midea", "byd", "hikvision", "qihoo360", "sany", "inovance", "vivo", "honor", "sgm", "ctrip", "tencent", "sap", "ths", "cmbnt", "netease_game", "leihuo", "ctyun", "ctcloud", "mihoyo", "pingan_tech", "pingan_oneconnect", "pingan_wallet", "cmcloud", "cmiot", "cmhome", "gbits", "hundsun", "yuewen", "tcl_digital", "tcl_honghu", "cec_software", "cmb_tech", "citic_tech", "boc_software", "boc_operations", "bankcomm_tech", "cms_securities", "htsc_securities", "csc_securities", "guosen_securities", "galaxy_securities", "cicc_securities":
		return true
	default:
		return false
	}
}

func SourceMinimumInterval(adapter string) int {
	if IsCampusSource(adapter) {
		return 1800
	}
	return 300
}

// WatchInterval is deliberately bounded and deterministic. Priority never
// bypasses a source's minimum interval or the failure cooldown.
func WatchInterval(w WatchTarget, minimum int, urgent bool) (int, string) {
	base := max(minimum, w.CheckInterval)
	ceiling := min(604800, base*8)
	if !w.Adaptive {
		return base, "FIXED"
	}
	if w.FailureRounds > 0 {
		return min(ceiling, base<<min(w.FailureRounds, 3)), "FAILURE_BACKOFF"
	}
	if w.Priority || urgent {
		return max(minimum, base/2), "PRIORITY"
	}
	if w.RoundChanged {
		return max(minimum, base/2), "RECENT_CHANGE"
	}
	if w.StableRounds >= 3 {
		return min(ceiling, base<<min(w.StableRounds/3, 3)), "UNCHANGED_BACKOFF"
	}
	return base, "BASE"
}

func (w *WatchTarget) RecordWatchRound(success bool) {
	if !success {
		w.FailureRounds = min(3, w.FailureRounds+1)
		w.StableRounds = 0
		return
	}
	w.FailureRounds = 0
	if w.RoundChanged {
		w.StableRounds = 0
	} else {
		w.StableRounds = min(9, w.StableRounds+1)
	}
}
