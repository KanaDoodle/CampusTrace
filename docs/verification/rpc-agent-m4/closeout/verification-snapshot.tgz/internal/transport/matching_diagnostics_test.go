package transport

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"log/slog"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"

	"github.com/KanaDoodle/CampusTrace/internal/analysis"
	"github.com/KanaDoodle/CampusTrace/internal/matching"
	"github.com/KanaDoodle/CampusTrace/internal/modelconfig"
	p "github.com/KanaDoodle/CampusTrace/internal/persistence"
)

func TestMatchingDiagnosticsExplainStageWithoutLoggingSensitiveErrors(t *testing.T) {
	var logs bytes.Buffer
	previous := slog.Default()
	slog.SetDefault(slog.New(slog.NewJSONHandler(&logs, nil)))
	t.Cleanup(func() { slog.SetDefault(previous) })
	for _, tc := range []struct {
		err         error
		stage, code string
		provider    int
	}{
		{&analysis.HTTPError{Status: 502}, "EXTRACT", "MODEL_PROVIDER_FAILED", 502},
		{&url.Error{Op: "Post", URL: "https://provider.invalid/?api_key=synthetic-secret", Err: errors.New("private candidate text")}, "EXTRACT", "MODEL_CONNECTION_FAILED", 0},
		{&url.Error{Op: "Post", URL: "https://provider.invalid/", Err: context.DeadlineExceeded}, "EXTRACT", "MODEL_TIMEOUT", 0},
		{&analysis.ResponseError{Reason: "INVALID_JSON"}, "EXTRACT", "MODEL_RESPONSE_INVALID", 0},
		{modelconfig.ErrInvalid, "EXTRACT", "MODEL_ENDPOINT_BLOCKED", 0},
		{matching.ErrInvalid, "COMPARE", "MATCH_OUTPUT_INVALID", 0},
	} {
		w := httptest.NewRecorder()
		w.Header().Set("X-Request-ID", "aabbccddeeff00112233445566778899")
		matchFailure(w, tc.err, tc.stage)
		var out struct {
			Code       string `json:"code"`
			Request    string `json:"request_id"`
			Diagnostic struct {
				Stage  string `json:"stage"`
				Status int    `json:"provider_status"`
			} `json:"diagnostic"`
		}
		if err := json.Unmarshal(w.Body.Bytes(), &out); err != nil {
			t.Fatal(err)
		}
		if w.Code != 502 || out.Code != tc.code || out.Diagnostic.Stage != tc.stage || out.Diagnostic.Status != tc.provider || out.Request == "" {
			t.Fatal(w.Body.String())
		}
		if strings.Contains(w.Body.String(), "synthetic-secret") || strings.Contains(w.Body.String(), "private candidate") {
			t.Fatal("sensitive provider error returned")
		}
	}
	if strings.Contains(logs.String(), "synthetic-secret") || strings.Contains(logs.String(), "private candidate") {
		t.Fatal("sensitive error logged")
	}
	if !strings.Contains(logs.String(), `"stage":"EXTRACT"`) {
		t.Fatal("missing failure stage")
	}
}

func TestMatchingValidationDiagnosticKeepsOnlyReasonAndNumericPositions(t *testing.T) {
	var logs bytes.Buffer
	previous := slog.Default()
	slog.SetDefault(slog.New(slog.NewJSONHandler(&logs, nil)))
	t.Cleanup(func() { slog.SetDefault(previous) })
	err := &matching.ValidationError{Reason: "MATCH_COUNT", JobIndex: 1, ItemIndex: 2, Expected: 15, Actual: 9}
	w := httptest.NewRecorder()
	matchFailure(w, err, "COMPARE")
	var out struct {
		Code       string `json:"code"`
		Diagnostic struct {
			Reason   string `json:"validation_reason"`
			Job      int    `json:"job_index"`
			Item     int    `json:"item_index"`
			Expected int    `json:"expected"`
			Actual   int    `json:"actual"`
		} `json:"diagnostic"`
	}
	if json.Unmarshal(w.Body.Bytes(), &out) != nil || w.Code != 502 || out.Code != "MATCH_OUTPUT_INVALID" || out.Diagnostic.Reason != "MATCH_COUNT" || out.Diagnostic.Job != 1 || out.Diagnostic.Item != 2 || out.Diagnostic.Expected != 15 || out.Diagnostic.Actual != 9 {
		t.Fatal(w.Body.String())
	}
	if !strings.Contains(logs.String(), "MATCH_COUNT") {
		t.Fatal("missing safe validation reason")
	}
}

func TestUnavailableMatchingJobPreservesCompatibilityError(t *testing.T) {
	w := httptest.NewRecorder()
	matchFailure(w, p.ErrMatchJobUnavailable)
	var out map[string]any
	if err := json.Unmarshal(w.Body.Bytes(), &out); err != nil {
		t.Fatal(err)
	}
	if w.Code != 409 || out["code"] != "MATCH_JOB_UNAVAILABLE" {
		t.Fatal(w.Code, w.Body.String())
	}
}

func TestChatImportDuplicateDiagnosticIncludesBothNumericPositions(t *testing.T) {
	var logs bytes.Buffer
	previous := slog.Default()
	slog.SetDefault(slog.New(slog.NewJSONHandler(&logs, nil)))
	t.Cleanup(func() { slog.SetDefault(previous) })
	w := httptest.NewRecorder()
	w.Header().Set("X-Request-ID", "synthetic-request")
	chatImportFailure(w, &matching.ValidationError{Reason: "CHAT_REQUIREMENT_CONTENT_DUPLICATE", ItemIndex: 2, RelatedItemIndex: 1}, 4)
	var out struct {
		Code       string `json:"code"`
		Diagnostic struct {
			Reason  string `json:"validation_reason"`
			Job     int    `json:"job_index"`
			Item    int    `json:"item_index"`
			Related int    `json:"related_item_index"`
		} `json:"diagnostic"`
	}
	if err := json.Unmarshal(w.Body.Bytes(), &out); err != nil || w.Code != 400 || out.Code != "MATCH_CHAT_INVALID" || out.Diagnostic.Reason != "CHAT_REQUIREMENT_CONTENT_DUPLICATE" || out.Diagnostic.Job != 4 || out.Diagnostic.Item != 2 || out.Diagnostic.Related != 1 {
		t.Fatal(w.Code, w.Body.String(), err)
	}
	if !strings.Contains(logs.String(), "synthetic-request") || !strings.Contains(logs.String(), "CHAT_REQUIREMENT_CONTENT_DUPLICATE") {
		t.Fatal("cannot correlate the safe diagnostic with its request", logs.String())
	}
}

func TestMatchingCapacityDiagnosticsExplainProfileVersusComparison(t *testing.T) {
	for _, reason := range []string{"CANDIDATE_BYTES", "CANDIDATE_FACTS", "COMPARISON_BYTES"} {
		err := &matching.CapacityError{Reason: reason, Actual: 33000, Limit: 32000}
		w := httptest.NewRecorder()
		matchFailure(w, err)
		var out struct {
			Code       string         `json:"code"`
			Diagnostic map[string]any `json:"diagnostic"`
		}
		if json.Unmarshal(w.Body.Bytes(), &out) != nil || w.Code != 400 || out.Code != "MATCH_CAPACITY" || out.Diagnostic["capacity_reason"] != reason || out.Diagnostic["actual"] != float64(33000) || out.Diagnostic["limit"] != float64(32000) {
			t.Fatal("capacity origin was hidden", w.Body.String())
		}
		code, task := matchTaskFailure(err, "COMPARE")
		if code != "MATCH_CAPACITY" || task["capacity_reason"] != reason || task["actual"] != 33000 || task["limit"] != 32000 {
			t.Fatal("background task lost input capacity diagnostics", task)
		}
	}
}

func TestWholeQuoteDiagnosticsSurviveHTTPTasksAndChat(t *testing.T) {
	err := &matching.ValidationError{Reason: "HOLISTIC_EVIDENCE_EXCERPT_NOT_EXACT", Scope: "HOLISTIC_STRENGTH", JobIndex: 3, ItemIndex: 2, CitationIndex: 1}
	for _, chat := range []bool{false, true} {
		w := httptest.NewRecorder()
		if chat {
			chatImportFailure(w, err, 3)
		} else {
			matchFailure(w, err, "ANALYZE")
		}
		var out struct {
			Diagnostic map[string]any `json:"diagnostic"`
		}
		if json.Unmarshal(w.Body.Bytes(), &out) != nil || out.Diagnostic["job_index"] != float64(3) || out.Diagnostic["item_index"] != float64(2) || out.Diagnostic["item_scope"] != "HOLISTIC_STRENGTH" || out.Diagnostic["citation_index"] != float64(1) {
			t.Fatal("lost quote location", w.Body.String())
		}
	}
	code, diag := matchTaskFailure(err, "ANALYZE")
	if code != "MATCH_OUTPUT_INVALID" || diag["item_scope"] != "HOLISTIC_STRENGTH" || diag["citation_index"] != 1 {
		t.Fatal("persisted task diagnostic lost quote location", diag)
	}
	unsafe := &matching.ValidationError{Reason: "FACT_UNKNOWN", Scope: "private-candidate-text", CitationIndex: 99}
	_, diag = matchTaskFailure(unsafe, "ANALYZE")
	wire, marshalErr := json.Marshal(diag)
	if marshalErr != nil || diag["item_scope"] != nil || diag["citation_index"] != nil || strings.Contains(string(wire), "private-candidate-text") {
		t.Fatal("diagnostic emitted an unrecognized scope", diag)
	}
}

func TestWholeQuotePositionMapsThroughCacheAndSnapshotOrdering(t *testing.T) {
	err := &matching.ValidationError{Reason: "HOLISTIC_JOB_EXCERPT_NOT_EXACT", JobIndex: 1, Scope: "HOLISTIC_GAP", ItemIndex: 2}
	mapped := matchValidationPosition(err, []matching.HolisticJob{{ID: "bad"}, {ID: "other"}}, []string{"cached", "other", "bad"})
	var v *matching.ValidationError
	if !errors.As(mapped, &v) || v.JobIndex != 3 || v.ItemIndex != 2 || v.Scope != "HOLISTIC_GAP" || err.JobIndex != 1 {
		t.Fatal("snapshot or cache changed diagnostic position", mapped)
	}
}
