package inferencebridge

import (
	"errors"
	"os"
	"time"

	"github.com/KanaDoodle/CampusTrace/internal/agent"
)

type Config struct {
	Address, Model, EvidenceKind string
	ScopeKey                     []byte
	Timeout                      time.Duration
}
type Client interface {
	agent.NarrationClient
	Close()
}

func FromEnvironment(scopeKey []byte) (Client, error) {
	address, model := os.Getenv("INFERENCE_RPC_ADDRESS"), os.Getenv("INFERENCE_MODEL")
	if address == "" && model == "" {
		return nil, nil
	}
	if address == "" || model == "" || len(scopeKey) < 32 {
		return nil, errors.New("incomplete inference RPC configuration")
	}
	return New(Config{Address: address, Model: model, ScopeKey: scopeKey, Timeout: 35 * time.Second, EvidenceKind: os.Getenv("INFERENCE_BACKEND_KIND")})
}
