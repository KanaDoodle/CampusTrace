package inferencebridge

import "testing"

func TestOptionalConfigurationDoesNotSilentlyEnableAnotherProvider(t *testing.T) {
	t.Setenv("INFERENCE_RPC_ADDRESS", "")
	t.Setenv("INFERENCE_MODEL", "")
	client, err := FromEnvironment(nil)
	if client != nil || err != nil {
		t.Fatalf("unconfigured service must stay disabled: %v %v", client, err)
	}
	t.Setenv("INFERENCE_RPC_ADDRESS", "127.0.0.1:1")
	if _, err = FromEnvironment([]byte("synthetic-scope-secret-long-enough")); err == nil {
		t.Fatal("partial configuration silently accepted")
	}
	t.Setenv("INFERENCE_MODEL", "synthetic-model")
	if _, err = FromEnvironment([]byte("short")); err == nil {
		t.Fatal("weak tenant scope key accepted")
	}
}
