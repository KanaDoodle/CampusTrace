package source

import (
	"context"
	"net/url"
	"strings"
)

const BaiduCampusURL = "https://talent.baidu.com/jobs/list?recruitType=GRADUATE"
const MeituanCampusURL = "https://zhaopin.meituan.com/web/campus?hiringType=1_1"
const JDCampusURL = "https://campus.jd.com/#/jobs?type=present"
const NeteaseCampusURL = "https://campus.163.com/app/job/position?id=103"
const AlibabaCampusURL = "https://campus-talent.alibaba.com/campus/position?batchId=100000760001"
const BilibiliCampusURL = "https://jobs.bilibili.com/campus/positions?type=3"
const SiemensCampusURL = "https://jobs.siemens.com.cn/siemens/position/index?recruitmentType=CAMPUSRECRUITMENT"
const HaierCampusURL = "https://maker.haier.net/client/campusmobile/activity/id/68/fid.html"
const OPPOCampusURL = "https://careers.oppo.com/university/oppo/campus/post?recruitType=Graduate"
const SGMCampusURL = "https://sgm.zhiye.com/campusjobs"
const CtripCampusURL = "https://careers.ctrip.com/campus/jobList"
const KuaishouCampusURL = "https://campus.kuaishou.cn/recruit/campus/e/#/campus/jobs?recruitSubProjectCodes=20271779425607"

// Presets describe implemented scopes, not promises about current availability.
type CampusSite struct {
	Adapter           string `json:"adapter"`
	Company           string `json:"company"`
	URL               string `json:"url"`
	Scope             string `json:"scope"`
	MinimumInterval   int    `json:"minimum_interval"`
	SupportsDirection bool   `json:"supports_direction"`
}

func CampusSites() []CampusSite {
	return []CampusSite{
		{"xiaohongshu", "小红书", XHSURL, "当前常规应届校招项目", 1800, true},
		{"tencent", "腾讯", TencentCampusURL, "2027 常规应届校招 · 官网中国工作地点分类（不含实习、青云等人才专项及海外 Workday 岗）", 1800, false},
		{"baidu", "百度", BaiduCampusURL, "应届生校招（含 AIDU、管培生项目）", 1800, false},
		{"meituan", "美团", MeituanCampusURL, "应届生校招", 1800, false},
		{"jd", "京东", JDCampusURL, "应届生项目（JDS、TET、新锐之星）", 1800, false},
		{"netease", "网易互联网", NeteaseCampusURL, "2027 届校园招聘（不含互娱、雷火）", 1800, false},
		{"alibaba", "阿里巴巴", AlibabaCampusURL, "2027 届应届生（官网当前公开业务集团）", 1800, false},
		{"bilibili", "哔哩哔哩", BilibiliCampusURL, "官网公开应届生岗位（不含实习）", 1800, false},
		{"sap", "SAP", SAPCampusURL, "中国 Graduate 职业阶段（不含 Student、Professional；具体届别与经验要求见原文）", 1800, false},
		{"siemens", "西门子", SiemensCampusURL, "中国官网校招分类（不含实习、社招）", 1800, false},
		{"haier", "海尔集团", HaierCampusURL, "2027 校园招聘项目", 1800, false},
		{"oppo", "OPPO", OPPOCampusURL, "2027 届应届生（不含实习、博士专项）", 1800, false},
		{"kuaishou", "快手", KuaishouCampusURL, "2027 届应届生（不含留用、日常实习）", 1800, false},
		{"qihoo360", "360集团", "https://360campus.zhiye.com/campus/jobs", "官网校招分类（具体毕业年份见岗位原文）", 1800, false},
		{"sany", "三一集团", "https://sanycampus.zhiye.com/campus/jobs", "官网校招分类（不含社招、实习）", 1800, false},
		{"inovance", "汇川技术", "https://inovance.zhiye.com/campus/jobs", "官网校招分类（当前可能暂未开放岗位）", 1800, false},
		{"vivo", "vivo", "https://hr-campus.vivo.com/campus/jobs", "官网校招分类（不含社招、实习）", 1800, false},
		{"sgm", "上汽通用/泛亚", SGMCampusURL, "官网校招分类（当前含 2027 届秋招项目；具体届别以岗位原文为准）", 1800, false},
		{"honor", "荣耀", HonorCampusURL, "2027 届应届本硕（不含博士专项、实习）", 1800, false},
		{"lenovo", "联想", LenovoCampusURL, "官网应届生招聘（不含人才专项、实习）", 1800, false},
		{"midea", "美的集团", MideaCampusURL, "2027 届美的星校招（不含博士专项、实习）", 1800, false},
		{"byd", "比亚迪", BYDCampusURL, "2027 应届生（不含实习、外派专项）", 1800, false},
		{"hikvision", "海康威视", HikvisionCampusURL, "2027 常规校园招聘（不含智先锋、实习）", 1800, false},
		{"ths", "同花顺", THSCampusURL, "2027 届校园招聘（含实习转正，用工形式以原文为准）", 1800, false},
		{"bankcomm_tech", "交通银行 · 总行金融科技", BankcommCampusURL, "官网总行 2026 年秋季校招（金科类）项目；官网入口需筛选总行，具体毕业范围及签约单位见原文", 1800, false},
		{"cms_securities", "招商证券", hotjobCampusURL("cms_securities"), "2027 校园招聘固定项目（含实习考察要求，见原文）", 1800, false},
		{"htsc_securities", "华泰证券 · 总部", hotjobCampusURL("htsc_securities"), "官网 2026 年秋招（总部）固定项目，2027 毕业范围以岗位原文为准（不混入分公司、专项与实习项目）", 1800, false},
		{"csc_securities", "中信建投证券", "https://csc108.zhiye.com/campus/jobs", "官网校招分类（含实习考察；具体毕业范围、用工形式见原文）", 1800, false},
		{"guosen_securities", "国信证券", "https://guosen.zhiye.com/campus/jobs", "官网校招分类（不同届别及经验要求以原文为准）", 1800, false},
		{"galaxy_securities", "中国银河证券", "https://chinastock.zhiye.com/custom/campus", "官网校招分类（具体毕业范围、招聘单位及实习考察见原文）", 1800, false},
		{"cicc_securities", "中金公司", "https://cicc.zhiye.com/campus/jobs", "官网校招分类（包含公开单位及地区，毕业与用工要求以原文为准）", 1800, false},
		{"cmb_tech", "招商银行 · 科技与研发", CMBCampusURL, "官网应届生分类 · 按岗位名称筛选信息技术、研发、金融科技等方向（含培养生和集团单位；轮岗、届别见原文）", 1800, false},
		{"citic_tech", "中信银行 · 信息科技", CITICCampusURL, "官网校园招聘 · 岗位名称含信息科技的岗位（具体届别与培养方式见原文）", 1800, false},
		{"boc_software", "中国银行 · 软件中心", bocCampusURL("boc_software"), "2027 校招 · 软件中心七个城市单位（官网链接打开集团目录，按单位查看；资格附件需另行核对）", 1800, false},
		{"boc_operations", "中国银行 · 信息科技运营中心", bocCampusURL("boc_operations"), "2027 校招 · 信息科技运营中心四个城市单位（官网链接打开集团目录，按单位查看；资格附件需另行核对）", 1800, false},
		{"cmbnt", "招银网络科技", CMBNTCampusURL, "官网应届毕业生分类（不含社招、实习；具体届别见原文）", 1800, false},
		{"netease_game", "网易游戏互娱", NeteaseGameCampusURL, "网易互娱 2027 届校园招聘（独立于网易互联网、雷火）", 1800, false},
		{"leihuo", "网易游戏雷火", LeihuoCampusURL, "雷火 2027 届应届生（不含研究型、转正或日常实习）", 1800, false},
		{"ctyun", "天翼云科技有限公司", ctCampusURL("ctyun"), "2027 年度秋季校招 · 天翼云单位（不含集团其他单位）", 1800, false},
		{"ctcloud", "中国电信云计算研究院", ctCampusURL("ctcloud"), "2027 年度秋季校招 · 云计算研究院（含博士岗位）", 1800, false},
		{"mihoyo", "米哈游", MihoyoCampusURL, "2027 届秋招应届生项目（不含实习）", 1800, false},
		{"pingan_tech", "平安科技", pinganCampusURL("pingan_tech"), "官网应届生分类 · 平安科技（具体届别见原文）", 1800, false},
		{"pingan_oneconnect", "金融壹账通", pinganCampusURL("pingan_oneconnect"), "官网应届生分类 · 金融壹账通（具体届别见原文）", 1800, false},
		{"pingan_wallet", "平安壹钱包", pinganCampusURL("pingan_wallet"), "官网应届生分类 · 平安壹钱包（具体届别见原文）", 1800, false},
		{"cmcloud", "中国移动云公司", mobileCampusURL("cmcloud"), "官网校园招聘 · 云公司（具体届别见原文）", 1800, false},
		{"cmiot", "中国移动物联网公司", mobileCampusURL("cmiot"), "官网校园招聘 · 物联网公司（含博士岗位，届别见原文）", 1800, false},
		{"cmhome", "中国移动智慧家庭运营中心", mobileCampusURL("cmhome"), "官网校园招聘 · 智慧家庭运营中心（含博士岗位，届别见原文）", 1800, false},
		{"hundsun", "恒生电子", "https://campus.hundsun.com/campus/jobs", "官网校招分类（具体毕业年份见岗位原文）", 1800, false},
		{"yuewen", "阅文集团", "https://yuewen.zhiye.com/campus/jobs", "官网应届生校招分类（不含实习、社招）", 1800, false},
		{"mthreads", "摩尔线程", "https://mthreads.zhiye.com/", "官网校招分类（AI、软件、芯片等方向，具体届别见原文）", 1800, false},
		{"h3c", "新华三集团", "https://career.h3c.com/campus/jobs", "官网校招分类（含专项和海外地点，具体届别、工作地点见原文）", 1800, false},
		{"yusys", "宇信科技", "https://yusys-campus.zhiye.com/", "官网校招分类（含高潜人才项目，具体届别见原文）", 1800, false},
		{"cksic", "中科芯", "https://cksic.zhiye.com/campus/jobs", "官网校招分类（软件、AI 与芯片方向，具体届别见原文）", 1800, false},
		{"whxmc", "新芯股份", "https://whxmc.zhiye.com/campus/jobs", "官网校招分类（软件、信息安全与制造研发，具体届别见原文）", 1800, false},
		{"venustech", "启明星辰", "https://venustech2.zhiye.com/campus/jobs", "官网校招分类（软件研发、AI 与信息安全等方向，具体届别见原文）", 1800, false},
		{"hand", "汉得信息", "https://hand-china.zhiye.com/campus/jobs", "官网校招分类（软件研发与数字化咨询等方向，具体届别见原文）", 1800, false},
		{"mediatek", "联发科技", "https://mediatek.zhiye.com/campus/jobs", "官网校招分类（软件、算法与芯片研发等方向，具体届别见原文）", 1800, false},
		{"yealink", "亿联网络", "https://yealink.zhiye.com/campus/jobs", "官网校招分类（软件、Agent、音视频与通信研发等方向，具体届别见原文）", 1800, false},
		{"dcits", "神州信息", "https://dcits.zhiye.com/campus/jobs", "官网校招分类（金融科技、后端与 AI Agent 等方向，具体届别见原文）", 1800, false},
		{"intsig", "合合信息", "https://intsig.zhiye.com/campus/jobs", "官网校招分类（后端、AI 全栈、RAG 与 Agent 等方向，具体届别见原文）", 1800, false},
		{"whalecloud", "浩鲸科技", "https://iwhalecloud1.zhiye.com/campus/jobs", "官网校招分类（后端、通信、AI 与嵌入式等方向，部分岗位接受 2026 届，见原文）", 1800, false},
		{"starnet", "星网锐捷", "https://starnet.zhiye.com/campus/jobs", "官网校招分类（软件、AI 与通信研发等方向，具体届别及招聘单位见原文）", 1800, false},
		{"digitalchina", "神州数码", "https://digitalchina.zhiye.com/campus/jobs", "官网校招分类（Agent、AI 应用与企业软件等方向，含提前实习要求；具体届别见原文）", 1800, false},
		{"beisen_hr", "北森", "https://beisen.zhiye.com/campus/jobs", "官网校招分类（后端、AI 算法与企业软件等方向，含校招实习及不同届别，工作性质见原文）", 1800, false},
		{"pylontech", "派能科技", "https://pylontech1.zhiye.com/campus/jobs", "官网校招分类（软件、算法与储能研发等方向，具体届别见原文）", 1800, false},
		{"galaxyspace", "银河航天", "https://galaxy.zhiye.com/campus/jobs", "官网校招分类（工业软件、AI 与卫星通信研发等方向，具体届别见原文）", 1800, false},
		{"nrec", "南瑞继保", "https://nrec.zhiye.com/campus/jobs", "官网校招分类（研发设计、信息技术与电力设备等方向，具体届别及单位见原文）", 1800, false},
		{"hec", "东阳光", "https://hec.zhiye.com/campus/jobs", "官网校招分类（软件、机器人与制造研发等方向，具体届别及招聘单位见原文）", 1800, false},
		{"transsion", "传音控股", "https://transsion.zhiye.com/campus/jobs", "官网校招分类（AI 全栈、Agent、软件开发与制造等方向，含海外地点，具体届别见原文）", 1800, false},
		{"sczq_securities", "首创证券", SCZQCampusURL, "官网校园招聘类别（含总部、分支及其他招聘单位，届别与签约单位见原文）", 1800, false},
		{"neusoft", "东软集团", "https://neusoft-campus.zhiye.com/", "官网校招分类（含软件研发，具体届别见原文）", 1800, false},
		{"kedacom", "苏州科达", KedacomCampusURL, "官网校园招聘类别（不含实习，包含不同届别，以原文为准）", 1800, false},
		{"games37", "三七互娱", Games37CampusURL, "官网校园招聘分类（含游戏研发、AI 等方向，具体届别见原文）", 1800, false},
		{"nexchip", "晶合集成", "https://nexchip.zhiye.com/campus/jobs", "官网校招分类（包含软件及制造研发方向，具体届别见原文）", 1800, false},
		{"yonyou", "用友网络", hotjobCampusURL("yonyou"), "2027 届校招（北京）固定项目（北京为项目名，工作城市见岗位；不含其他项目）", 1800, false},
		{"sangfor", "深信服", SangforCampusURL, "2027 届常规校园招聘（不含 X-STAR 专项、实习及社招）", 1800, false},
		{"gbits", "吉比特&雷霆游戏", GBitsCampusURL, "2027 届秋季校招正式岗位（含提前实习要求，用工形式见原文）", 1800, false},
		{"tcl_digital", "TCL · 流程与数字化转型中心", tclCampusURL("tcl_digital"), "2027 届全球校招 · 流程与数字化转型中心", 1800, false},
		{"tcl_honghu", "TCL · 鸿鹄实验室", tclCampusURL("tcl_honghu"), "2027 届全球校招 · 鸿鹄实验室", 1800, false},
		{"cec_software", "中国电子 · 麒麟软件/中电云", CECCampusURL, "官网校招分类 · 仅麒麟软件、中电云两个招聘单位（具体届别见原文）", 1800, false},
	}
}

func campusSite(raw string) (CampusSite, error) {
	u, err := url.Parse(raw)
	if err != nil || u.Scheme != "https" || u.User != nil || u.RawPath != "" {
		return CampusSite{}, fail("UNSUPPORTED", false, 0)
	}
	query, err := url.ParseQuery(u.RawQuery)
	if err != nil {
		return CampusSite{}, fail("UNSUPPORTED", false, 0)
	}
	path := strings.TrimRight(u.Path, "/")
	for _, site := range CampusSites() {
		if _, ok := sectorScopes[site.Adapter]; ok && sectorEntry(site, u) {
			return site, nil
		}
		if site.Adapter == "lenovo" && u.Host == "talent.lenovo.com.cn" && path == "" && u.RawQuery == "" && u.RawFragment == "" && (u.Fragment == "" || u.Fragment == "/campus") {
			return site, nil
		}
		if site.Adapter == "kuaishou" && u.Host == "campus.kuaishou.cn" && path == "/recruit/campus/e" && u.RawQuery == "" && u.RawFragment == "" && (u.Fragment == "" || u.Fragment == "/campus/index" || u.Fragment == "/campus/jobs" || u.Fragment == "/campus/jobs?recruitSubProjectCodes="+kuaishouProjectCode) {
			return site, nil
		}
		if site.Adapter == "jd" && u.Host == "campus.jd.com" && path == "" && u.RawQuery == "" && (u.Fragment == "" || u.Fragment == "/jobs" || u.Fragment == "/jobs?type=present") {
			return site, nil
		}
		if u.Fragment != "" {
			continue
		}
		if cfg, ok := beisenCompanies[site.Adapter]; ok && (u.Host == strings.TrimPrefix(cfg.Origin, "https://") || (site.Adapter == "h3c" && u.Host == "h3c.zhiye.com") || (site.Adapter == "venustech" && u.Host == "venustech.zhiye.com")) && (u.String() == site.URL || path == "" || strings.EqualFold(path, "/campus") || strings.EqualFold(path, "/campus/jobs") || (site.Adapter == "sgm" && path == "/campusjobs")) && u.RawQuery == "" {
			return site, nil
		}
		switch site.Adapter {
		case "sap":
			if u.Host == "careers.sap.com" && path == "/search" && len(query) == 3 && len(query["q"]) == 1 && query.Get("q") == "" && len(query["optionsFacetsDD_country"]) == 1 && query.Get("optionsFacetsDD_country") == "CN" && len(query["optionsFacetsDD_customfield3"]) == 1 && query.Get("optionsFacetsDD_customfield3") == "Graduate" {
				return site, nil
			}
		case "tencent":
			if u.Host == "join.qq.com" && (path == "" || path == "/post.html") && u.RawQuery == "" {
				return site, nil
			}
		case "xiaohongshu":
			if u.Host == "job.xiaohongshu.com" && path == "/campus/position" && u.RawQuery == "" {
				return site, nil
			}
		case "baidu":
			if u.Host == "talent.baidu.com" && (path == "/jobs/list" || path == "/jobs/campus") && (u.RawQuery == "" || (len(query) == 1 && len(query["recruitType"]) == 1 && query.Get("recruitType") == "GRADUATE")) {
				return site, nil
			}
		case "meituan":
			if u.Host == "zhaopin.meituan.com" && path == "/web/campus" && (u.RawQuery == "" || (len(query) == 1 && len(query["hiringType"]) == 1 && query.Get("hiringType") == "1_1")) {
				return site, nil
			}
		case "netease":
			if u.Host == "campus.163.com" && path == "/app/job/position" && len(query) == 1 && len(query["id"]) == 1 && query.Get("id") == "103" {
				return site, nil
			}
		case "alibaba":
			if u.Host == "campus-talent.alibaba.com" && path == "/campus/position" && len(query) == 1 && len(query["batchId"]) == 1 && query.Get("batchId") == "100000760001" {
				return site, nil
			}
		case "siemens":
			if u.Host == "jobs.siemens.com.cn" && path == "/siemens/position/index" && len(query) == 1 && len(query["recruitmentType"]) == 1 && query.Get("recruitmentType") == siemensScope {
				return site, nil
			}
		case "haier":
			if u.Host == "maker.haier.net" && path == "/client/campusmobile/activity/id/68/fid.html" && u.RawQuery == "" {
				return site, nil
			}
		case "oppo":
			if u.Host == "careers.oppo.com" && path == "/university/oppo/campus/post" && (u.RawQuery == "" || (len(query) == 1 && len(query["recruitType"]) == 1 && query.Get("recruitType") == "Graduate")) {
				return site, nil
			}
		case "honor":
			if u.Host == "career.honor.com" && path == "/"+honorSuite+"/pb/school.html" && u.RawQuery == "" {
				return site, nil
			}
		case "midea":
			if u.Host == "careers.midea.com" && (path == "/schoolOut" && u.RawQuery == "" || path == "/schoolOut/post" && len(query) == 1 && len(query["projectType"]) == 1 && query.Get("projectType") == "1") {
				return site, nil
			}
		case "byd":
			if u.Host == "job.byd.com" && (path == "/portal/mobile/school-home" && u.RawQuery == "" || path == "/portal/mobile/schoolPositionList" && len(query) == 1 && len(query["tab"]) == 1 && query.Get("tab") == "应届生") {
				return site, nil
			}
		case "hikvision":
			if u.Host == "campushr.hikvision.com" && path == "/school" && len(query) == 1 && len(query["schoolType"]) == 1 && query.Get("schoolType") == "nozxf" {
				return site, nil
			}
		case "bilibili":
			if u.Host == "jobs.bilibili.com" && path == "/campus/positions" && (u.RawQuery == "" || (len(query) == 1 && len(query["type"]) == 1 && query.Get("type") == "3")) {
				return site, nil
			}
		}
	}
	return CampusSite{}, fail("UNSUPPORTED", false, 0)
}

func RecognizeCampusURL(raw string) error {
	_, err := campusSite(raw)
	return err
}

func (a PublicPlatform) PreviewCampus(ctx context.Context, raw string) (CampusPreview, error) {
	site, err := campusSite(raw)
	if err != nil {
		return CampusPreview{}, err
	}
	var v CampusPreview
	if site.Adapter == "xiaohongshu" {
		v, err = a.PreviewXHS(ctx, raw)
		v.Name = site.Company + " · " + v.Name
	} else if site.Adapter == "alibaba" {
		v, err = a.previewAlibaba(ctx, site)
	} else if site.Adapter == "bilibili" {
		v, err = a.previewBilibili(ctx, site)
	} else if site.Adapter == "siemens" {
		v, err = a.previewSiemens(ctx, site)
	} else if site.Adapter == "haier" {
		v, err = a.previewHaier(ctx, site)
	} else if site.Adapter == "oppo" {
		v, err = a.previewOPPO(ctx, site)
	} else if site.Adapter == "kuaishou" {
		v, err = a.previewKuaishou(ctx, site)
	} else if moreTenant(site.Adapter) != "" {
		v, err = a.previewMore(ctx, site)
	} else if site.Adapter == "jd" || site.Adapter == "netease" {
		v, err = a.previewPortal(ctx, site)
	} else {
		v, err = a.previewGraduate(ctx, site)
	}
	v.Adapter, v.Company, v.MinimumInterval, v.SupportsDirection = site.Adapter, site.Company, site.MinimumInterval, site.SupportsDirection
	return v, err
}
