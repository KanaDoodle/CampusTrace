package pipeline

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"github.com/KanaDoodle/CampusTrace/internal/analysis"
	d "github.com/KanaDoodle/CampusTrace/internal/domain"
	"github.com/KanaDoodle/CampusTrace/internal/observability"
	p "github.com/KanaDoodle/CampusTrace/internal/persistence"
	"github.com/KanaDoodle/CampusTrace/internal/source"
	"github.com/redis/go-redis/v9"
	"log/slog"
	"sync"
	"time"

	"go.opentelemetry.io/otel/attribute"
)

type Analyzer interface {
	Analyze(context.Context, d.Observation, string) ([]d.Claim, error)
}
type Worker struct {
	Source                   source.DiscoveryAdapter
	radarCursor              string
	Version                  string
	ParserVersion            string
	Store                    *p.Store
	Queue                    *Queue
	Analyzer                 Analyzer
	Concurrency, MaxAttempts int
	LaneConcurrency          map[string]int
	Timeout, ClaimIdle       time.Duration
	TaskHistory              time.Duration
	Metrics                  *observability.Metrics
}

func (w *Worker) Dispatch(ctx context.Context) error {
	_, err := w.dispatch(ctx)
	return err
}
func (w *Worker) dispatch(ctx context.Context) (int, error) {
	if w.Queue.Partitioned {
		if _, e := w.Store.BackfillOutboxTenants(ctx); e != nil {
			return 0, e
		}
		return w.Store.FairOutbox(ctx, func(ctx context.Context, t p.Task) (bool, error) {
			if t.Type == "ANALYZE" {
				o, e := w.Store.Observation(ctx, t.EntityID)
				if e != nil && !errors.Is(e, p.ErrNotFound) {
					return false, e
				}
				// An orphan legacy envelope still reaches the normal terminal/DLQ
				// path. It must not roll back healthy owners' dispatch transactions.
				if e == nil {
					t, e = w.Store.BindAnalysis(ctx, t, w.processingVersion(o))
					if e != nil {
						return false, e
					}
				}
			}
			e := w.Queue.Publish(ctx, t)
			if errors.Is(e, ErrQueueFull) {
				if w.Metrics != nil {
					w.Metrics.Add("queue_admission_deferred_total", 1)
				}
				return false, nil
			}
			return e == nil, e
		})
	}
	count := 0
	err := w.Store.Tx(ctx, func(tx *sql.Tx) error {
		tasks, err := p.Many[p.Task](ctx, tx, "SELECT body FROM outbox WHERE sent=FALSE ORDER BY created_at LIMIT 50 FOR UPDATE SKIP LOCKED")
		if err != nil {
			return err
		}
		for _, t := range tasks {
			if t.Type == "ANALYZE" {
				o, e := w.Store.Observation(ctx, t.EntityID)
				if e != nil {
					return e
				}
				t, e = w.Store.BindAnalysis(ctx, t, w.processingVersion(o))
				if e != nil {
					return e
				}
			}
			if err = w.Queue.Publish(ctx, t); err != nil {
				return err
			}
			if _, err = tx.ExecContext(ctx, "UPDATE outbox SET sent=TRUE WHERE id=?", t.ID); err != nil {
				return err
			}
			count++
		}
		return nil
	})
	return count, err
}
func (w *Worker) Process(ctx context.Context, t p.Task) (err error) {
	if err := ValidateTask(t); err != nil {
		return err
	}
	ctx, span := observability.Consumer(ctx, "task.process", t.TraceParent)
	defer func() { observability.End(span, err) }()
	span.SetAttributes(attribute.String("task.type", t.Type), attribute.String("task.id", t.ID), attribute.Int("task.attempt", t.Attempt))
	fields := observability.From(ctx)
	fields.RequestID = t.CorrelationID
	fields.TaskID = t.ID
	ctx = observability.With(ctx, fields)
	if w.Metrics != nil {
		w.Metrics.Observe("task_age_seconds", max(0, time.Since(t.CreatedAt).Seconds()))
		started := time.Now()
		defer func() {
			w.Metrics.Since("task_process", started)
			if err != nil {
				w.Metrics.Add("task_errors_total", 1)
			}
		}()
	}
	if t.Type == "WATCH_CHECK" || t.Type == "WATCH_FETCH" {
		return w.processWatch(ctx, t)
	}
	if t.Type == "SOURCE_IMPORT" {
		return w.processSourceImport(ctx, t)
	}
	if t.Type == "ASSESS" {
		return w.Store.Assess(ctx, t.ID, t.EntityID)
	}
	o, err := w.Store.Observation(ctx, t.EntityID)
	if err != nil {
		return err
	}
	t, err = w.Store.BindAnalysis(ctx, t, w.processingVersion(o))
	if err != nil {
		return err
	}
	done, err := w.Store.Analyzed(ctx, t.EntityID, t.ProcessingVersion)
	if err != nil {
		return err
	}
	if done {
		return w.Store.ReconcileAnalysis(ctx, t.EntityID, t.ProcessingVersion, t.Generation)
	}
	if t.ProcessingVersion != w.processingVersion(o) {
		return p.ErrProcessingUnavailable
	}
	claims := []d.Claim{}
	if o.FetchStatus == "SUCCESS" {
		key := w.Queue.Prefix + "analysis:cache-v2:" + t.ProcessingVersion + ":" + d.Hash(o.Text)
		cached, e := w.Queue.R.Get(ctx, key).Bytes()
		cacheValid := e == nil
		if e == nil {
			if e = json.Unmarshal(cached, &claims); e != nil {
				cacheValid = false
			}
			for _, c := range claims {
				if c.Validate(o.Text) != nil {
					cacheValid = false
					break
				}
			}
		}
		// JSON null is a valid saved empty result, distinct from a cache miss.
		if !cacheValid {
			began, e := w.Store.BeginAnalysisInvocation(ctx, t)
			if e != nil {
				return e
			}
			if !began {
				return ErrAnalysisUncertain
			}
			start := time.Now()
			ctx = observability.With(ctx, observability.Fields{RequestID: t.CorrelationID, TaskID: t.ID, JobID: o.JobID})
			claims, err = w.Analyzer.Analyze(ctx, o, t.CorrelationID)
			w.Metrics.Since("analysis_latency", start)
			w.Metrics.Since("rpc_latency", start)
			if err != nil {
				w.Metrics.Add("rpc_errors", 1)
				// Only an explicit rejection permits a later automatic attempt.
				var rejected *analysis.HTTPError
				if errors.As(err, &rejected) && (rejected.Status == 429 || rejected.Status == 401 || rejected.Status == 403) {
					cleanup, stop := context.WithTimeout(context.WithoutCancel(ctx), 5*time.Second)
					e := w.Store.RejectAnalysisInvocation(cleanup, t)
					stop()
					if e != nil {
						return ErrAnalysisUncertain
					}
				} else {
					return ErrAnalysisUncertain
				}
				return err
			}
			if err = w.Queue.R.Set(ctx, key, d.JSON(claims), 24*time.Hour).Err(); err != nil {
				return ErrAnalysisUncertain
			}
		}
	}
	return w.Store.PersistAnalysis(ctx, o.ID, t.ProcessingVersion, claims)
}
func (w *Worker) handle(root context.Context, m redis.XMessage, consumers ...string) {
	t, err := Decode(m)
	if err != nil {
		consumer := "unknown"
		if len(consumers) > 0 {
			consumer = consumers[0]
		}
		ctx, cancel := context.WithTimeout(root, w.Timeout)
		defer cancel()
		if e := w.Queue.Quarantine(ctx, m, t, err, consumer); e != nil {
			slog.Error("poison quarantine failed", "message_id", m.ID)
		} else {
			w.Metrics.Add("poison_count", 1)
		}
		return
	}
	ctx, cancel := context.WithTimeout(root, w.Timeout)
	defer cancel()
	if !w.Queue.belongs(t) {
		w.Metrics.Add("queue_wrong_lane_total", 1)
		return
	} // Never ACK another lane's work.
	if err == nil {
		if !t.QueueUntil.IsZero() && time.Now().After(t.QueueUntil) {
			err = ErrQueueExpired
		} else {
			w.Metrics.Observe("queue_wait_seconds_"+w.Queue.Lane, time.Since(t.CreatedAt).Seconds())
			err = w.Process(ctx, t)
		}
	}
	if root.Err() != nil {
		return
	}
	if err == nil {
		if e := w.Queue.Ack(ctx, m.ID); e != nil {
			slog.Error("task ack failed", "task_id", t.ID)
		} else {
			w.Metrics.Add("tasks_processed", 1)
			slog.InfoContext(ctx, "task completed", "task_id", t.ID, "observation_id", t.EntityID, "request_id", t.CorrelationID)
		}
		return
	}
	var sourceFailure *source.FetchError
	if (t.Type == "WATCH_CHECK" || t.Type == "WATCH_FETCH" || t.Type == "SOURCE_IMPORT") && errors.As(err, &sourceFailure) && sourceFailure.Category == "RATE_LIMIT" {
		if e := w.Queue.DeferRateLimited(root, m.ID, t); e != nil {
			slog.Error("source pace deferral failed", "task_id", t.ID)
		} else {
			w.Metrics.Add("retry_count", 1)
		}
		return
	}
	w.Metrics.Add("task_failures", 1)
	if t.ID == "" {
		t = p.NewTask("ANALYZE", "invalid-envelope")
		err = errors.New("schema: invalid envelope")
	}
	if t.Type == "ANALYZE" && !errors.Is(err, p.ErrProcessingUnavailable) && (!Transient(err) || t.Attempt >= w.MaxAttempts) {
		code := "ANALYSIS_FAILED"
		if errors.Is(err, ErrQueueExpired) {
			code = "QUEUE_EXPIRED"
		}
		if errors.Is(err, ErrAnalysisUncertain) {
			code = "ANALYSIS_OUTCOME_UNKNOWN"
		}
		if e := w.Store.AnalysisTaskFailed(root, t, code); e != nil {
			slog.Warn("could not persist terminal analysis failure", "task_id", t.ID)
			return
		}
	}
	if (t.Type == "WATCH_CHECK" || t.Type == "WATCH_FETCH") && (!Transient(err) || t.Attempt >= w.MaxAttempts) {
		if e := w.terminalWatch(root, t); e != nil {
			return
		}
		if e := w.Store.SourceImportWatchFailed(root, t, sourceImportFailure(err)); e != nil {
			return
		}
	}
	if t.Type == "SOURCE_IMPORT" && (!Transient(err) || t.Attempt >= w.MaxAttempts) {
		if e := w.Store.FailSourceImport(root, t, sourceImportFailure(err)); e != nil {
			return
		}
	}
	retry, e := w.Queue.Fail(root, m.ID, t, err, w.MaxAttempts)
	if e != nil {
		slog.Error("task failure persistence failed", "task_id", t.ID)
	} else if retry {
		w.Metrics.Add("retry_count", 1)
	} else {
		w.Metrics.Add("dlq_count", 1)
	}
	slog.WarnContext(observability.Extract(root, t.TraceParent), "task failed", "task_id", t.ID, "observation_id", t.EntityID, "request_id", t.CorrelationID, "retry", retry, "category", func() string {
		if Transient(err) {
			return "TRANSIENT"
		}
		return "PERMANENT"
	}())
}
func (w *Worker) Run(ctx context.Context) error {
	if w.Concurrency < 1 || w.Timeout <= 0 || w.ClaimIdle <= w.Timeout || w.MaxAttempts < 1 || w.MaxAttempts > MaxTaskAttempt {
		return errors.New("workers/timeout positive, attempts in 1..100, and claim idle must exceed task timeout")
	}
	retention := w.TaskHistory
	if retention == 0 {
		retention = 24 * time.Hour
	}
	if retention < time.Hour || retention > 365*24*time.Hour {
		return errors.New("task history retention must be between one hour and one year")
	}
	if err := w.Queue.Init(ctx); err != nil {
		return err
	}
	if err := w.Store.InitAssessmentSchedule(ctx); err != nil {
		return err
	}
	var wg sync.WaitGroup
	if w.Queue.ResolveOwner == nil {
		w.Queue.ResolveOwner = w.Store.TaskOwner
	}
	total := w.Concurrency
	if w.Queue.Partitioned {
		total = 0
		for _, lane := range QueueLanes() {
			n := w.LaneConcurrency[lane]
			if n == 0 {
				n = 1
			}
			if n < 1 || n > 16 {
				return errors.New("lane concurrency must be in 1..16")
			}
			total += n
		}
		if total > 64 {
			return errors.New("total worker concurrency exceeds 64")
		}
	}
	workers := []*Worker{}
	if w.Queue.Partitioned {
		for _, lane := range QueueLanes() {
			n := w.LaneConcurrency[lane]
			if n == 0 {
				n = 1
			}
			child := *w
			child.Queue = w.Queue.ForLane(lane)
			for i := 0; i < n; i++ {
				workers = append(workers, &child)
			}
		}
	} else {
		for i := 0; i < w.Concurrency; i++ {
			workers = append(workers, w)
		}
	}
	for _, executor := range workers {
		executor := executor
		wg.Add(1)
		go func() {
			defer wg.Done()
			consumer := d.ID()
			for ctx.Err() == nil {
				msgs, err := executor.Queue.Recover(ctx, consumer, w.ClaimIdle)
				if err == nil {
					for _, m := range msgs {
						executor.handle(ctx, m, consumer)
					}
				}
				if executor.Queue.Lane != "" {
					if _, e := executor.Queue.Pump(ctx); e != nil && ctx.Err() == nil {
						slog.Warn("ready queue pump failed", "lane", executor.Queue.Lane)
					}
				}
				streams, err := executor.Queue.R.XReadGroup(ctx, &redis.XReadGroupArgs{Group: executor.Queue.Group(), Consumer: consumer, Streams: []string{executor.Queue.Stream(), ">"}, Count: 1, Block: time.Second}).Result()
				if err == nil {
					for _, stream := range streams {
						for _, m := range stream.Messages {
							executor.handle(ctx, m, consumer)
						}
					}
				} else if err != redis.Nil && ctx.Err() == nil {
					select {
					case <-ctx.Done():
					case <-time.After(200 * time.Millisecond):
					}
				}
			}
		}()
	}
	if w.Queue.Partitioned {
		wg.Add(1)
		go func() { defer wg.Done(); w.bridgeLegacy(ctx) }()
	}
	freshness := time.NewTimer(0)
	defer freshness.Stop()
	wg.Add(1)
	go func() {
		defer wg.Done()
		tick := time.NewTicker(time.Minute)
		defer tick.Stop()
		for {
			if ctx.Err() != nil {
				return
			}
			batch, cancel := context.WithTimeout(ctx, 30*time.Second)
			w.radarTick(batch)
			cancel()
			select {
			case <-ctx.Done():
				return
			case <-tick.C:
			}
		}
	}()
	delay := 200 * time.Millisecond
	dispatch := time.NewTimer(delay)
	defer dispatch.Stop()
	history := time.NewTimer(0)
	defer history.Stop()
	defer wg.Wait()
	for {
		select {
		case <-ctx.Done():
			return nil
		case <-freshness.C:
			n, err := w.Store.ScheduleAssessments(ctx, time.Now().UTC(), 100)
			if err != nil && ctx.Err() == nil {
				slog.Warn("freshness scheduling failed")
			}
			if err == nil && n > 0 && w.Metrics != nil {
				w.Metrics.Add("assessments_scheduled_total", float64(n))
			}
			next := time.Minute
			if err == nil && n == 100 {
				next = time.Second
			}
			freshness.Reset(next)
		case <-history.C:
			cleanup, cancel := context.WithTimeout(ctx, 3*time.Second)
			n, err := w.Queue.TrimAcknowledged(cleanup, retention)
			cancel()
			if err != nil && ctx.Err() == nil {
				slog.Warn("task history cleanup failed")
			} else if n > 0 && w.Metrics != nil {
				w.Metrics.Add("queue_history_trimmed_total", float64(n))
			}
			next := time.Minute
			if err == nil && n > 0 {
				next = time.Second
			}
			history.Reset(next)
		case <-dispatch.C:
			dispatched, dispatchErr := w.dispatch(ctx)
			if dispatchErr != nil && ctx.Err() == nil {
				slog.Warn("outbox dispatch failed")
			}
			scheduled, scheduleErr := w.Queue.Schedule(ctx)
			if scheduleErr != nil && ctx.Err() == nil {
				slog.Warn("retry scheduler failed")
			}
			delay = dispatchDelay(delay, dispatched+scheduled, dispatchErr != nil || scheduleErr != nil)
			dispatch.Reset(delay)
		}
	}
}

func (w *Worker) version() string { return d.EffectiveAnalysisVersion(w.Version) }

func (w *Worker) processingVersion(o d.Observation) string {
	parser := w.ParserVersion
	if parser == "" {
		parser = d.ParserVersion
	}
	return d.ProcessingVersion(w.Version, parser, o.ParserVersion)
}
