package resume

import (
	d "github.com/KanaDoodle/CampusTrace/internal/domain"
	"regexp"
	"strconv"
	"strings"
	"unicode"
	"unicode/utf8"
)

// Diagnostics contain only fixed reasons and numeric positions. Never include
// resume text, model content, suggested values, credentials or personal names.
type Diagnostic struct {
	Reason       string `json:"validation_reason"`
	Scope        string `json:"scope,omitempty"`
	ProjectIndex int    `json:"project_index,omitempty"`
	ItemIndex    int    `json:"item_index,omitempty"`
}

type ValidationError struct{ Diagnostic }

func (e *ValidationError) Error() string { return "invalid resume draft: " + e.Reason }
func (e *ValidationError) Unwrap() error { return ErrInvalid }

func invalid(reason, scope string, project, item int) error {
	return &ValidationError{Diagnostic{reason, scope, project, item}}
}

func draftLimits(draft Draft) error {
	if len(draft.Suggestions) > 60 || len(draft.Projects) > 15 || len(draft.Educations) > 8 {
		return invalid("DRAFT_LIMIT", "", 0, 0)
	}
	count := 0
	for i, project := range draft.Projects {
		if len(project.Facts) > 20 {
			return invalid("PROJECT_FACTS_LIMIT", "PROJECT", i+1, 0)
		}
		if len(project.Bullets) > 20 || len(project.Description) > 4000 {
			return invalid("PROJECT_CONTENT_LIMIT", "PROJECT", i+1, 0)
		}
		total := len(project.Description)
		for _, bullet := range project.Bullets {
			total += len(bullet)
		}
		if total > 16000 {
			return invalid("PROJECT_CONTENT_LIMIT", "PROJECT", i+1, 0)
		}
		count += len(project.Facts)
	}
	if count > 80 {
		return invalid("DRAFT_LIMIT", "", 0, 0)
	}
	return nil
}

func valueReason(value string, limit int) string {
	if strings.TrimSpace(value) == "" {
		return "VALUE_EMPTY"
	}
	if !utf8.ValidString(value) || strings.ContainsRune(value, '\x00') {
		return "VALUE_INVALID"
	}
	if len(value) > limit {
		return "VALUE_LENGTH"
	}
	if HasSensitive(value) {
		return "VALUE_SENSITIVE"
	}
	return ""
}

func suggestionReason(s Suggestion) string {
	if !allowedFields[s.Field] {
		return "FIELD_UNKNOWN"
	}
	if reason := valueReason(s.Value, 120); reason != "" {
		return reason
	}
	switch s.Field {
	case "degree":
		if s.Value != "ASSOCIATE" && s.Value != "BACHELOR" && s.Value != "MASTER" && s.Value != "PHD" {
			return "VALUE_FORMAT"
		}
	case "graduation_year", "experience_months":
		n, err := strconv.Atoi(s.Value)
		if err != nil || strconv.Itoa(n) != s.Value || (s.Field == "graduation_year" && (n < 2000 || n > 2100)) || (s.Field == "experience_months" && (n < 0 || n > 600)) {
			return "VALUE_FORMAT"
		}
	}
	return ""
}

func factReason(f Fact) string {
	if f.Kind != "IMPLEMENTED" && f.Kind != "LIMITATION" && f.Kind != "PLANNED" {
		return "FACT_KIND"
	}
	return valueReason(f.Claim, 4000)
}

func exactReason(source, value string) string {
	return exactReasonLimit(source, value, 600)
}

func exactReasonLimit(source, value string, limit int) string {
	if strings.TrimSpace(value) == "" {
		return "EXCERPT_EMPTY"
	}
	if !utf8.ValidString(value) || strings.ContainsRune(value, '\x00') {
		return "EXCERPT_NOT_EXACT"
	}
	if len(value) > limit {
		return "EXCERPT_LENGTH"
	}
	if !strings.Contains(source, value) {
		return "EXCERPT_NOT_EXACT"
	}
	return ""
}

// Validate remains strict. Review must first restore an actual contiguous slice
// of the submitted source; downstream callers never receive normalized quotes.
func Validate(draft Draft, source string) error {
	if err := draftLimits(draft); err != nil {
		return err
	}
	for i, e := range draft.Educations {
		reason := educationReason(e)
		if reason == "" {
			reason = exactReason(source, e.Excerpt)
		}
		if reason != "" {
			return invalid(reason, "EDUCATION", 0, i+1)
		}
	}
	for i, s := range draft.Suggestions {
		reason := suggestionReason(s)
		if reason == "" {
			reason = exactReason(source, s.Excerpt)
		}
		if reason != "" {
			return invalid(reason, "SUGGESTION", 0, i+1)
		}
	}
	for i, project := range draft.Projects {
		reason := valueReason(project.Name, 200)
		if reason == "" {
			reason = exactReason(source, project.Excerpt)
		}
		if reason != "" {
			return invalid(reason, "PROJECT", i+1, 0)
		}
		block := projectBlock(source, project.Excerpt, draft.Projects)
		if project.Description != "" {
			if reason := projectContentReason(block, project.Description, 4000); reason != "" {
				return invalid(reason, "PROJECT_DESCRIPTION", i+1, 0)
			}
		}
		for j, bullet := range project.Bullets {
			if reason := projectContentReason(block, bullet, 2000); reason != "" {
				return invalid(reason, "PROJECT_BULLET", i+1, j+1)
			}
		}
		for j, fact := range project.Facts {
			reason := factReason(fact)
			if reason == "" {
				reason = exactReasonLimit(source, fact.Excerpt, 2000)
			}
			if reason != "" {
				return invalid(reason, "FACT", i+1, j+1)
			}
		}
	}
	return nil
}

// Map every compact UTF-8 byte to its original rune span. Only Unicode
// whitespace is ignored; letters, casing, punctuation and numbers stay exact.
func compactSource(source string) (string, []int, []int) {
	var text strings.Builder
	starts, ends := []int{}, []int{}
	for i, r := range source {
		if unicode.IsSpace(r) {
			continue
		}
		text.WriteRune(r)
		for n := 0; n < utf8.RuneLen(r); n++ {
			starts = append(starts, i)
			ends = append(ends, i+utf8.RuneLen(r))
		}
	}
	return text.String(), starts, ends
}

func restoreExcerpt(source, compact string, starts, ends []int, value string) (string, bool, string) {
	return restoreExcerptLimit(source, compact, starts, ends, value, 600)
}

func restoreExcerptLimit(source, compact string, starts, ends []int, value string, limit int) (string, bool, string) {
	if reason := exactReasonLimit(source, value, limit); reason != "EXCERPT_NOT_EXACT" {
		return value, false, reason
	}
	if !utf8.ValidString(value) || strings.ContainsRune(value, '\x00') {
		return "", false, "EXCERPT_NOT_EXACT"
	}
	var quote strings.Builder
	for _, r := range value {
		if !unicode.IsSpace(r) {
			quote.WriteRune(r)
		}
	}
	needle := quote.String()
	if needle == "" {
		return "", false, "EXCERPT_EMPTY"
	}
	i := strings.Index(compact, needle)
	if i < 0 {
		return "", false, "EXCERPT_NOT_EXACT"
	}
	if strings.Contains(compact[i+1:], needle) {
		return "", false, "EXCERPT_AMBIGUOUS"
	}
	actual := source[starts[i]:ends[i+len(needle)-1]]
	if reason := exactReasonLimit(source, actual, limit); reason != "" {
		return "", false, reason
	}
	return actual, true, ""
}

func reviewDraft(draft Draft, source string) (Draft, error) {
	if err := draftLimits(draft); err != nil {
		return Draft{}, err
	}
	out := Draft{Suggestions: []Suggestion{}, Projects: []Project{}}
	compact, starts, ends := compactSource(source)
	// Use restored headings to delimit projects even when PDF whitespace differs.
	sourceProjects := []Project{}
	for _, project := range draft.Projects {
		if heading, _, reason := restoreExcerpt(source, compact, starts, ends, project.Excerpt); reason == "" {
			sourceProjects = append(sourceProjects, Project{Excerpt: heading})
		}
	}
	checkLimit := func(quote string, d Diagnostic, reason string, limit int) (string, bool) {
		actual, repaired := "", false
		if reason == "" {
			actual, repaired, reason = restoreExcerptLimit(source, compact, starts, ends, quote, limit)
		}
		if reason != "" {
			d.Reason = reason
			out.Warnings = append(out.Warnings, d)
			return "", false
		}
		if repaired {
			out.NormalizedExcerpts++
		}
		return actual, true
	}
	check := func(quote string, diagnostic Diagnostic, reason string) (string, bool) {
		return checkLimit(quote, diagnostic, reason, 600)
	}
	for i, e := range draft.Educations {
		actual, ok := check(e.Excerpt, Diagnostic{Scope: "EDUCATION", ItemIndex: i + 1}, educationReason(e))
		if ok {
			e.Excerpt = actual
			if e.Majors == nil {
				e.Majors = []string{}
			}
			out.Educations = append(out.Educations, e)
		}
	}
	values := map[string]map[string]bool{}
	for _, s := range draft.Suggestions {
		if s.Field == "degree" || s.Field == "graduation_year" || s.Field == "experience_months" {
			if values[s.Field] == nil {
				values[s.Field] = map[string]bool{}
			}
			values[s.Field][s.Value] = true
		}
	}
	for i, suggestion := range draft.Suggestions {
		if len(out.Educations) > 0 && (suggestion.Field == "degree" || suggestion.Field == "graduation_year" || suggestion.Field == "majors") {
			continue
		}
		reason := suggestionReason(suggestion)
		if reason == "" && len(values[suggestion.Field]) > 1 {
			reason = "VALUE_CONFLICT"
		}
		actual, ok := check(suggestion.Excerpt, Diagnostic{Scope: "SUGGESTION", ItemIndex: i + 1}, reason)
		if ok {
			suggestion.Excerpt = actual
			out.Suggestions = append(out.Suggestions, suggestion)
		}
	}
	validFacts := 0
	for i, project := range draft.Projects {
		actual, ok := check(project.Excerpt, Diagnostic{Scope: "PROJECT", ProjectIndex: i + 1}, valueReason(project.Name, 200))
		if !ok {
			continue
		} // An unbound project cannot safely own its facts.
		kept := Project{Name: project.Name, Excerpt: actual, Bullets: []string{}, Facts: []Fact{}}
		block := projectBlock(source, actual, sourceProjects)
		content := func(value, scope string, item, limit int) (string, bool) {
			quote, ok := checkLimit(value, Diagnostic{Scope: scope, ProjectIndex: i + 1, ItemIndex: item}, valueReason(value, limit), limit)
			if ok && !strings.Contains(block, quote) {
				out.Warnings = append(out.Warnings, Diagnostic{Reason: "EXCERPT_OUTSIDE_PROJECT", Scope: scope, ProjectIndex: i + 1, ItemIndex: item})
				return "", false
			}
			return quote, ok
		}
		if project.Description != "" {
			kept.Description, _ = content(project.Description, "PROJECT_DESCRIPTION", 0, 4000)
		}
		for j, bullet := range project.Bullets {
			if quote, ok := content(bullet, "PROJECT_BULLET", j+1, 2000); ok && !containsBullet(kept.Bullets, quote) {
				kept.Bullets = append(kept.Bullets, quote)
			}
		}
		kept.Bullets = alignSourceBullets(block, kept.Bullets)
		for j, fact := range project.Facts {
			actual, ok := checkLimit(fact.Excerpt, Diagnostic{Scope: "FACT", ProjectIndex: i + 1, ItemIndex: j + 1}, factReason(fact), 2000)
			if ok {
				fact.Excerpt = actual
				kept.Facts = append(kept.Facts, fact)
				validFacts++
			}
		}
		kept.Facts = completeAccomplishments(kept.Facts, kept.Bullets)
		out.Projects = append(out.Projects, kept)
	}
	out.Suggestions = filterSkillDetails(out.Suggestions)
	if len(out.Suggestions) == 0 && len(out.Educations) == 0 && validFacts == 0 && len(out.Warnings) > 0 {
		return Draft{}, &ValidationError{out.Warnings[0]}
	}
	if err := Validate(out, source); err != nil {
		return Draft{}, err
	}
	return out, nil
}

func educationReason(e Education) string {
	if d.DegreeLevel(e.Degree) == 0 {
		return "EDUCATION_FORMAT"
	}
	if (d.Education{Degree: e.Degree, Majors: e.Majors, StartYear: e.StartYear, GraduationYear: e.GraduationYear, GraduationMonth: e.GraduationMonth, Status: e.Status}).Validate() != nil {
		return "EDUCATION_FORMAT"
	}
	if e.GraduationMonth != 0 {
		matches := educationYearMonth.FindAllStringSubmatch(e.Excerpt, -1)
		if len(matches) == 0 {
			return "EDUCATION_FORMAT"
		}
		last := matches[len(matches)-1]
		year, _ := strconv.Atoi(last[1])
		month, _ := strconv.Atoi(last[2])
		if year != e.GraduationYear || month != e.GraduationMonth {
			return "EDUCATION_FORMAT"
		}
	}
	for _, major := range e.Majors {
		if reason := valueReason(major, 200); reason != "" {
			return reason
		}
	}
	return ""
}

var educationYearMonth = regexp.MustCompile(`(20\d{2})(?:年|[-./])\s*(\d{1,2})(?:月|\b)`)
