# 架构与处理链路

这里说明后台如何处理招聘观察、恢复失败任务，以及 Agent 能执行哪些动作。产品使用方式见 [README](../README.md)，匹配规则见 [岗位匹配与求职资料](matching.md)。

## 原文、证据和判断为什么分开保存

```text
Source → Observation → Evidence → Deterministic Rules → Assessment
```

| 层次 | 保存什么 | 如何约束结论 |
| --- | --- | --- |
| Observation | 一次实际观察的原始输入、时间和抓取结果 | 输入不可变，提取处理状态可独立推进；新的失败不会被旧的成功掩盖 |
| Evidence | 来源 Observation、原文或规范化摘录、提取方法和置信度 | 候选 claims 必须经过严格解码、摘录绑定与保守信号验证，才能持久化 |
| Assessment | 基于当前输入与确定性规则生成的判断 | 保留追加历史，区分确定结论、冲突、待核验与未知 |

近期官方投递证据且没有关闭信号，才允许判断 `OPEN`；明确官方关闭或截止时间已过，可以判断 `CLOSED`。信息不足、相互矛盾或仅有第三方证据需要核验；官方观察失败或过期会产生 `UNKNOWN`。**HTTP 200 本身不是开放证据。**

岗位状态、Eligibility、GoFit、偏好排名和投递状态相互独立。岗位关闭不会自动终止已经进行中的投递。

## 服务如何分工

```mermaid
flowchart TD
  UI[中文 UI / HTTP clients] --> API[Go API + JWT ownership]
  Host[External MCP Host] --> MCP[MCP stdio / 5 read tools]
  MCP --> Tools[Local business tools]
  API --> Tools
  API --> Watch[User-owned WatchTarget]
  Watch --> Scheduler[Worker 内周期 Scheduler]
  Scheduler --> DB
  Worker --> Discover[WATCH_CHECK / PostingDiscoverer]
  Discover --> Fanout[MySQL Outbox / WATCH_FETCH]
  Fanout --> Stream
  Worker --> Fetch[PostingFetcher / public sources]
  Fetch --> O[SourcePosting / Observation]
  API --> O
  Rules --> Radar[DailyDigest / Changes / Deadline Radar]
  Radar --> Inbox[MySQL Notification Inbox]
  API --> Preference[UserJobPreference / SAVED / IGNORED]
  O --> DB[(MySQL / authoritative data + Outbox)]
  DB --> SearchSync[Core Worker / search outbox]
  SearchSync --> Search[独立 Go Search / HTTP]
  API --> Search
  Search --> OS[(独立 OpenSearch 派生索引)]
  DB --> Publisher[Outbox publisher]
  Publisher --> Stream[(按类型与用户／系统归属隔离的 Redis 队列)]
  Stream --> Worker[独立有界执行池]
  Worker --> RPC[KanaRPC client / independent semaphore]
  Etcd[(etcd discovery)] -.-> RPC
  RPC --> A1[Analysis instance 1]
  RPC --> A2[Analysis instance 2]
  A1 --> Claims[Strict candidate claims]
  A2 --> Claims
  Claims --> DB
  DB --> Rules[Assessment task / deterministic rules]
  Rules --> DB
  Worker --> Retry[Retry ZSET / DLQ]
  Retry --> Stream
  Tools --> Agent[Bounded Grounded Agent]
  Agent --> Pending[PendingAction preview]
  Pending --> Confirm[Authenticated user confirmation]
  Confirm --> DB
  Tools --> RAG[MySQL chunks / BM25 + optional semantic vectors / RRF + rerank]
```

MySQL 事务与唯一约束承担业务正确性；Redis 承担队列、重试、限流、缓存及短期 Agent 状态。Analysis 通过 KanaRPC 返回候选 claims；可选 Search 通过版本化 HTTP 提供岗位全文检索，只拥有派生索引。主后端保留权限、决策与 CRUD 职责。同步、水位、回退和独立部署见 [Search 服务](search-service.md)。

### 岗位来源、归并与变化记录

- 来源为运营者登记的 `OFFICIAL`、`THIRD_PARTY` 或 `MANUAL`；可信度不是系统自动认证的。公共 API 导入只能创建用户自有的 `PRIVATE` manual source，不能自行赋予官方可信度。官方/系统来源为 `GLOBAL`，私人观察不会并入共享岗位雷达。
- 一个 canonical Job 可以对应多个 SourcePosting。先按来源与 external ID 匹配，再按来源内 URL 确定 posting 身份；结构化摘要仅用于寻找跨来源候选，还需核对公司、规范化标题、岗位类型、地点集合与来源身份。归并依据保存在 posting JSON 中，不做模糊或 LLM 归并。
- External ID、URL path/query 保留大小写，内容按精确字节处理。不确定的候选保持分离；没有稳定 external ID/URL 的手工文本发生变化时，可能形成新岗位。
- 连续成功观察的内容 hash 用于记录内容与结构化变化；每个 posting 取最新观察。新的观察、解析版本或解析结果只触发对应岗位的状态更新，同一岗位等待中的更新会合并。`job_assessment_schedule` 保存下一次实际状态变化的时间：可信截止时间、七天信息有效期等；Worker 平时每分钟只通过到期索引挑选待更新岗位，每批最多 100 个，有积压时逐批处理。状态更新不重新抓网页、不调用大模型；启用 WatchTarget 后，独立的周期检查仍会发现并重新抓取岗位。

## 招聘来源如何定期检查

首页提供今日新增、优先投递、7 天内截止、状态变化和未来 7 天面试；“稍后看 / 忽略”使用独立的 UserJobPreference，“准备投递 / 已投递”复用原 Application FSM。Agent 的四个雷达 read tools 只读当前事实，`watch_source` / `unwatch_source` 仍需要 Proposal → PendingAction → 显式确认 → MySQL receipt。

调度与来源链：

```text
WatchTarget (MySQL next_check_at)
  → SELECT due FOR UPDATE SKIP LOCKED
  → 同事务 schedule_version++ / next_check_at / Outbox(WATCH_CHECK)
  → Redis Stream → Worker → Discover
  → 同事务 fan-out Outbox(WATCH_FETCH) + discovery receipt
  → Redis Stream → bounded Fetch / existing source Lua rate limit
  → 锁定并重验 Watch generation → existing Ingest + per-posting SQL receipt
  → Observation → KanaRPC Analysis → Evidence → Rules → Assessment
  → Radar read models / idempotent Notification Inbox
```

抓取子任务默认进入独立 WATCH_FETCH 队列与执行池，每个岗位独立 timeout/retry；来源不增加服务或 RPC 边界。重复投递会收敛到同一 Observation；更改设置、暂停或删除后，旧 generation 不再写观察或调度状态。来源 429 至少等待一分钟再重试，5xx/timeout 使用已有 backoff，401/403/格式不兼容为本次任务的永久失败。访问失败、列表中消失或 HTTP 200 都不能直接决定 CLOSED/OPEN。


容量与展示：每个用户最多 100 个 Watch，每个 Watch 最多 500 个已发现/历史 posting；响应解压后最多 1 MiB，岗位正文最多 60,000 bytes。Radar 动态摘要最多 10,000 个可见 Job、500 个未完成 Interview、10,000 个窗口内 change，超限明确返回 `RADAR_CAPACITY`；不提供无界扫描。摘要计数完整，岗位各展示前 5 条、变化/面试各前 10 条，并标明 `truncated`。变化 feed 和 Inbox 最近 100 条，尚未提供历史翻页。最近窗口为滚动 24h/7d，截止窗口为滚动 3/7/14 天。状态变化只读取窗口内的 Assessment，通过现有 `(job_id, assessed_at)` 索引寻找每条记录的直接前序（同一时刻按 ID 区分），保留窗口外前序状态，不再对全部历史 JSON 做窗口排序。新增与内容变化先按放宽的日期范围缩小候选，再按原时区转换后的时刻精确核对。

推荐要求当前 OPEN、ELIGIBLE/CONDITIONAL、尚未投递或仅 PLANNED、未忽略；按现有规则评分降序及 Job ID 排序，使用与原 evaluation CAS 相同的计算函数。新岗位分数 ≥70 才发优先提醒。截止提醒以“deadline 语义版本 + D7/D3/D1”去重，进入当前最紧窗口时发一次；同一截止值连续重抓不重复，修改再改回也形成新版本。状态变化引用现有 Assessment 历史，内容/截止变化引用 JobChange；Notification 不承担 Job truth。通知后台每分钟轮转处理 10 个用户，仅站内提醒。

首页截止看板使用独立只读接口 `GET /api/radar/deadlines`，不受旧版完整 Radar 聚合的 500 岗限制。先按可见性、本人忽略与投递记录、可能的截止窗口筛选，再按岗位编号每批 100 个读取观察与证据，沿用当前解析代次、来源时区、七天有效期和状态核验；窗口候选最多 10,000 个。批量读取避免逐岗位查询，不读取求职资料或计算推荐分数。响应只含完整计数、最早 5 项和截断标记，日期型截止保留原始日期。完整截止列表使用同一筛选逻辑，登录后的库存列表和截止看板互不等待。动态摘要只在展开「岗位发现与变化」时读取，不阻塞待办或截止提醒。摘要在同一只读快照中按 Job ID 每批 100 个读取，个人资料只读取一次；每批读取观察、证据、偏好与投递状态后沿用现有规则计算，累计完整分类数量，仅保留各类最优 5 条。不再一次装入全部 RadarJob，超过 10,000 个可见岗位仍明确报错，不以局部计数冒充完整结果。提醒控制器只更新自己的 DOM 区域，避免轮询重建岗位列表和公司决策表单；隐藏页面时清除提醒定时器，返回时只在数据过期后立即补读，离开路由后移除可见性监听并丢弃迟到结果。

通知生成也分开读取最近一天的新岗位和未来七天的截止候选，各按 100 个岗位一批处理、最多 10,000 个候选；无关旧库存不会触发 500 岗容量错误。截止看板读取不会写通知，后台生成通知仍遵守原有语义版本去重，变化和未完成面试仍有各自容量限制。

## 消息失败与恢复

```text
MySQL Outbox → Redis Stream → Worker → KanaRPC Analysis
                                      ↓
                             Evidence → Assessment
```

整体采用 **at-least-once** 投递。Outbox 在崩溃后可能重复发布，业务结果通过数据库幂等收敛；SQL analysis result 与已完成 Assessment task key 是正确性边界。

- 默认 typed 模式将 `WATCH_CHECK`、`WATCH_FETCH`、`SOURCE_IMPORT`、`ANALYZE` 和 `ASSESS` 拆成用户与系统通道，分别使用 Redis ready 轮转、Stream 和执行池。旧共用 Stream 保留作迁移入口。RPC、模型和 embedding 工作仍有原有独立并发／限速边界，不意味着默认使用外部 embedding 服务。详见[可靠任务调度](task-scheduling.md)。
- PEL 通过 `XAUTOCLAIM` 恢复，idle time 大于任务 deadline。恢复在有界轮次间保留 stream/group cursor，每轮最多 32 次命令；每个串行 worker 只为一个空闲槽 claim 一条消息。后台执行没有持续延长 PEL idle 的租约，任务超过 claim idle 仍可能再次被领取；generation／回执限制写入，新增 SQL 调用凭据阻止未知分析自动重复调用。
- 临时失败按 2s、4s、8s 等指数退避并加入 jitter。Lua 将 retry/DLQ 状态记录与 ACK 放在同一操作中；另一个脚本将到期 retry 原子转回 typed ready（legacy 模式转回原 Stream），目标满时保留原任务。永久 schema/auth/validation 错误直接进入 DLQ。终态分析失败写入 MySQL，并重新评估为未知。
- 测试覆盖数据库已提交、ACK 前崩溃的场景。异常 envelope 被保存为净化后的 DLQ 记录；`poison` hash 保留有界诊断、digest、时间、consumer 与可恢复的关联 ID，不保留完整畸形原始 payload。隔离失败则继续留在 PEL。
- 失败转移先检查 Redis key 类型/group，写 retry/DLQ 后写 v2 completion marker，最后 ACK。Lua 运行时错误不会回滚已发生的写入，因此使用稳定转移字节支持重跑，不信任旧的提前完成 marker。

DLQ 由本地 operator CLI 查看和主动 redrive：

```sh
go run ./cmd/dlq
go run ./cmd/dlq -redrive TASK_ID
```

滑动窗口限流使用 Redis server time 和原子 ZSET/Lua，包含来源独立 key 及全局 LLM/embedding key。当前使用 standalone Redis，多 key Lua 不支持 Redis Cluster slot 分布。typed Stream 完成可靠交接即删除传输消息；旧 Stream 采用保守的已确认历史清理。完成任务与 Outbox 历史仍需人工保留策略，尚无自动归档。

## Analysis 服务与 KanaRPC

KanaRPC 是本项目维护者基于上游 KamaRPC-Go 历史持续实现与维护的**自研轻量 RPC / 服务治理框架**，属于学习与工程实践项目；来源与许可见 [KanaRPC 仓库](https://github.com/KanaDoodle/KanaRPC-Go) 和 [dependency audit](dependency-audit.md)。CampusTrace Analysis Service 是它的真实业务消费者。

CampusTrace 是独立 module `github.com/KanaDoodle/CampusTrace`，固定依赖已发布的 `github.com/KanaDoodle/KanaRPC-Go v0.1.0`，仅导入公开的 `/rpc` facade。`go.mod` 无 replace，正常构建使用 `GOWORK=off`，无需 sibling checkout。Transport、codec、pool 与 breaker 实现类型留在 KanaRPC internal 内。v0.x facade 尚不承诺长期 API 稳定性。

两个 Analysis 实例注册到 etcd。已知 breaker-open 实例在负载均衡前被排除；admission race 下每个已发现地址最多尝试一次选择，远程业务方法不自动重放。本地取消不计入 breaker 失败，后端 deadline 仍计入。

KeepAlive/lease 丢失会降低 readiness，并以有上限的指数退避和 jitter 创建新 lease、恢复注册。`/healthz`、`/readyz` 使用 `ANALYSIS_HEALTH_ADDR`，本地两实例默认为 `127.0.0.1:19191` / `19192`；测试包含真实 lease revoke 与关闭 KeepAlive channel。

RPC wire protocol 没有提前远程取消信号；CampusTrace 传递显式 deadline 和 IDs，服务端工作到 deadline 或服务关闭时停止。这些实现边界不构成对成熟生产级 RPC 框架的性能或能力优势声明。

可选本地联合开发使用 `make dev-workspace` 生成 ignored `go.work`。`make verify-boundary` 在关闭 workspace 后验证已发布依赖边界，不能替代远程 clean clone 验收。

## Agent、检索与 MCP

### Grounded Agent：模型选工具，事实来自成功的工具观察

默认 `DemoModel` 是确定性的离线自然语言路由器；可在网页「模型设置」中选择外部模型，或由部署者通过 `LLM_URL`、`LLM_API_KEY`、`LLM_MODEL` 提供服务器默认的 OpenAI-compatible chat endpoint。普通测试使用 scripted models，不需要外部凭据。

`make eval` 还会运行 [Agent 评测基线](agent-evaluation.md)：24 例运行时边界检查和 43 例合成中文求职问题，逐项报告工具选择、参数、依据与拒答、调用次数及延迟。离线评测无需密钥或用户数据；可明确传入外部模型配置，在同一批合成问题上单独评测，不能把离线通过率当作真实模型准确率。

「更多工具 → 求职问答」现在显示由成功工具观察确定性生成的简短回答，原始结构化记录折叠保留供核对。岗位雷达选择同一公司 2–8 个岗位后，可点「问 Agent」带入岗位编号。`get_match_result`、`compare_company_jobs` 复用岗位雷达相同的当前资料、岗位文字、模型身份与本轮额外姓名遮盖，只读取已有的深度匹配并返回有界脱敏摘要；待分析或已过期的结果不会显示旧分数或充当推荐。按公司全量比较最多读取既有的 200 个岗位，Agent 回传其中最多 8 个摘要并标明总数与截断；已有的同分并列、待更新和资料不足规则保持不变。`get_match_tasks` 只查询最近任务及失败阶段，不继续或重试付费分析。外部模型的本次求职问答仍会产生其自身的 API 调用；上述读取不会额外启动岗位深度分析。独立 stdio MCP 也提供匹配、公司比较、分析进度、待办和练习查询，共十个只读工具。

默认预算最多 4 次模型调用、8 次工具执行，总 deadline 35s、单工具 timeout 8s，时间限制可配置。运行时校验未知字段、尾随 JSON、null、必填项、枚举、范围和大小；最后一步提案只记录 trace，不执行。

最终业务事实由成功的工具 observations 确定性渲染，**模型自由文本不会直接作为事实答案展示**。项目事实标记为 `IMPLEMENTED` / `LIMITATION` / `PLANNED`，只有已核验事实支持能力声明；检索内容中的指令不能任意调用工具或绕过确认。

写工具只保存归属用户、TTL 10 分钟的 PendingAction。`POST /agent/actions/{id}/confirm` 必须携带 `{"confirm":true}`，随后重新验证当前状态和版本。已完成的 MySQL receipt 按 action ID 与认证用户读取，即使 Redis pending 数据缺失或不可用，仍能重放完成结果；未完成时照常校验 owner/TTL/状态/版本，并区分数据不存在与后端错误。并发或重复确认通过数据库 receipt 幂等处理，模型没有确认工具。

会话按用户和 session 隔离，最多 6 个完整 turn / 32KB，TTL 30 分钟并带乐观版本检查；过期的并发 writer 可能跳过保存。失败 trace 净化后保留 24 小时，Redis 故障可能导致 trace 无法持久化。会话内容不属于业务 Evidence。

输出预算默认为：`AGENT_MAX_TOOL_RESULT_BYTES=32768`、`AGENT_MAX_FACTS_BYTES=98304`、`AGENT_MAX_ANSWER_BYTES=32768`、`AGENT_MAX_FINAL_BYTES=163840`。非正值回到默认；final 最小有效预算为 512 bytes，包含 JSON 与 SSE framing。超限工具结果不进入 Facts，无法容纳的输出以 `OUTPUT_LIMIT` 结束，不伪装成完整答案。同一步重复 call ID 只执行一次；验证后的相同规范化参数复用首次结果与 pending action，后续模型步骤仍可重新读取。

### 任务执行与资料客户端

常用 Skills 使用审核过的固定查询计划、MySQL 逐步检查点和带令牌的运行租约。问答按问题选择工具和相关记忆，临时只读网络失败最多重试一次；公共 HTTPS MCP 客户端只能读取用户选定的文本资源。模型分工和预算在每次请求前检查，usage 与估计分开。招聘变化使用事务事件与持久游标生成站内待办，不自动触发分析或投递。使用方法和具体限制见 [求职助手说明](agent-harness.md)。

### RAG：关键词、语义检索与可选重排序

默认 BM25 在本地检索当前账号的材料，中文 bigram 保留基础词法支持。用户可单独配置外部 Embedding 服务，预览确认材料后分批建立语义索引；两路按 RRF 合并，再可选对最多 20 个候选片段重排序，默认 Top5。旧 128 维 lexical-hash 字段保留兼容，不再参与新关键词排名。

材料和模型版本隔离的向量仍存在 MySQL，没有新增 ANN 或独立向量数据库。每账号最多 10,000 段；索引输入与保存均有身份核对、账号租约和原子提交，删除会清理对应向量。模型失败明确显示回退，付费检索不自动重试。密钥留在浏览器、只随本次请求临时传递。完整用法、容量、评测与边界见 [学习资料检索](knowledge-retrieval.md)。

### SSE 与 MCP

`POST /agent/decide` 返回最终结果；`/agent/stream` 通过有界直接 SSE 写入发送 run_start、model_start/end、tool_start/result、final 和 error。断开连接取消 Context；不支持 token streaming、重放或断线续传。

独立 stdio MCP server 使用官方 Go MCP SDK `v1.7.0`，提供十个业务只读工具：`search_jobs`、`get_job`、`get_job_evidence`、`get_job_eligibility`、`search_knowledge`、`get_match_result`、`compare_company_jobs`、`get_match_tasks`、`get_agent_todos`、`get_practice_runs`。stdout 仅输出协议，日志走 stderr；本地 Agent 工具不经 MCP 绕行。

MCP/Agent 查询复用相同输入的未过期 Assessment，或计算当前结果而不插入 Eligibility/Ranking/history；Redis 知识限流计数仍可能变化。显式/后台 Assessment 通过 input-identity CAS 与相同输入去重持久化。输入身份包含 profile revision、当前 Observation/generation、岗位元数据及规则/权重版本；时间相关缓存在一分钟内或下一个 deadline/freshness 边界过期。

## 维护命令与导入

各二进制仍可用环境变量独立启动，参见 [配置示例](../configs/local.env.example)。示例是文档，DSN 含 `&` 时不能直接 shell source，应使用正确引用的 export。**只有需要虚构演示数据时才显式执行 `make seed`**；演示账户为 `demo@campustrace.local` / `Synthetic-demo-2027`。

手工导入与 operator 来源登记：

```sh
go run ./cmd/ingest -file testdata/import.json
go run ./cmd/ingest -format csv -file testdata/import.csv
go run ./cmd/ingest -register-source -source company-careers -name 'Example careers' -type OFFICIAL -trust OFFICIAL
```

UI/API 可导入公共 URL；验证码、登录要求和 403 如实记录，不绕过。HTTP fetch 拒绝 private/loopback/link-local 地址，涵盖重定向与 DNS 解析。仅处理显式 text/HTML content type；解压后超过 1 MiB、不支持的编码或二进制类型返回 `PARSE_ERROR`，不会把部分文本当完整观察。

使用 MCP 时先通过 `/auth/login` 获取 JWT，设置 `MCP_TOKEN`、相同的 `JWT_SECRET` 与数据库配置，再执行 `go run ./cmd/mcp-server`。Token 仅在进程启动时验证；改变身份或撤销访问需要重启 stdio server，1.0 不执行会话中的 JWT 过期/撤销检查。HTTP 接口详见 [API 文档](api.md)。

### 现有数据迁移与处理版本

启动迁移串行化、可重启，保留已有 IDs、原文和历史。旧 manual 数据没有可靠 owner 时，关联岗位（包括混合来源岗位）隔离为无归属用户的 private，需 operator 核查来源后分配 ownership 或重建公开岗位；不猜测归属，不自动拆分已错误合并的历史岗位。迁移前停止旧 writer，不支持新旧二进制混跑。

新 manual source 默认 `Asia/Shanghai`，operator 可用 `-timezone`、`-owner` 指定。纯日期截止时间在来源时区的次日零点到期；带 offset 的时间戳保留实际时刻。稳定 posting 的新元数据更新标题/类型/地点，旧观察不能覆盖。

SQL receipt 与 Redis cache 使用完整 `ProcessingVersion`：semantic/model/prompt 配置、实现 parser、来源 adapter/parser 和 Observation parser 版本。更换模型或 prompt 时更新 `ANALYSIS_VERSION`；parser 变化自动使旧 receipt 失效。`BindAnalysis` 首次调度新身份时分配 numeric generation，设置 desired/active generation 并持久绑定任务；已知旧身份重放不会重新激活，也不按版本字符串排序。只有 active generation 可成为 current，旧结果仍保留历史；active receipt 重放会原子校正指针和派生 apply/deadline 字段。desired generation 等待期间，旧代 Evidence 不参与当前规则。

部署需要显式调度目标实现，不能从版本名字自动推断发布先后；重做或回滚也需新的 processing configuration identity。`cache-v2`、`claims-v3-semantics`、完整 `processing-v3-*` 身份和精确文本摘要隔离旧缓存/receipt，即便旧环境仍设 `claims-v1` 也执行有效 semantic version；自定义模型/prompt 版本经命名空间与 hash 限制 SQL 长度。未触及的旧 Observation 需要显式 reanalysis 或新观察；没有全历史迁移或版本切换 UI。

## 完整检查与复现

```sh
export GOWORK=off
go test -count=1 ./...
go test -race -count=1 ./...
go vet ./...
go build ./...
node --test web/*.test.cjs
make verify-boundary
./scripts/verify-radar.sh   # 独立临时库：全部真实集成 + old schema upgrade
RADAR_RACE=1 ./scripts/verify-radar.sh # 同样覆盖真实 MySQL/Redis/etcd/KanaRPC
make integration           # 兼容旧命令；复用 campustrace_test，历史任务可能影响测试
CAMPUS_INTEGRATION=1 go test -race -count=1 -v ./internal/integration
make eval                  # 24 个 scripted runtime contract cases
./scripts/benchmark.sh --jobs 1000 --requests 40 --concurrency 4 # 隔离库，无模型调用
make loadgen               # 100 个 synthetic Observation，经实际 Worker/KanaRPC
```

前端测试需 Node.js。普通测试未设置 `CAMPUS_INTEGRATION=1` 时会明确跳过 integration；最终验收也要启用真实依赖测试。`MYSQL_TEST_DSN` 可指定独立测试库，测试会保留 synthetic 数据；Make target 创建测试库需要本地 operator 权限，测试本身使用非 root 的 `campus` 账户。

Scripted eval 不代表真实模型准确率，synthetic loadgen 不代表线上吞吐指标。远程可复现性需在开发 workspace 外真实 clone，使用 `GOWORK=off`、全新 `GOPATH` / `GOMODCACHE`，运行 download/test/race/vet/build、前端测试以及 Quick Start / Demo；单纯本地测量不能替代此流程。

## 当前限制

- **来源与抓取**：parser/HTTP adapter 能力有限；不支持 JS 渲染、登录自动化或反爬绕过。来源 trust 为 operator-attested，不验证域名所有权或第三方平台真实性。不提供自动岗位投递。
- **岗位归并**：精确策略有意保守，包含初始内容 fingerprint；稳定 external ID/URL 维持 posting 关联，但文本变化的跨来源别名可能保持分离。
- **数据模型与管理**：JSON-backed SQL aggregates 配合 relational ownership/FK/unique keys，优先满足个人规模的实现清晰度；没有 schema downgrade、文档 revisions、丰富分页或多租户管理角色。
- **历史与时效**：历史 Evidence 保留，显式调度决定 active generation；旧结果不能覆盖 current，未重新处理的 legacy Observation 需要显式 reanalysis。没有全历史版本选择界面；旧官方矛盾保守产生核验/未知，freshness 状态缓存可能滞后一小时；只对已启用且适配器支持的关注源自动重抓。
- **RPC**：KanaRPC 为教育性 v0.x 框架，API 稳定性及提前远程取消存在上述限制。
- **Agent 与检索**：自由生成事实回答被刻意限制。可选 live provider 未完成效果评估；可选语义 Embedding 与重排序已接入协议，但未用真实账号材料和真实模型评估检索质量。弱点提取依赖经过验证的显式输入，非 LLM extractor。RAG 容量、重复导入和文档更新/删除限制见上文。
- **会话与认证**：SSE 无 replay/reconnect；MCP 认证仅在启动时进行；没有邮箱验证、密码重置或撤销服务。Redis 故障可影响短期状态与 trace 保存。
- **队列与运维**：没有自动队列/历史归档或 Redis Cluster 支持；DLQ 仅通过 operator CLI 管理。进程内计数重启重置；队列和共享池另提供实时聚合指标。API 与 Worker 保留 `/metrics` JSON 和 `/metrics/prometheus`，任务阶段事件保存在 MySQL；可选 OpenTelemetry / Prometheus / Grafana / Tempo 连接本地服务追踪并提供面板与本地告警，不包含外部告警投递或生产高可用，见[监控与排障](operations.md#可选的完整观测栈)。
- **UI**：中文优先，使用结构化资料与复盘表单；岗位雷达最多 10,000 条、每页 50 条；独立普通搜索最多 100 条。没有使用前端框架。
