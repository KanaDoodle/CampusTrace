package rpc_test

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/rpc"
)

func streamingServer(t testing.TB, capacity int, register func(*rpc.Server)) (*rpc.Server, *rpc.Client) {
	t.Helper()
	s, err := rpc.NewServer(rpc.ServerConfig{Address: "127.0.0.1:0", MaxConcurrentRequests: capacity})
	if err != nil {
		t.Fatal(err)
	}
	s.Register("demo", &Handler{})
	register(s)
	done := make(chan error, 1)
	go func() { done <- s.Start() }()
	until := time.Now().Add(3 * time.Second)
	for s.Addr() == nil && time.Now().Before(until) {
		time.Sleep(time.Millisecond)
	}
	if s.Addr() == nil {
		t.Fatal("server failed to listen")
	}
	c, err := rpc.NewDirectClient(s.Addr().String(), rpc.ClientConfig{Timeout: 5 * time.Second, StreamWindow: 2})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		c.Close()
		s.Shutdown()
		if err := <-done; err != nil {
			t.Error(err)
		}
	})
	return s, c
}

func mustRegister(t testing.TB, s *rpc.Server, method string, h rpc.StreamHandler) {
	t.Helper()
	if err := s.RegisterStream("demo", method, h); err != nil {
		t.Fatal(err)
	}
}
func awaitSignal(t *testing.T, ch <-chan struct{}, label string) {
	t.Helper()
	select {
	case <-ch:
	case <-time.After(3 * time.Second):
		t.Fatal("timed out: " + label)
	}
}

func TestStreamMultiplexesOrderedChunksAndUnary(t *testing.T) {
	_, c := streamingServer(t, 4, func(s *rpc.Server) {
		mustRegister(t, s, "Items", func(ctx context.Context, req json.RawMessage, out *rpc.ServerStream) error {
			for i := 0; i < 20; i++ {
				if err := out.Send(Request{Value: i}); err != nil {
					return err
				}
			}
			return nil
		})
		mustRegister(t, s, "Empty", func(context.Context, json.RawMessage, *rpc.ServerStream) error { return nil })
	})
	var workers sync.WaitGroup
	for n := 0; n < 2; n++ {
		workers.Add(1)
		go func() {
			defer workers.Done()
			stream, err := c.InvokeStream(context.Background(), "demo", "Items", struct{}{})
			if err != nil {
				t.Error(err)
				return
			}
			defer stream.Close()
			for i := 0; i < 20; i++ {
				var out Request
				if err := stream.Recv(&out); err != nil || out.Value != i {
					t.Errorf("chunk %d: %+v %v", i, out, err)
					return
				}
			}
			var out Request
			if err := stream.Recv(&out); err != io.EOF {
				t.Errorf("end: %v", err)
			}
		}()
	}
	var reply Request
	if err := c.Invoke(context.Background(), "demo", "Echo", &Request{42}, &reply); err != nil || reply.Value != 42 {
		t.Fatal(reply, err)
	}
	workers.Wait()
	// A fast empty stream may finish before OpenStream's caller is scheduled.
	for i := 0; i < 20; i++ {
		stream, err := c.InvokeStream(context.Background(), "demo", "Empty", struct{}{})
		if err != nil {
			t.Fatal(err)
		}
		var out any
		if err := stream.Recv(&out); err != io.EOF {
			t.Fatal(err)
		}
	}
}

func TestSlowStreamBackpressureDoesNotBlockOtherCalls(t *testing.T) {
	twoSent, thirdAttempt, thirdSent, stopped := make(chan struct{}), make(chan struct{}), make(chan struct{}), make(chan struct{})
	_, c := streamingServer(t, 3, func(s *rpc.Server) {
		mustRegister(t, s, "Slow", func(ctx context.Context, _ json.RawMessage, out *rpc.ServerStream) error {
			defer close(stopped)
			for i := 0; i < 2; i++ {
				if err := out.Send(i); err != nil {
					return err
				}
			}
			close(twoSent)
			close(thirdAttempt)
			if err := out.Send(2); err != nil {
				return err
			}
			close(thirdSent)
			<-ctx.Done()
			return ctx.Err()
		})
		mustRegister(t, s, "Fast", func(_ context.Context, _ json.RawMessage, out *rpc.ServerStream) error { return out.Send("fast") })
	})
	slow, err := c.InvokeStream(context.Background(), "demo", "Slow", struct{}{})
	if err != nil {
		t.Fatal(err)
	}
	defer slow.Close()
	awaitSignal(t, twoSent, "initial window")
	awaitSignal(t, thirdAttempt, "blocked send")
	select {
	case <-thirdSent:
		t.Fatal("sender exceeded receive window")
	case <-time.After(30 * time.Millisecond):
	}
	fast, err := c.InvokeStream(context.Background(), "demo", "Fast", struct{}{})
	if err != nil {
		t.Fatal(err)
	}
	var text string
	if err := fast.Recv(&text); err != nil || text != "fast" {
		t.Fatal(text, err)
	}
	_ = fast.Close()
	var reply Request
	if err := c.Invoke(context.Background(), "demo", "Echo", &Request{7}, &reply); err != nil || reply.Value != 7 {
		t.Fatal(reply, err)
	}
	var first int
	if err := slow.Recv(&first); err != nil || first != 0 {
		t.Fatal(first, err)
	}
	awaitSignal(t, thirdSent, "credit after consumption")
	_ = slow.Close()
	awaitSignal(t, stopped, "remote cancellation")
	if err := slow.Recv(&first); !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
}

func TestCancellationWorksAtFullServerCapacity(t *testing.T) {
	started, stopped := make(chan struct{}), make(chan struct{})
	_, c := streamingServer(t, 1, func(s *rpc.Server) {
		mustRegister(t, s, "Wait", func(ctx context.Context, _ json.RawMessage, _ *rpc.ServerStream) error {
			close(started)
			<-ctx.Done()
			close(stopped)
			return ctx.Err()
		})
	})
	stream, err := c.InvokeStream(context.Background(), "demo", "Wait", struct{}{})
	if err != nil {
		t.Fatal(err)
	}
	awaitSignal(t, started, "active stream")
	_, err = c.InvokeStream(context.Background(), "demo", "Wait", struct{}{})
	var remote *rpc.StreamError
	if !errors.As(err, &remote) || remote.Code != "resource_exhausted" {
		t.Fatalf("overload: %v", err)
	}
	_ = stream.Close()
	awaitSignal(t, stopped, "cancel while full")
	var out Request
	until := time.Now().Add(time.Second)
	for {
		err = c.Invoke(context.Background(), "demo", "Echo", &Request{9}, &out)
		if err == nil {
			break
		}
		if time.Now().After(until) {
			t.Fatal(err)
		}
		time.Sleep(time.Millisecond)
	}
	if out.Value != 9 {
		t.Fatal(out)
	}
}

func TestStreamTerminalErrorAfterBufferedData(t *testing.T) {
	_, c := streamingServer(t, 2, func(s *rpc.Server) {
		mustRegister(t, s, "Error", func(_ context.Context, _ json.RawMessage, out *rpc.ServerStream) error {
			if err := out.Send("partial"); err != nil {
				return err
			}
			return errors.New("test failure")
		})
	})
	stream, err := c.InvokeStream(context.Background(), "demo", "Error", struct{}{})
	if err != nil {
		t.Fatal(err)
	}
	var value string
	if err := stream.Recv(&value); err != nil || value != "partial" {
		t.Fatal(value, err)
	}
	var remote *rpc.StreamError
	if err := stream.Recv(&value); !errors.As(err, &remote) || remote.Code != "internal" {
		t.Fatal(err)
	}
}

func TestStreamContextDeadlineDisconnectAndShutdown(t *testing.T) {
	for _, mode := range []string{"deadline", "client_close", "server_shutdown"} {
		t.Run(mode, func(t *testing.T) {
			stopped := make(chan struct{})
			s, c := streamingServer(t, 2, func(s *rpc.Server) {
				mustRegister(t, s, "Wait", func(ctx context.Context, _ json.RawMessage, _ *rpc.ServerStream) error {
					<-ctx.Done()
					close(stopped)
					return ctx.Err()
				})
			})
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			if mode == "deadline" {
				ctx, cancel = context.WithTimeout(ctx, 80*time.Millisecond)
				defer cancel()
			}
			stream, err := c.InvokeStream(ctx, "demo", "Wait", struct{}{})
			if err != nil {
				t.Fatal(err)
			}
			switch mode {
			case "client_close":
				c.Close()
			case "server_shutdown":
				s.Shutdown()
			}
			var value any
			err = stream.Recv(&value)
			if err == nil || err == io.EOF {
				t.Fatalf("missing terminal failure: %v", err)
			}
			if mode == "deadline" && !errors.Is(err, context.DeadlineExceeded) {
				t.Fatal(err)
			}
			awaitSignal(t, stopped, "handler exit")
		})
	}
}

func TestStreamValidation(t *testing.T) {
	if _, err := rpc.NewDirectClient("127.0.0.1:1", rpc.ClientConfig{StreamWindow: 33}); err == nil {
		t.Fatal("invalid window accepted")
	}
	s, err := rpc.NewServer(rpc.ServerConfig{Address: "127.0.0.1:0"})
	if err != nil {
		t.Fatal(err)
	}
	defer s.Shutdown()
	if err := s.RegisterStream("demo", "Missing", nil); err == nil {
		t.Fatal("nil handler accepted")
	}
}

func TestStreamViaEtcdDiscovery(t *testing.T) {
	endpoint := os.Getenv("KANARPC_TEST_ETCD")
	if endpoint == "" {
		t.Skip("requires isolated etcd")
	}
	name := fmt.Sprintf("stream-discovery-%d", time.Now().UnixNano())
	s, _ := streamingServer(t, 2, func(s *rpc.Server) {
		if err := s.RegisterStream(name, "Echo", func(_ context.Context, raw json.RawMessage, out *rpc.ServerStream) error { return out.Send(raw) }); err != nil {
			t.Fatal(err)
		}
	})
	r, err := rpc.NewRegistry([]string{endpoint})
	if err != nil {
		t.Fatal(err)
	}
	defer r.Close()
	if err := r.Register(name, s.Addr().String(), 5); err != nil {
		t.Fatal(err)
	}
	c, err := rpc.NewClient(r, rpc.ClientConfig{Timeout: 3 * time.Second})
	if err != nil {
		t.Fatal(err)
	}
	defer c.Close()
	stream, err := c.InvokeStream(context.Background(), name, "Echo", Request{Value: 42})
	if err != nil {
		t.Fatal(err)
	}
	defer stream.Close()
	var out Request
	if err := stream.Recv(&out); err != nil || out.Value != 42 {
		t.Fatal(out, err)
	}
	if err := stream.Recv(&out); err != io.EOF {
		t.Fatal(err)
	}
}

func BenchmarkStreamRoundTrip(b *testing.B) {
	payload := strings.Repeat("x", 256)
	_, c := streamingServer(b, 4, func(s *rpc.Server) {
		mustRegister(b, s, "Bench", func(_ context.Context, _ json.RawMessage, out *rpc.ServerStream) error {
			for i := 0; i < 32; i++ {
				if err := out.Send(payload); err != nil {
					return err
				}
			}
			return nil
		})
	})
	b.ReportAllocs()
	b.SetBytes(32 * 256)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		s, err := c.InvokeStream(context.Background(), "demo", "Bench", struct{}{})
		if err != nil {
			b.Fatal(err)
		}
		for j := 0; j < 32; j++ {
			var out string
			if err := s.Recv(&out); err != nil || out != payload {
				b.Fatal(err)
			}
		}
		var out string
		if err := s.Recv(&out); err != io.EOF {
			b.Fatal(err)
		}
	}
}

func TestConcurrentStreamCancellationAndCompletion(t *testing.T) {
	release := make(chan struct{})
	_, c := streamingServer(t, 32, func(s *rpc.Server) {
		mustRegister(t, s, "Race", func(ctx context.Context, raw json.RawMessage, out *rpc.ServerStream) error {
			if err := out.Send(raw); err != nil {
				return err
			}
			select {
			case <-release:
				return nil
			case <-ctx.Done():
				return ctx.Err()
			}
		})
	})
	streams := make([]*rpc.ClientStream, 16)
	for i := range streams {
		var err error
		streams[i], err = c.InvokeStream(context.Background(), "demo", "Race", Request{Value: i})
		if err != nil {
			t.Fatal(err)
		}
	}
	var workers sync.WaitGroup
	for _, stream := range streams {
		workers.Add(1)
		go func(stream *rpc.ClientStream) {
			defer workers.Done()
			<-release
			_ = stream.Close()
			var out Request
			if err := stream.Recv(&out); !errors.Is(err, context.Canceled) {
				t.Errorf("local close terminal: %v", err)
			}
		}(stream)
	}
	close(release)
	workers.Wait()
	var out Request
	if err := c.Invoke(context.Background(), "demo", "Echo", Request{Value: 42}, &out); err != nil || out.Value != 42 {
		t.Fatal(out, err)
	}
}
