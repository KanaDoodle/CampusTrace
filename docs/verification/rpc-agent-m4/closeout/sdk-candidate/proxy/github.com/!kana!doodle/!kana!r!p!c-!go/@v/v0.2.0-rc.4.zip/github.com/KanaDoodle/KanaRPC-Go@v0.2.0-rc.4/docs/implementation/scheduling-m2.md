# M2：token 工作量调度与延迟目标治理

日期：2026-10-30。以前一轮尚未提交的 M1 工作区为基线；备份为 `/private/tmp/kanarpc-before-m2.tgz` 与 `.patch`，不重置已有修改。

## 分阶段实施与验收

1. **工作量与路由核心**：输入计数来自上游 tokenizer API；输出使用 max_tokens 预留上界。每实例配置模型/引擎 profile/tokenizer ID 与校准速率；路由对照 RR、最少在途、token 工作量。状态有 TTL，不可达即排除，陈旧状态默认拒绝，可显式选择只看本地预留的降级策略。单元测试和离散事件模拟复用实际路由实现。
2. **接纳与排队**：交互/批量分别限制执行数、执行 token 预留、排队数及排队 token；类内 FIFO，固定保留容量避免另一类饥饿。取消/超时/队满/关闭必须原子释放；已过排队截止时间的请求不能开始执行。以 shared FIFO 作为对照，明确隔离牺牲空闲借用的取舍。
3. **Worker 与网关接入**：Worker 增独立 HTTP 状态/分词控制入口，避免 RPC 执行满载时失去观测。网关做计数→排队→预留实例→转发 M1 流，返回决策、片段、汇总事件；首文本目标使用入口到网关观察到文本的时间，并有执行总预算。一次业务发送后不重放。接纳拒绝不能误触发后端熔断。
4. **对照与交付**：固定到达轨迹、多个种子、长短混合与实例减速；统计全部 offered、成功/拒绝/超时、TTFT/输出间隔、目标内完成和批量进度。另跑真实 TCP/HTTP fixture 和独立进程链路、普通/race/vet。真实 vLLM opt-in 明确 SKIP，模拟数据不写成真实推理收益。

## 部署与语义约束

- 这是**单网关进程**内的原子接纳与预留，不是跨网关的全局配额；多实例全局治理后续另做。
- worker 池配置同时包含 RPC 地址、admin URL 和校准 profile；本阶段不是动态集群成员管理。
- token 计数仅对所配置 tokenizer/chat template 有效，profile ID 由部署者正确配置；输出预留不是预测实际会生成多少 token。
- TTFT 成本模型是可校准的近似，不代表 vLLM continuous batching 的精确预测；真实性能必须另验。
- adapter 的 active / 等待首文本是其 HTTP 调用视角，不冒充引擎 GPU running/waiting/KV 指标。
- 不加入 KV 缓存路由、自动付费重试、持久任务恢复或抢占已开始的模型执行。

## 请求生命周期

```mermaid
sequenceDiagram
    participant C as 调用者
    participant G as Gateway
    participant A as 本地 Admission
    participant W as Worker
    participant V as vLLM HTTP
    G->>W: 独立 HTTP /status，周期刷新
    C->>G: InvokeStream(模型 scheduled 服务)
    G->>W: HTTP /tokenize(chat)
    W->>V: 根路径 /tokenize，含 chat template
    V-->>G: 精确 count（经 Worker）
    G->>A: 按类、数量/token、排队截止时间接纳
    A-->>G: Permit 或结构化拒绝
    G->>G: 状态快照 ∪ 本地预留 → 预测 TTFT → 选址/原子预留
    G-->>C: scheduled 决策
    G->>W: 一次 InvokeStream（随机 invocation ID）
    W->>V: 复核 tokenizer 后 POST 流式生成
    V-->>W: SSE text / usage / DONE
    W-->>G: ChatChunk
    G-->>C: chunk / 最终 summary
    Note over C,V: 取消、首文本超时、总预算、断连或关闭：取消 HTTP，归还 Permit/预留
```

tokenizer 调用当前做两次：网关选址前计数、被选 worker 生成前计数。此成本纳入网关 TTFT；没有声称零额外开销。池内 tokenizer/chat-template ID 必须一致，ID 是部署约定，不是自动指纹或认证。

## 路由与配额

`work = (prompt_tokens, max_tokens)`。输出使用预留上界，不猜测实际生成长度。对于可达、身份匹配、状态新鲜且有容量的实例：

```text
predicted_TTFT = base_TTFT
  + (本请求 prompt + 尚无首文本的在途 prompt) / calibrated_prefill_rate
  + 在途 max_tokens 预留总和 / calibrated_decode_rate
token_work_score = predicted_TTFT + 本请求 max_tokens / calibrated_decode_rate
```

三种策略都应用同一容量/预测 TTFT 过滤。RR 在候选中轮换，least_in_flight 按有效请求数，token_work 按上述 score。`invocation_id` 将 worker 快照与本地预留做集合并集，避免同一次调用重复计算；完成记录只抑制已经观察到的旧快照，晚到但此前未见的快照可能短暂高估负载，等待刷新消除。不会据此抹去其他来源调用。

每类固定的 running / running_tokens / queued / queued_tokens 四个上限；类内 FIFO，队首超时或取消立即剔除。交互和批量各保留执行容量，不借用空闲名额。批量进度依赖有限的服务时间/总执行预算，不承诺跨租户公平或对已执行任务抢占。`shared_fifo=true` 仅提供显式对照/可选配置，共享的两个视图引用同一桶，不能把计数相加。

状态默认 TTL 2s，使用本机接收时间。不可达或身份不匹配排除；陈旧默认 fail closed。`allow_local_fallback=true` 只允许曾经健康、但状态过期的实例依据本地预留降级，无法看见别的网关负载，且不会使已确认不可达的实例复活。库使用者需主动 `Refresh` 或配置 `RefreshInterval`；CLI 默认每 250ms 刷新。

## API 与时间语义

注册服务名为 `gateway.ServiceForModel(model)`，与 M1 原始模型服务隔离。方法仍为 `Chat`：

```go
request := gateway.Request{
    Chat: vllm.ChatRequest{
        Messages: []vllm.Message{{Role: "user", Content: "你好"}},
        MaxTokens: 64,
    },
    Class: scheduler.Interactive,
    QueueBudgetMS: 200,
    TargetTTFTMS: 500,
}
stream, err := client.InvokeStream(ctx, gateway.ServiceForModel(model), vllm.MethodName, request)
// Recv(&gateway.Event{}): scheduled → chunk... → summary → io.EOF
```

- 排队截止时间从网关 handler 入口起算，包含分词时间，不能因“尚未正式入队”重置预算。QueueBudgetMS 只能收紧服务端排队上限。
- TargetTTFTMS 可在 1..30000ms 内指定；缺省使用交互 500ms / 批量 5s。这是内部调用方声明的目标，不是经过认证的等级。总执行预算仍由网关配置限制（默认 1 分钟，最多 10 分钟）。
- `gateway_ttft_ns` 从网关入口到网关收到首段非空 content/reasoning_content；包含计数、排队和 worker 分词，但不含客户端拨号及网关到客户端传输。CLI `first_text_ms` 另测客户端观察时间。
- 首文本预算耗尽时取消上游，返回 `slo_exceeded`；预测无法满足时提前 `slo_unachievable`；队满/token 满 `resource_exhausted`；排队过期 `queue_timeout`；不可用/陈旧 `unavailable`。这些接纳/预算拒绝对客户端熔断统计中性；真实网络、后端错误仍影响熔断。
- 有首文本后停止首文本计时器，后续仍受总执行预算约束。记录的是 **text-event gap**，不是逐 token ITL；没有实现输出间隔 SLO。
- summary 仅在完整 EOF 成功后发送，包含最终 usage（上游提供时）、网关 TTFT、最大文本事件间隔与耗时。错误/取消不会伪装成成功 summary。`ttft_met` 计数只包含完成且达标的请求，失败仍在 offered/outcomes 中。
- 仍受 M1 每数据帧 64KiB/信用窗口约束。网关封装 JSON 会增加少量开销，接近 64KiB 的原始事件可能无法转发；错误会结束该流，不做重放。

独立 HTTP 管理入口：Worker `GET /status` / `POST /tokenize`，Gateway `GET /status`。Worker status 是 adapter 的 HTTP 调用视角；其 TTFT EWMA 从 worker 完成自身分词后起算。未直接接入 vLLM `/metrics`、KV 使用率、GPU running/waiting，也没有用 EWMA 自动更新校准速率。

## 本地运行与真实服务验收

一条命令启动并验证独立 fixture/worker/gateway/check，端口自动分配，退出后关闭本次进程：

```bash
bash scripts/verify-scheduling.sh
# 如已有独立的测试 etcd，还验证 scheduled 模型服务注册发现：
KANARPC_TEST_ETCD=127.0.0.1:32379 bash scripts/verify-scheduling.sh
go run ./cmd/scheduling-lab -output /tmp/scheduling-comparison.json -repeats 3
python3 scripts/summarize-scheduling.py /tmp/scheduling-comparison.json
```

手动演示可分别在终端运行：

```bash
go run ./cmd/inference-fixture -listen 127.0.0.1:18000
go run ./cmd/inference-worker -upstream http://127.0.0.1:18000 -model fixture-model \
  -listen 127.0.0.1:9093 -admin-listen 127.0.0.1:9096 -concurrency 4 \
  -profile fixture-serial-v1 -tokenizer fixture-words-plus-template-v1 -backend-kind fixture-no-model
go run ./cmd/inference-gateway -config configs/gateway-fixture.json
go run ./cmd/inference-check -address 127.0.0.1:9094 -model fixture-model -scheduled
```

`configs/gateway-fixture.json` 的速率只用于无模型演示，不能复制为真实模型的“实测值”。配置中的所有 duration 是 ns；命令行 budget 参数使用 `200ms` / `5s`。API key 只保留在 worker 的本机环境变量中，不写入 gateway config 或命令参数。

有真实服务后，先配置实际 base URL、模型、profile、tokenizer/chat-template revision 与已校准速率，再运行 opt-in 功能验收：

```bash
# 环境变量：KANARPC_VLLM_BASE_URL, KANARPC_VLLM_MODEL,
# KANARPC_VLLM_PROFILE, KANARPC_VLLM_TOKENIZER,
# KANARPC_VLLM_PREFILL_TPS, KANARPC_VLLM_DECODE_TPS；密钥用 VLLM_API_KEY
go test -count=1 -v ./inference/vllm ./inference/gateway -run RealVLLM
```

此入口验证真实 tokenizer、模型流、完成与取消，不是性能实验。缺少服务会明确 SKIP。多实例部署使用同模型/tokenizer、独立 profile 与对应 RPC/admin 地址填入 workers 数组；性能验收至少两个真实实例、固定模型/硬件/引擎配置、相同采样参数与到达轨迹，对照三种路由及 shared/isolated 队列，保留全部 offered/拒绝/超时、TTFT/间隔、目标内完成和批量进度。必须记录分词成本与预热、复核吞吐/延迟误差后才能声称收益。

管理入口必须由可信私有网络隔离，默认命令绑定 loopback。当前没有 TLS/auth、调用者身份到 workload class 的映射或跨网关协调；不能把客户端自报 interactive 当成生产优先级授权。

协议依据：[vLLM Tokenize API](https://docs.vllm.ai/en/latest/api/vllm/entrypoints/serve/tokenize/protocol/)、[vLLM 引擎指标](https://docs.vllm.ai/en/latest/usage/metrics/)。真实版本兼容仍需上述实际服务验收。
