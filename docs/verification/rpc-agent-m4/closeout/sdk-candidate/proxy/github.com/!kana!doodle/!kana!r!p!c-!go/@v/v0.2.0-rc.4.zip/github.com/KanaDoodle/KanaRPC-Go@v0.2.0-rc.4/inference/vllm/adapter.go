// Package vllm bridges KanaRPC server streams to a vLLM Chat Completions SSE
// endpoint. It does not own model execution or retry paid/unknown requests.
package vllm

import (
	"bufio"
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"mime"
	"net"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/rpc"
)

const ServiceName = "Inference"
const MethodName = "Chat"
const MaxEventBytes = 64 << 10
const MaxPromptBytes = 256 << 10

type Config struct {
	BaseURL    string
	Model      string
	APIKey     string
	HTTPClient *http.Client
	Scheduling *SchedulingConfig
}
type Adapter struct {
	baseURL, model, key string
	http                *http.Client
	scheduling          *SchedulingConfig
	statsMu             sync.Mutex
	stats               runtimeStats
	tokenizerSlots      chan struct{}
}
type Message struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}
type ChatRequest struct {
	Messages    []Message `json:"messages"`
	MaxTokens   int       `json:"max_tokens,omitempty"`
	Temperature *float64  `json:"temperature,omitempty"`
	// InvocationID is correlation/accounting only, not a durable idempotency key.
	InvocationID string `json:"invocation_id,omitempty"`
	CacheSalt    string `json:"cache_salt,omitempty"`
}
type Usage struct {
	PromptTokens        int                  `json:"prompt_tokens"`
	CompletionTokens    int                  `json:"completion_tokens"`
	TotalTokens         int                  `json:"total_tokens"`
	PromptTokensDetails *PromptTokensDetails `json:"prompt_tokens_details,omitempty"`
}
type PromptTokensDetails struct {
	CachedTokens int `json:"cached_tokens"`
}
type Delta struct {
	Role             string          `json:"role,omitempty"`
	Content          string          `json:"content,omitempty"`
	ReasoningContent string          `json:"reasoning_content,omitempty"`
	ToolCalls        json.RawMessage `json:"tool_calls,omitempty"`
}
type Choice struct {
	Index        int     `json:"index"`
	Delta        Delta   `json:"delta"`
	FinishReason *string `json:"finish_reason"`
}
type ChatChunk struct {
	ID      string   `json:"id"`
	Model   string   `json:"model"`
	Choices []Choice `json:"choices"`
	Usage   *Usage   `json:"usage,omitempty"`
}

func New(cfg Config) (*Adapter, error) {
	u, err := url.Parse(cfg.BaseURL)
	if err != nil || u.Host == "" || (u.Scheme != "http" && u.Scheme != "https") || u.User != nil || u.RawQuery != "" || u.Fragment != "" {
		return nil, errors.New("vLLM base URL must be an HTTP(S) endpoint without credentials, query or fragment")
	}
	if strings.TrimSpace(cfg.Model) == "" {
		return nil, errors.New("vLLM model required")
	}
	base := strings.TrimRight(u.String(), "/")
	if !strings.HasSuffix(base, "/v1") {
		base += "/v1"
	}
	h := cfg.HTTPClient
	if h == nil {
		h = &http.Client{Transport: &http.Transport{Proxy: http.ProxyFromEnvironment, DialContext: (&net.Dialer{Timeout: 5 * time.Second, KeepAlive: 30 * time.Second}).DialContext, TLSHandshakeTimeout: 5 * time.Second, ResponseHeaderTimeout: 15 * time.Second, MaxIdleConns: 32, MaxIdleConnsPerHost: 8}}
	}
	// Redirects are not part of the model API contract. Never forward a bearer
	// credential to a redirected endpoint, including custom client's redirects.
	copyClient := *h
	copyClient.CheckRedirect = func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }
	h = &copyClient
	a := &Adapter{baseURL: base, model: cfg.Model, key: cfg.APIKey, http: h, tokenizerSlots: make(chan struct{}, 4)}
	if err := a.initScheduling(cfg.Scheduling); err != nil {
		return nil, err
	}
	return a, nil
}

// ServiceForModel prevents discovery from mixing workers serving different
// model IDs. This is identity isolation, not inference-aware load balancing.
func ServiceForModel(model string) string {
	return fmt.Sprintf("%s.model.%x", ServiceName, sha256.Sum256([]byte(model)))
}

func (a *Adapter) Register(server *rpc.Server) error {
	if err := server.RegisterStream(ServiceForModel(a.model), MethodName, a.Handle); err != nil {
		return err
	}
	// Direct clients may use the generic name because the endpoint is explicit.
	return server.RegisterStream(ServiceName, MethodName, a.Handle)
}

func (a *Adapter) Models(ctx context.Context) ([]string, error) {
	response, err := a.do(ctx, http.MethodGet, "/models", nil)
	if err != nil {
		return nil, err
	}
	defer response.Body.Close()
	data, err := io.ReadAll(io.LimitReader(response.Body, 1<<20+1))
	if err != nil {
		return nil, err
	}
	if len(data) > 1<<20 {
		return nil, errors.New("vLLM model list too large")
	}
	var models struct {
		Data []struct {
			ID string `json:"id"`
		} `json:"data"`
	}
	if err := json.Unmarshal(data, &models); err != nil {
		return nil, errors.New("invalid vLLM model list")
	}
	ids := make([]string, 0, len(models.Data))
	for _, model := range models.Data {
		ids = append(ids, model.ID)
	}
	return ids, nil
}

func (a *Adapter) Handle(ctx context.Context, raw json.RawMessage, stream *rpc.ServerStream) (result error) {
	var request ChatRequest
	if len(raw) > MaxPromptBytes+16<<10 {
		return errors.New("chat request too large")
	}
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&request); err != nil {
		return errors.New("invalid chat request")
	}
	if err := ValidateRequest(&request); err != nil {
		return err
	}
	var invocation string
	var usage *Usage
	if a.scheduling != nil {
		count, err := a.Tokenize(ctx, request)
		if err != nil {
			return err
		}
		invocation, err = a.begin(request, count)
		if err != nil {
			return err
		}
		defer func() { a.end(invocation, result, usage) }()
	}
	request.InvocationID = "" // never forward internal accounting metadata upstream
	// Model identity is worker configuration, never an untrusted request override.
	body, err := json.Marshal(struct {
		ChatRequest
		Model         string `json:"model"`
		Stream        bool   `json:"stream"`
		StreamOptions struct {
			IncludeUsage bool `json:"include_usage"`
		} `json:"stream_options"`
	}{ChatRequest: request, Model: a.model, Stream: true, StreamOptions: struct {
		IncludeUsage bool `json:"include_usage"`
	}{true}})
	if err != nil {
		return err
	}
	response, err := a.do(ctx, http.MethodPost, "/chat/completions", bytes.NewReader(body))
	if err != nil {
		return err
	}
	defer response.Body.Close()
	contentType, _, err := mime.ParseMediaType(response.Header.Get("Content-Type"))
	if err != nil || contentType != "text/event-stream" {
		return errors.New("vLLM response is not an SSE stream")
	}
	return readSSE(ctx, response.Body, func(event []byte) error {
		var chunk struct {
			ChatChunk
			Error json.RawMessage `json:"error"`
		}
		if err := json.Unmarshal(event, &chunk); err != nil {
			return errors.New("malformed vLLM stream event")
		}
		if len(chunk.Error) > 0 && string(chunk.Error) != "null" {
			return errors.New("vLLM reported a stream error")
		}
		if chunk.Choices == nil && chunk.Usage == nil {
			return errors.New("vLLM stream event contains neither choices nor usage")
		}
		if chunk.Usage != nil {
			usage = chunk.Usage
		}
		if invocation != "" && HasText(chunk.ChatChunk) {
			a.text(invocation)
		}
		return stream.Send(json.RawMessage(event))
	})
}

func ValidateRequest(request *ChatRequest) error {
	if request == nil {
		return errors.New("chat request required")
	}
	if len(request.CacheSalt) > 128 {
		return errors.New("cache salt exceeds 128 bytes")
	}
	if len(request.Messages) == 0 || len(request.Messages) > 128 {
		return errors.New("messages must contain between 1 and 128 items")
	}
	bytesTotal := 0
	for _, message := range request.Messages {
		if message.Role != "system" && message.Role != "user" && message.Role != "assistant" {
			return errors.New("unsupported chat role")
		}
		bytesTotal += len(message.Content)
	}
	if bytesTotal > MaxPromptBytes {
		return errors.New("chat prompt too large")
	}
	if request.MaxTokens == 0 {
		request.MaxTokens = 256
	}
	if request.MaxTokens < 1 || request.MaxTokens > 8192 {
		return errors.New("max_tokens must be between 1 and 8192")
	}
	if request.Temperature != nil && (*request.Temperature < 0 || *request.Temperature > 2) {
		return errors.New("invalid temperature")
	}
	return nil
}

func HasText(chunk ChatChunk) bool {
	for _, choice := range chunk.Choices {
		if choice.Delta.Content != "" || choice.Delta.ReasoningContent != "" {
			return true
		}
	}
	return false
}

func (a *Adapter) do(ctx context.Context, method, path string, body io.Reader) (*http.Response, error) {
	return a.doURL(ctx, method, a.baseURL+path, body)
}
func (a *Adapter) doURL(ctx context.Context, method, endpoint string, body io.Reader) (*http.Response, error) {
	request, err := http.NewRequestWithContext(ctx, method, endpoint, body)
	if err != nil {
		return nil, err
	}
	request.Header.Set("Content-Type", "application/json")
	request.Header.Set("Accept", "text/event-stream, application/json")
	if a.key != "" {
		request.Header.Set("Authorization", "Bearer "+a.key)
	}
	response, err := a.http.Do(request)
	if err != nil {
		if ctx.Err() != nil {
			return nil, ctx.Err()
		}
		return nil, errors.New("vLLM HTTP request failed") // do not leak endpoint credentials/body
	}
	if response.StatusCode != http.StatusOK {
		response.Body.Close()
		return nil, fmt.Errorf("vLLM HTTP status %d", response.StatusCode)
	}
	return response, nil
}

func readSSE(ctx context.Context, reader io.Reader, send func([]byte) error) error {
	scanner := bufio.NewScanner(reader)
	scanner.Buffer(make([]byte, 4096), MaxEventBytes+1024)
	var event []byte
	hasData := false
	dispatch := func() (bool, error) {
		if !hasData {
			return false, nil
		}
		data := bytes.TrimSpace(event)
		if bytes.Equal(data, []byte("[DONE]")) {
			return true, nil
		}
		if err := send(data); err != nil {
			return false, err
		}
		event = nil
		hasData = false
		return false, nil
	}
	for scanner.Scan() {
		if err := ctx.Err(); err != nil {
			return err
		}
		line := scanner.Bytes()
		if len(line) == 0 {
			done, err := dispatch()
			if err != nil {
				return err
			}
			if done {
				return nil
			}
			continue
		}
		if line[0] == ':' {
			continue
		}
		field, value, ok := bytes.Cut(line, []byte(":"))
		if !ok {
			field = line
			value = nil
		}
		if string(field) != "data" {
			continue
		}
		value = bytes.TrimPrefix(value, []byte(" "))
		if hasData {
			event = append(event, '\n')
		}
		if len(event)+len(value) > MaxEventBytes {
			return errors.New("vLLM SSE event exceeds 64 KiB")
		}
		event = append(event, value...)
		hasData = true
	}
	if ctx.Err() != nil {
		return ctx.Err()
	}
	if scanner.Err() != nil {
		return errors.New("vLLM SSE read failed or line exceeds limit")
	}
	return io.ErrUnexpectedEOF // only [DONE] commits a successful stream
}
