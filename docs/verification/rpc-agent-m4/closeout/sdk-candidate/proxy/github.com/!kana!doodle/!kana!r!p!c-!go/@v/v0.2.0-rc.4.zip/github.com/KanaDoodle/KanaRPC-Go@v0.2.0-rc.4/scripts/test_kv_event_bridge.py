import unittest

from kv_event_bridge import Bridge, Unsupported, block_id, normalize

def stored():
    return {'type':'BlockStored','block_hashes':[1,2],'parent_block_hash':None,'token_ids':[1,2,3,4],'block_size':2,'lora_id':None,'lora_name':None,'medium':'GPU','group_idx':0,'extra_keys':[['tenant'],None]}

class NormalizeTests(unittest.TestCase):
    def test_fixed_vllm_wire_subset_and_salt(self):
        value=normalize([123.0,[stored()],0],2)[0]
        self.assertEqual(value['hashes'],['i:1','i:2'])
        self.assertEqual(value['salt'],'tenant')
        self.assertTrue(block_id(b'\xff\x00').startswith('b:'))

    def test_non_gpu_never_grants_credit(self):
        for medium in ['CPU','STORAGE']:
            event=stored();event['medium']=medium
            self.assertEqual(normalize([1,[event]],2),[])

    def test_unknown_layout_rank_and_extra_keys_fail_closed(self):
        for patch in [{'group_idx':1},{'lora_name':'adapter'},{'medium':None},{'locality':'REMOTE'},{'kv_cache_spec_kind':'MambaSpec'},{'token_ids':[1]},{'extra_keys':[[['image',0]],None]}]:
            event=dict(stored(),**patch)
            with self.assertRaises(Unsupported): normalize([1,[event]],2)
        with self.assertRaises(Unsupported):normalize([1,[stored()],1],2)
        with self.assertRaises(Unsupported):normalize([1,[{'type':'NewFutureEvent'}]],2)

    def test_child_does_not_invent_salt(self):
        event=stored();event['parent_block_hash']=42;event['extra_keys']=None
        self.assertEqual(normalize([1,[event]],2)[0]['salt'],'')
        event['extra_keys']=[['tenant'],None]
        with self.assertRaises(Unsupported): normalize([1,[event]],2)

class FakeBridge(Bridge):
    def __init__(self):
        super().__init__('http://127.0.0.1:1','http://127.0.0.1:2','w','ns',2,'fixture-events-no-model')
        self.resets=0;self.sent=[]
    def reset(self):
        self.resets+=1;self.owner={};self.epoch=str(self.resets);self.sequence=None;self.fingerprint=None
    def http(self,base,path,payload=None):
        self.sent.append((path,payload))

class BridgeTests(unittest.TestCase):
    def test_stale_bridge_cannot_claim_new_epoch_during_reset(self):
        bridge=Bridge('http://127.0.0.1:1','http://127.0.0.1:2','w','ns',2,'fixture-events-no-model')
        status={'ready':True,'instance_id':'boot','model':'m','profile_id':'p','tokenizer_id':'t','backend_kind':'fixture-no-model'}
        bridge.owner={'worker':'w','instance':'boot','model':'m','profile':'p','tokenizer':'t','namespace':'ns','backend_kind':'fixture-no-model'}
        bridge.epoch='old-epoch';posts=[]
        def http(base,path,payload=None):
            if path=='/status':return status
            if path=='/kv/status':return [{'worker':'w','instance':'boot','epoch':'new-epoch'}]
            posts.append(payload)
        bridge.http=http
        with self.assertRaises(Unsupported):bridge.reset()
        self.assertEqual(posts,[])

    def test_shutdown_uses_owned_epoch_without_querying_latest(self):
        bridge=Bridge('http://127.0.0.1:1','http://127.0.0.1:2','w','ns',2,'fixture-events-no-model')
        bridge.owner={'worker':'w'};bridge.epoch='owned-old';calls=[]
        bridge.http=lambda base,path,payload=None:calls.append((path,payload))
        bridge.invalidate_owned()
        self.assertEqual(len(calls),1)
        self.assertEqual(calls[0][0],'/kv/reset')
        self.assertEqual(calls[0][1]['previous_epoch'],'owned-old')

    def test_duplicate_gap_regression_and_conflicting_payload(self):
        b=FakeBridge();payload=[1,[stored()]]
        b.forward(5,payload);self.assertEqual(b.resets,1)
        self.assertFalse(b.forward(5,payload));self.assertEqual(len(b.sent),1)
        b.forward(7,payload);self.assertEqual(b.resets,2)
        b.forward(0,payload);self.assertEqual(b.resets,3)
        b.forward(0,[1,[{'type':'AllBlocksCleared'}]]);self.assertEqual(b.resets,4)
        self.assertEqual(len(b.sent),4)

    def test_actual_msgpack_multipart_encoding(self):
        import msgpack, zmq
        context=zmq.Context();pub=context.socket(zmq.PAIR);sub=context.socket(zmq.PAIR)
        port=pub.bind_to_random_port('tcp://127.0.0.1');sub.connect('tcp://127.0.0.1:'+str(port))
        try:
            payload=[1.5,[stored()],0]
            pub.send_multipart([b'kv',(123).to_bytes(8,'big'),msgpack.packb(payload,use_bin_type=True)])
            self.assertTrue(sub.poll(1000));frames=sub.recv_multipart()
            self.assertEqual(int.from_bytes(frames[1],'big'),123)
            self.assertEqual(normalize(msgpack.unpackb(frames[2],raw=False),2),normalize(payload,2))
        finally:
            pub.close(0);sub.close(0);context.term()

if __name__=='__main__':unittest.main()
