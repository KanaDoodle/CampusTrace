# M1：流式 RPC 与 vLLM 接入

实施计划：[AI 推理 RPC 路线](ai-inference-roadmap.md)。本阶段是 **单个 JSON 请求 → 多个 JSON 响应片段**；业务双向流、token 调度、KV 缓存路由和持久恢复属于后续阶段。

## 公共 API

```go
err := srv.RegisterStream("Analysis", "Run", func(
    ctx context.Context, request json.RawMessage, out *rpc.ServerStream,
) error {
    // 解析 request；下游 HTTP/数据库调用必须继续传递 ctx。
    for _, part := range []string{"first", "second"} {
        if err := out.Send(map[string]string{"text": part}); err != nil {
            return err
        }
    }
    return nil
})
```

处理注册返回的 err 后启动服务。handler 应观察 Context，且返回前等待自己启动的 goroutine。Send 可从多个 goroutine 调用，片段串行发送；跨 goroutine 的业务顺序仍由应用负责。

```go
// 也可以用 rpc.NewClient(reg, cfg) 进行 etcd 发现。
cli, err := rpc.NewDirectClient("127.0.0.1:9093", rpc.ClientConfig{
    Timeout: 60 * time.Second,
    StreamWindow: 8,
})
if err != nil { return err }
defer cli.Close()

stream, err := cli.InvokeStream(ctx, "Analysis", "Run", map[string]string{"input": "hello"})
if err != nil { return err }
defer stream.Close() // 提前退出时取消远端请求、释放未读片段
for {
    var part map[string]string
    if err := stream.Recv(&part); err != nil {
        if errors.Is(err, io.EOF) { break }
        return err
    }
    // 处理 part。
}
```

- Timeout 覆盖发现、能力探测、OPEN、整个接收过程；默认仍为 5 秒，推理调用应显式配置。
- 正常结束：读取全部已收到片段后返回 io.EOF；远端失败：先交付其之前的片段，再返回 `*rpc.StreamError`。
- 本地取消/断连：丢弃尚未消费的片段，返回取消或连接错误。`errors.Is(err, context.Canceled/DeadlineExceeded)` 可识别相应状态。
- `errors.Is(err, rpc.ErrStreamingUnsupported)` 表示无法协商流式 v1，不会重放为同步业务调用。
- `resource_exhausted` 表示没有接纳名额；没有自动重试已经发出的业务请求。
- 同一 Client 下的同步调用与多个流复用同一地址池连接。现有 Register/Invoke 保持 unary 语义；远端取消新增能力只用于流式 API。

## 协议与所有权

旧 unary 使用 version=0/kind=0，新增字段全部 omitempty，原有 Magic、固定头、长度和压缩规则保留。

| 消息 | 方向 | 行为 |
| --- | --- | --- |
| HELLO / HELLO_ACK | 双向握手 | 无业务 service/method/body；确认 stream_version=1；旧端不会误执行业务请求 |
| OPEN | 客户端 → 服务端 | requestID、JSON 请求、接收窗口、剩余时间预算 |
| ACCEPT | 服务端 → 客户端 | 接纳成功，确认窗口；拒绝则直接 END+错误 |
| DATA | 服务端 → 客户端 | 严格递增 sequence，从 1 开始，每帧最多 64 KiB |
| WINDOW_UPDATE | 客户端 → 服务端 | Recv 消费后归还 1 个信用，携带消费序号，防止重复/越界信用 |
| CANCEL | 客户端 → 服务端 | 按 requestID 取消；迟到或重复取消可忽略 |
| END | 服务端 → 客户端 | 最后一帧 sequence+1，正常终态或结构化 code/error |

接收窗口默认 8、最大 32；每连接最多 64 个活动流。客户端读循环只做有界非阻塞入队。服务端信用用尽后阻塞 Send，不继续读取下一个 SSE 事件；消费后才更新窗口。peer 超窗、错序、非法控制消息视为连接协议错误，关闭连接并失败在途请求。

客户端拥有流接收队列、终态与取消等待；服务器每连接拥有流 map，每个流拥有 Context、信用与发送序号。连接关闭取消全部服务器流，业务完成后释放全局执行名额。每个流在完成/取消/断连竞争中只发布一次完成结果。

剩余预算在获得连接写名额后重新计算，扣除写锁等待。服务器最长执行预算为 10 分钟。它不是跨机器精确同步的绝对 deadline，网络传输与控制消息仍有延迟；客户端自身 deadline 与远端取消是另一层约束。

**满载接纳行为发生变化**：新版服务端在执行名额满时立即拒绝新业务请求，继续读取控制消息，避免 CANCEL 排在等待名额的读循环后面。同步调用在满载时也会收到错误。后续 M2 再建立有预算的排队层。

控制帧写入和 socket 数据帧写入有 5 秒上限。逐流取消不会主动截断共享连接上已开始写入的完整帧；真实 socket 写错、半帧或永久不读的 peer 仍会导致整连接失败。TCP 的队头阻塞仍存在。

## vLLM adapter

公开包 `inference/vllm` 提供 `New(Config)`、`Models(ctx)`、`Register(server)`。一个 worker 固定一个模型；ChatRequest 当前支持文本 system/user/assistant messages、max_tokens（1–8192，默认 256）及 temperature，不开放任意模型名/未知字段覆盖。

adapter 请求 `/v1/chat/completions`，强制 `stream=true`、`stream_options.include_usage=true`。接收 SSE 注释、多行 data 和 CRLF；最多 64 KiB/事件；原始有效 JSON 片段透传，因此新增响应字段不会被 adapter 丢弃。HTTP 状态、错误事件、畸形 JSON、超限和缺少 `[DONE]` 的截断均失败，不自动重试。HTTP 请求和读取随流 Context 取消；未知上游错误 body 不回传，Bearer key 只从配置读取，禁止重定向转发凭据。

协议参考：[vLLM Chat Completions API](https://docs.vllm.ai/en/latest/serving/online_serving/)。本轮没有真实引擎版本验收，不声明特定版本矩阵或 GPU 性能收益。

## 独立进程本地验证（无模型）

```sh
./scripts/verify-streaming.sh
# 可提供一个绝对路径，保留二进制、stdout、stderr 和 JSON 验收输出：
./scripts/verify-streaming.sh /private/tmp/kanarpc-streaming-check
```

脚本构建并启动 SSE fixture、RPC worker、验收客户端三个独立进程，全部使用动态 loopback 端口，检查正常结束、提前取消及上游 HTTP 取消，退出时终止自己启动的进程。输出明确标记 `fixture-no-model`，没有模型执行或性能结论。脚本依赖 Go、bash、python3；生成的证据目录保留。

若设置 `KANARPC_TEST_ETCD`，脚本还会通过该独立测试实例注册模型服务并进行发现；该变量也用于项目的 compaction 测试，只能指向隔离 etcd。

## 连接真实 vLLM 的验收入口

先准备已有的可控 vLLM 服务。以下模型名必须使用 `/v1/models` 实际返回的 ID；如需要密钥，在运行 worker 的终端配置 `VLLM_API_KEY`，不写进命令参数或日志。

```sh
go run ./cmd/inference-worker \
  -listen 127.0.0.1:9093 \
  -upstream http://127.0.0.1:8000 \
  -model YOUR_SERVED_MODEL

# 另一个终端：
go run ./cmd/inference-check -address 127.0.0.1:9093 -timeout 90s
go run ./cmd/inference-check -address 127.0.0.1:9093 -timeout 90s -cancel-after-first
```

worker 启动前检查模型列表，输出 ready 地址后才算就绪。check 输出事件数、首个非空文本耗时、终态与可选 usage，不打印 prompt/完整生成内容。可以给 worker 和 check 都传 `-etcd ENDPOINT` 测试注册发现；check 此时还必须传 `-model YOUR_SERVED_MODEL`，忽略 address。worker 仅向 etcd 注册由模型 ID 确定的服务名，避免不同模型混进同一个轮询池；`vllm.ServiceForModel(model)` 可用于 SDK 调用。这只是模型身份隔离，尚无 M2 推理负载路由。外部服务器应按实际网络配置 advertise 地址，本命令默认只支持监听地址直接注册的简单部署。

自动化真实服务验收：

```sh
KANARPC_VLLM_BASE_URL=http://127.0.0.1:8000 \
KANARPC_VLLM_MODEL=YOUR_SERVED_MODEL \
go test -race -count=1 -run '^TestRealVLLMThroughRPC$' -v ./inference/vllm
```

未配置服务时测试明确 SKIP，不能视为真实 vLLM 验收。CLI 提前取消检查证明客户端终态；实际模型计算是否停止、何时释放 GPU，需要引擎侧事件/指标，M1 不据 HTTP 取消作该承诺。

## 后续边界

当前尚无 token 路由、KV 索引、推理延迟目标调度、持久重订阅或 A2A 适配。旧 unary Future 的慢完成回调仍可能阻塞连接读循环；业务 handler 必须协作取消。Shutdown 会取消流并关连接，没有响应 drain。窗口只约束 RPC 片段缓冲，不等于全进程内存/连接数或 GPU 显存上限。每流能力探测目前消耗一次额外往返；可以在后续基于明确连接能力状态优化。
