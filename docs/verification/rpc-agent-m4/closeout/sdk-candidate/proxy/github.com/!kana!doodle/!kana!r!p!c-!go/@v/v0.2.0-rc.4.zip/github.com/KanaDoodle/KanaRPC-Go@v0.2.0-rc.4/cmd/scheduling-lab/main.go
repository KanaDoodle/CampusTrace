// scheduling-lab compares actual routing/admission implementations with
// explicitly synthetic workloads. It never invokes a real model.
package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"runtime"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/inference/lab"
	"github.com/KanaDoodle/KanaRPC-Go/inference/scheduler"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
func run() error {
	output := flag.String("output", "", "JSON result file (default stdout)")
	repeats := flag.Int("repeats", 3, "loopback admission runs per policy, 1..10")
	flag.Parse()
	if *repeats < 1 || *repeats > 10 {
		return fmt.Errorf("repeats must be 1..10")
	}
	var routing []lab.RoutingResult
	var admission []lab.AdmissionResult
	for _, scenario := range []string{"heterogeneous", "instance_slowdown"} {
		for _, seed := range []int64{1, 7, 42} {
			for _, policy := range []scheduler.Policy{scheduler.RoundRobin, scheduler.LeastInFlight, scheduler.TokenWork} {
				for _, budget := range []time.Duration{10 * time.Minute, 2 * time.Second} {
					result, err := lab.RoutingWithBudget(seed, policy, scenario, budget)
					if err != nil {
						return err
					}
					routing = append(routing, result)
				}
			}
		}
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Minute)
	defer cancel()
	for i := 0; i < *repeats; i++ {
		for _, shared := range []bool{true, false} {
			result, err := lab.AdmissionComparison(ctx, shared)
			if err != nil {
				return err
			}
			admission = append(admission, result)
		}
	}
	var destination = os.Stdout
	if *output != "" {
		file, err := os.Create(*output)
		if err != nil {
			return err
		}
		defer file.Close()
		destination = file
	}
	encoder := json.NewEncoder(destination)
	encoder.SetIndent("", "  ")
	return encoder.Encode(map[string]any{"evidence": "simulation-and-loopback-fixtures-no-model", "warning": "No model or GPU is used. Results do not establish vLLM inference performance gains.", "go": runtime.Version(), "platform": runtime.GOOS + "/" + runtime.GOARCH, "routing": routing, "admission": admission})
}
