#!/usr/bin/env python3
"""Create a local, unpublished Go module candidate. Never commits, tags or pushes.

The output implements Go's file GOPROXY protocol. Consumers must use an isolated
module cache: an unpublished candidate must not poison a public version's cache.
"""
import argparse
import datetime
import hashlib
import json
import pathlib
import re
import subprocess
import zipfile

MODULE = 'github.com/KanaDoodle/KanaRPC-Go'


def escaped(value):
    return ''.join('!' + c.lower() if 'A' <= c <= 'Z' else c for c in value)


def package(repo, output, version, require_clean=False):
    if not re.fullmatch(r'v0\.\d+\.\d+(?:-rc\.\d+)?', version):
        raise ValueError('use an explicit v0.x.y or v0.x.y-rc.N version')
    status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True)
    if require_clean and status:
        raise ValueError('release preparation requires a clean committed checkout')
    if output.exists() and any(output.iterdir()):
        raise ValueError('output must be empty; never overwrite a version candidate')
    paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=repo).decode().split('\0')
    included = []
    for value in sorted(set(filter(None, paths))):
        p = pathlib.PurePosixPath(value)
        if '..' in p.parts or p.is_absolute():
            raise ValueError('invalid source path')
        # Use the repository file set, as Go's VCS module download does. Do not
        # whitelist only .go files: that would produce a different module sum
        # from the eventual public tag even when the code was identical.
        if value in ('go.work', 'go.work.sum') or p.name == '.env' or p.name.startswith('.env.') and p.name != '.env.example':
            continue
        if any(part in ('vendor', '.git', '.hg', '.svn', '.bzr') for part in p.parts):
            continue
        if any((repo / pathlib.Path(*p.parts[:i]) / 'go.mod').exists() for i in range(1, len(p.parts))):
            continue  # nested modules are not part of the root module archive
        if (repo / value).is_symlink():
            raise ValueError('SDK sources must not contain symbolic links')
        included.append(value)
    required = ['go.mod', 'go.sum', 'rpc/rpc.go']
    if int(version.split('.')[1]) >= 2:
        required += ['rpc/stream.go', 'inference/gateway/gateway.go']
    if not all(value in included for value in required):
        raise ValueError('incomplete streaming SDK source')
    mod = (repo / 'go.mod').read_bytes()
    if not mod.startswith(('module ' + MODULE + '\n').encode()) or re.search(rb'^replace\s', mod, re.M):
        raise ValueError('unexpected module identity or development replacement')
    output.mkdir(parents=True, exist_ok=True)
    target = output / 'proxy' / escaped(MODULE) / '@v'
    target.mkdir(parents=True)
    timestamp = subprocess.check_output(['git', 'show', '-s', '--format=%cI', 'HEAD'], cwd=repo, text=True).strip()
    timestamp = datetime.datetime.fromisoformat(timestamp).astimezone(datetime.timezone.utc).isoformat().replace('+00:00', 'Z')
    (target / (version + '.mod')).write_bytes(mod)
    (target / (version + '.info')).write_text(json.dumps({'Version': version, 'Time': timestamp}) + '\n')
    (target / 'list').write_text(version + '\n')
    files = {}
    with zipfile.ZipFile(target / (version + '.zip'), 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for value in included:
            raw = (repo / value).read_bytes()
            files[value] = hashlib.sha256(raw).hexdigest()
            entry = zipfile.ZipInfo(MODULE + '@' + version + '/' + value, date_time=(1980, 1, 1, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, raw)
    artifacts = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in target.iterdir() if p.name != 'list'}
    result = {'module': MODULE, 'version': version, 'publication': 'LOCAL_UNPUBLISHED_CANDIDATE',
              'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
              'source_dirty': bool(status), 'files': files, 'artifacts': artifacts,
              'real_vllm': 'NOT_VALIDATED', 'warning': 'A local module archive is not a public tag, checksum-db attestation, or inference performance result.'}
    (output / 'manifest.json').write_text(json.dumps(result, indent=2) + '\n')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--version', required=True)
    parser.add_argument('--output', required=True, type=pathlib.Path)
    parser.add_argument('--require-clean', action='store_true')
    args = parser.parse_args()
    repo = pathlib.Path(__file__).resolve().parents[1]
    result = package(repo, args.output.resolve(), args.version, args.require_clean)
    print(json.dumps({key: result[key] for key in ('module', 'version', 'publication', 'source_dirty', 'real_vllm')}))


if __name__ == '__main__':
    main()
