# M2 对照原始结果摘要

**全部结果来自离散事件模拟或本地 TCP/HTTP fixture，没有运行模型或 GPU。不能据此声称真实 vLLM 推理性能提升。**

运行环境：go1.27.1，darwin/arm64。时间单位见列名；原始 JSON 时间为 ns。

## 路由对照

每组种子 1、7、42，各 120 个请求；同一种子的 offered trace SHA256 在所有策略/预算间一致。2s 为统计目标；600s 接纳预算隔离选址影响，2s 预算另启预测 TTFT 拒绝。模拟不硬取消执行，校准误差导致的超标请求仍保留。

| 场景 | 接纳预算(s) | 路由 | 完成/offered | 拒绝 | 2s 内完成 | 各种子成功请求 TTFT p95(s) |
| --- | ---: | --- | ---: | ---: | ---: | --- |
| heterogeneous | 2 | least_in_flight | 328/360 | 32 | 328/360 | 1.780, 1.394, 1.704 |
| heterogeneous | 2 | round_robin | 324/360 | 36 | 324/360 | 1.721, 1.443, 1.611 |
| heterogeneous | 2 | token_work | 327/360 | 33 | 327/360 | 1.559, 1.562, 1.476 |
| heterogeneous | 600 | least_in_flight | 360/360 | 0 | 92/360 | 18.907, 13.158, 17.556 |
| heterogeneous | 600 | round_robin | 360/360 | 0 | 93/360 | 29.186, 21.523, 22.102 |
| heterogeneous | 600 | token_work | 360/360 | 0 | 108/360 | 11.641, 6.298, 9.964 |
| instance_slowdown | 2 | least_in_flight | 315/360 | 45 | 255/360 | 5.324, 4.564, 4.934 |
| instance_slowdown | 2 | round_robin | 313/360 | 47 | 221/360 | 5.667, 4.529, 5.710 |
| instance_slowdown | 2 | token_work | 317/360 | 43 | 263/360 | 4.518, 3.535, 3.357 |
| instance_slowdown | 600 | least_in_flight | 360/360 | 0 | 77/360 | 29.344, 18.331, 30.201 |
| instance_slowdown | 600 | round_robin | 360/360 | 0 | 68/360 | 29.444, 21.700, 30.558 |
| instance_slowdown | 600 | token_work | 360/360 | 0 | 108/360 | 44.562, 24.894, 32.939 |

## 真实 loopback TCP/HTTP、定时 SSE fixture 的队列对照

固定输入：8 个 batch 先到，12 个 interactive 随后到；batch 首文本定时 160ms，interactive 为 10ms；交互目标 150ms。最大并行总数均为 3；共享 FIFO 与交互 2 / 批量 1 固定分区比较。不模拟 GPU 资源竞争。

| 轮次 | 队列策略 | 完成/offered | 交互目标内完成/offered | 批量完成/offered | 交互成功 TTFT p95(ms) | 失败 | 整轮耗时(s) |
| ---: | --- | ---: | ---: | ---: | ---: | --- | ---: |
| 1 | shared_fifo | 8/20 | 0/12 | 8/8 | N/A (无成功样本) | queue_timeout=12 | 0.488 |
| 1 | isolated | 20/20 | 12/12 | 8/8 | 22.17 | 无 | 1.295 |
| 2 | shared_fifo | 8/20 | 0/12 | 8/8 | N/A (无成功样本) | queue_timeout=12 | 0.486 |
| 2 | isolated | 20/20 | 12/12 | 8/8 | 11.31 | 无 | 1.292 |
| 3 | shared_fifo | 8/20 | 0/12 | 8/8 | N/A (无成功样本) | queue_timeout=12 | 0.486 |
| 3 | isolated | 20/20 | 12/12 | 8/8 | 11.76 | 无 | 1.290 |

固定分区保护交互容量，但不借用空闲交互名额，批量完成耗时增加。这是构造的隔离验收案例，不是一般负载下的吞吐收益。
