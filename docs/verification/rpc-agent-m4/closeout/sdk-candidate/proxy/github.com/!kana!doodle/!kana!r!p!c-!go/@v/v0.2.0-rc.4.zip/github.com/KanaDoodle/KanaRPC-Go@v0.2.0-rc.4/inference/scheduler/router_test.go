package scheduler

import (
	"errors"
	"fmt"
	"sync"
	"testing"
	"time"
)

func testWorkers() []Worker {
	return []Worker{{ID: "a", Profile: Profile{Model: "m", ID: "p", TokenizerID: "t", PrefillTokensPerSecond: 1000, DecodeTokensPerSecond: 1000, MaxInFlight: 8}}, {ID: "b", Profile: Profile{Model: "m", ID: "p", TokenizerID: "t", PrefillTokensPerSecond: 1000, DecodeTokensPerSecond: 1000, MaxInFlight: 8}}}
}
func testStatus(active ...Invocation) WorkerStatus {
	return WorkerStatus{Model: "m", ProfileID: "p", TokenizerID: "t", InstanceID: "boot", TokenSource: "upstream_tokenizer_api", Ready: true, Active: active}
}
func routerForTest(t *testing.T, policy Policy) *Router {
	t.Helper()
	r, e := NewRouter(RouterConfig{Workers: testWorkers(), Policy: policy, StaleAfter: time.Second})
	if e != nil {
		t.Fatal(e)
	}
	for _, w := range testWorkers() {
		if e := r.Observe(w.ID, testStatus()); e != nil {
			t.Fatal(e)
		}
	}
	return r
}

func TestRoutingPoliciesCompareTokenWorkAndRequestCount(t *testing.T) {
	for _, policy := range []Policy{RoundRobin, LeastInFlight, TokenWork} {
		t.Run(string(policy), func(t *testing.T) {
			r := routerForTest(t, policy)
			_ = r.Observe("a", testStatus(Invocation{ID: "long", Work: Work{900, 100}}))
			_ = r.Observe("b", testStatus(Invocation{ID: "short1", Work: Work{10, 10}}, Invocation{ID: "short2", Work: Work{10, 10}}))
			res, e := r.Reserve("new", Work{10, 10}, 5*time.Second)
			if e != nil {
				t.Fatal(e)
			}
			defer res.Done()
			want := "a"
			if policy == TokenWork {
				want = "b"
			}
			if res.Decision.WorkerID != want {
				t.Fatal(res.Decision)
			}
		})
	}
}
func TestReservationAndWorkerSnapshotAreNotDoubleCounted(t *testing.T) {
	r := routerForTest(t, TokenWork)
	res, e := r.Reserve("call", Work{500, 100}, time.Second)
	if e != nil {
		t.Fatal(e)
	}
	if e := r.Observe(res.Worker().ID, testStatus(Invocation{ID: "call", Work: Work{500, 100}})); e != nil {
		t.Fatal(e)
	}
	views := r.Snapshot()
	if views[0].InFlight != 1 {
		t.Fatal(views)
	}
	res.FirstText()
	res.Done()
	res.Done()
	if views := r.Snapshot(); views[0].InFlight != 0 || views[0].LocalReservations != 0 {
		t.Fatal(views)
	}
}
func TestRoutingMetricsFreshnessUnreachableAndIdentity(t *testing.T) {
	now := time.Unix(100, 0)
	for _, fallback := range []bool{false, true} {
		r, e := NewRouter(RouterConfig{Workers: testWorkers()[:1], Policy: TokenWork, StaleAfter: time.Second, AllowLocalFallback: fallback, Now: func() time.Time { return now }})
		if e != nil {
			t.Fatal(e)
		}
		if _, e := r.Reserve("unknown", Work{10, 10}, time.Second); e == nil {
			t.Fatal("uninitialized worker selected")
		}
		_ = r.Observe("a", testStatus())
		now = now.Add(2 * time.Second)
		res, e := r.Reserve("stale", Work{10, 10}, time.Second)
		if fallback {
			if e != nil || res.Decision.MetricsSource != "local_fallback" {
				t.Fatal(res, e)
			}
			res.Done()
		} else if e == nil {
			t.Fatal("stale status accepted")
		}
		r.MarkUnavailable("a")
		if _, e := r.Reserve("down", Work{10, 10}, time.Second); e == nil {
			t.Fatal("unreachable selected by fallback")
		}
		wrong := testStatus()
		wrong.Model = "different"
		if e := r.Observe("a", wrong); e == nil {
			t.Fatal("wrong model accepted")
		}
		if e := r.Observe("a", testStatus()); e != nil {
			t.Fatal(e)
		}
		if _, e := r.Reserve("expired-slo", Work{1000, 100}, time.Millisecond); e == nil {
			t.Fatal("impossible SLO accepted")
		}
	}
}
func TestConcurrentReservationsRespectWorkerCapacity(t *testing.T) {
	r := routerForTest(t, TokenWork)
	var wg sync.WaitGroup
	held := make(chan *Reservation, 32)
	for i := 0; i < 32; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			if res, e := r.Reserve(fmt.Sprint(i), Work{1, 1}, time.Second); e == nil {
				held <- res
			}
		}(i)
	}
	wg.Wait()
	close(held)
	for _, view := range r.Snapshot() {
		if view.InFlight > 8 || view.LocalReservations > 8 {
			t.Fatal(view)
		}
	}
	for res := range held {
		res.Done()
	}
	for _, view := range r.Snapshot() {
		if view.LocalReservations != 0 {
			t.Fatal(view)
		}
	}
}
func TestRouterRejectsInvalidCalibrationAndDuplicateAccounting(t *testing.T) {
	workers := testWorkers()
	workers[0].Profile.PrefillTokensPerSecond = 0
	if _, e := NewRouter(RouterConfig{Workers: workers, StaleAfter: time.Second}); e == nil {
		t.Fatal("zero rate accepted")
	}
	r := routerForTest(t, TokenWork)
	bad := testStatus(Invocation{ID: "x", Work: Work{1, 1}}, Invocation{ID: "x", Work: Work{1, 1}})
	if e := r.Observe("a", bad); e == nil {
		t.Fatal("duplicate status ids accepted")
	}
	_, e := r.Reserve("x", Work{0, 1}, time.Second)
	var typed *Error
	if !errors.As(e, &typed) || typed.Code != "invalid_argument" {
		t.Fatal(e)
	}
}
