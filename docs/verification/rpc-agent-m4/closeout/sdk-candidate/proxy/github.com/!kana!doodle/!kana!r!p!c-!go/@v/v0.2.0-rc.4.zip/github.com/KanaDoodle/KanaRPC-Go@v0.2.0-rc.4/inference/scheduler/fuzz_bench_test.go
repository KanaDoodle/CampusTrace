package scheduler

import (
	"fmt"
	"math"
	"testing"
	"time"
)

func FuzzRouterBudgetBoundaries(f *testing.F) {
	f.Add(math.Float64bits(1000), uint32(512), uint16(16), int64(time.Second))
	f.Add(math.Float64bits(math.SmallestNonzeroFloat64), uint32(1), uint16(1), int64(time.Second))
	f.Add(math.Float64bits(1/(float64(math.MaxInt64)/1e9)), uint32(1), uint16(1), int64(math.MaxInt64))
	f.Fuzz(func(t *testing.T, bits uint64, prompt uint32, output uint16, budget int64) {
		workers := testWorkers()[:1]
		workers[0].Profile.PrefillTokensPerSecond = math.Float64frombits(bits)
		workers[0].Profile.DecodeTokensPerSecond = math.Float64frombits(bits)
		router, err := NewRouter(RouterConfig{Workers: workers, StaleAfter: time.Second})
		if err != nil {
			return
		}
		if err := router.Observe("a", testStatus()); err != nil {
			t.Fatal(err)
		}
		res, err := router.Reserve("fuzz", Work{int(prompt), int(output)}, time.Duration(budget))
		if err != nil {
			return
		}
		defer res.Done()
		if res.Decision.PredictedTTFT < 0 || res.Decision.PredictedTTFT > time.Duration(budget) {
			t.Fatal("duration overflow or budget bypass", res.Decision)
		}
	})
}
func BenchmarkTokenRouting(b *testing.B) {
	for _, inFlight := range []int{0, 64} {
		b.Run(fmt.Sprintf("workers8_inflight%d", inFlight), func(b *testing.B) {
			workers := make([]Worker, 8)
			for i := range workers {
				workers[i] = testWorkers()[0]
				workers[i].ID = fmt.Sprint(i)
				workers[i].Profile.MaxInFlight = 256
				workers[i].Profile.PrefillTokensPerSecond = 1e9
				workers[i].Profile.DecodeTokensPerSecond = 1e9
			}
			router, err := NewRouter(RouterConfig{Workers: workers, StaleAfter: time.Hour})
			if err != nil {
				b.Fatal(err)
			}
			for _, w := range workers {
				status := testStatus()
				for j := 0; j < inFlight; j++ {
					status.Active = append(status.Active, Invocation{ID: fmt.Sprint(j), Work: Work{512, 128}})
				}
				if err := router.Observe(w.ID, status); err != nil {
					b.Fatal(err)
				}
			}
			b.ReportAllocs()
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				res, err := router.Reserve("bench", Work{512, 128}, time.Second)
				if err != nil {
					b.Fatal(err)
				}
				res.Done()
			}
		})
	}
}
