package lab

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math/rand"
	"sort"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/inference/kvcache"
	"github.com/KanaDoodle/KanaRPC-Go/inference/scheduler"
)

type KVArrival struct {
	ID     string
	At     time.Duration
	Family int
	Salt   string
	Tokens []int
}
type KVSample struct {
	ID                    string        `json:"id"`
	Worker                string        `json:"worker,omitempty"`
	Outcome               string        `json:"outcome"`
	HintTokens            int           `json:"hint_tokens"`
	SimulatedCachedTokens int           `json:"simulated_cached_tokens"`
	TTFT                  time.Duration `json:"ttft_ns"`
	Elapsed               time.Duration `json:"elapsed_ns"`
	Reason                string        `json:"reason,omitempty"`
}
type KVResult struct {
	Evidence                                                                                                                                                string           `json:"evidence"`
	Scenario                                                                                                                                                string           `json:"scenario"`
	Seed                                                                                                                                                    int64            `json:"seed"`
	Policy                                                                                                                                                  scheduler.Policy `json:"policy"`
	TraceSHA256                                                                                                                                             string           `json:"trace_sha256"`
	Offered, Completed, Rejected, WithinTargetCompleted, HintRequests, SimulatedHitRequests, FalseHintRequests, MissedHintRequests, Transferred, EventDrops int
	Target                                                                                                                                                  time.Duration `json:"target_ns"`
	AdmissionBudget                                                                                                                                         time.Duration `json:"admission_budget_ns"`
	TTFT, Elapsed                                                                                                                                           Distribution
	Index                                                                                                                                                   []kvcache.View `json:"index"`
	Samples                                                                                                                                                 []KVSample     `json:"samples"`
}

func KVTrace(seed int64, scenario string) []KVArrival {
	rng := rand.New(rand.NewSource(seed))
	trace := make([]KVArrival, 120)
	for n := range trace {
		family := rng.Intn(8)
		if rng.Intn(10) < 7 {
			family = 0
		}
		if scenario == "cold_prefixes" {
			family = n + 1000
		}
		salt := "tenant-a"
		if rng.Intn(10) == 0 {
			salt = "tenant-b"
		}
		tokens := make([]int, 264)
		for k := 0; k < 256; k++ {
			tokens[k] = 100 + family
		}
		for k := 256; k < len(tokens); k++ {
			tokens[k] = 100000 + n*8 + k
		}
		trace[n] = KVArrival{ID: fmt.Sprintf("request-%03d", n), At: time.Duration(n) * 70 * time.Millisecond, Family: family, Salt: salt, Tokens: tokens}
	}
	return trace
}

type kvJob struct {
	arrival      KVArrival
	worker       int
	reservation  *scheduler.Reservation
	hint, actual int
	first        bool
	firstAt      time.Duration
}
type kvWorker struct {
	actual               map[string]bool
	active               map[string]*kvJob
	queue                []*kvJob
	running              *kvJob
	busy                 bool
	owner                kvcache.Owner
	epoch                string
	generation, sequence uint64
}
type kvEvent struct {
	at     time.Duration
	kind   string
	worker int
	job    *kvJob
}

func familyKey(a KVArrival) string { return fmt.Sprintf("%s/%d", a.Salt, a.Family) }
func storePrefix(a KVArrival) kvcache.Event {
	ids := make([]string, 16)
	for n := range ids {
		sum := sha256.Sum256([]byte(fmt.Sprintf("fixture/%s/%d/%d", a.Salt, a.Family, n)))
		ids[n] = hex.EncodeToString(sum[:])
	}
	return kvcache.Event{Type: "stored", Hashes: ids, Tokens: a.Tokens[:256], BlockSize: 16, Salt: a.Salt}
}

// KVSimulation runs a serial FIFO engine SURROGATE. Actual-cache state in this
// function is simulated ground truth, independent from Index hints. It has no
// continuous batching/GPU/KV transfer, and does not hard-cancel at the target.
func KVSimulation(seed int64, policy scheduler.Policy, scenario string) (KVResult, error) {
	valid := map[string]bool{"repeated_prefixes": true, "cold_prefixes": true, "hotspot": true, "eviction": true, "event_loss": true, "stale_events": true, "instance_slowdown": true}
	if !valid[scenario] {
		return KVResult{}, fmt.Errorf("unknown KV scenario")
	}
	trace := KVTrace(seed, scenario)
	encoded, _ := json.Marshal(trace)
	digest := sha256.Sum256(encoded)
	result := KVResult{Evidence: "discrete-event-kv-simulation-no-model", Scenario: scenario, Seed: seed, Policy: policy, TraceSHA256: hex.EncodeToString(digest[:]), Offered: len(trace), Target: 500 * time.Millisecond, AdmissionBudget: 3 * time.Second}
	virtual := time.Unix(0, 0)
	clock := func() time.Time { return virtual }
	index, err := kvcache.New(kvcache.Config{Namespace: "synthetic-full-attention-v1", BlockSize: 16, Capacity: 4096, TTL: 500 * time.Millisecond, Now: clock})
	if err != nil {
		return result, err
	}
	workers := make([]scheduler.Worker, 2)
	engine := make([]*kvWorker, 2)
	for n := range workers {
		id := fmt.Sprintf("w%d", n)
		workers[n] = scheduler.Worker{ID: id, Profile: scheduler.Profile{Model: Model, ID: ProfileID, TokenizerID: TokenizerID, PrefillTokensPerSecond: 2000, DecodeTokensPerSecond: 400, MaxInFlight: 64}}
		engine[n] = &kvWorker{actual: map[string]bool{}, active: map[string]*kvJob{}, owner: kvcache.Owner{Worker: id, Instance: "sim-boot", Model: Model, Profile: ProfileID, Tokenizer: TokenizerID, Namespace: index.Namespace(), BackendKind: "simulation-no-model"}, epoch: fmt.Sprintf("%032x", 1)}
	}
	router, err := scheduler.NewRouter(scheduler.RouterConfig{Workers: workers, Policy: policy, StaleAfter: time.Minute, Now: clock, Cache: index, CacheQueueLimit: 100 * time.Millisecond, MinCacheGain: time.Millisecond})
	if err != nil {
		return result, err
	}
	revision := uint64(0)
	now := time.Duration(0)
	faulted := false
	blockedEvents := false
	observe := func() error {
		revision++
		for n, w := range workers {
			status := scheduler.WorkerStatus{Model: Model, ProfileID: ProfileID, TokenizerID: TokenizerID, InstanceID: "sim-boot", Revision: revision, Ready: true, TokenSource: "upstream_tokenizer_api", BackendKind: "simulation-no-model"}
			for id, j := range engine[n].active {
				status.Active = append(status.Active, scheduler.Invocation{ID: id, Work: scheduler.Work{PromptTokens: 264, OutputTokens: 16}, FirstText: j.first})
			}
			if engine[n].busy {
				status.Active = append(status.Active, scheduler.Invocation{ID: "external-busy", Work: scheduler.Work{PromptTokens: 1, OutputTokens: 800}, FirstText: true})
			}
			if err := router.Observe(w.ID, status); err != nil {
				return err
			}
		}
		return nil
	}
	if err := observe(); err != nil {
		return result, err
	}
	for _, e := range engine {
		if err := index.Reset(kvcache.Reset{Owner: e.owner, Epoch: e.epoch}); err != nil {
			return result, err
		}
	}
	emit := func(n int, events []kvcache.Event, drop bool) error {
		e := engine[n]
		batch := kvcache.Batch{Owner: e.owner, Epoch: e.epoch, Sequence: e.sequence, Source: kvcache.FixtureSource, Events: events}
		e.sequence++
		if drop || blockedEvents {
			result.EventDrops++
			return nil
		}
		if err := index.Apply(batch); err != nil {
			e.generation++
			previous := e.epoch
			e.epoch = fmt.Sprintf("%032x", e.generation+2)
			if err := index.Reset(kvcache.Reset{Owner: e.owner, PreviousEpoch: previous, Epoch: e.epoch}); err != nil {
				return err
			}
			batch.Epoch = e.epoch
			return index.Apply(batch)
		}
		return nil
	}
	prime := KVArrival{Family: 0, Salt: "tenant-a", Tokens: make([]int, 264)}
	for n := range prime.Tokens {
		prime.Tokens[n] = 100
	}
	if scenario != "cold_prefixes" {
		engine[0].actual[familyKey(prime)] = true
		if err := emit(0, []kvcache.Event{storePrefix(prime)}, false); err != nil {
			return result, err
		}
	}
	var events []kvEvent
	if scenario == "hotspot" {
		engine[0].busy = true
		events = append(events, kvEvent{at: 2 * time.Second, kind: "unblock", worker: 0})
	}
	var startNext func(int)
	startNext = func(n int) {
		e := engine[n]
		if e.busy || e.running != nil || len(e.queue) == 0 {
			return
		}
		job := e.queue[0]
		e.queue = e.queue[1:]
		e.running = job
		if e.actual[familyKey(job.arrival)] {
			job.actual = 256
		}
		slowdown := 1.0
		if scenario == "instance_slowdown" && n == 0 && now >= 3*time.Second {
			slowdown = 4
		}
		prefill := time.Duration(float64(time.Second) * float64(264-job.actual) / 2000 * slowdown)
		decode := time.Duration(float64(time.Second) * 16 / 400 * slowdown)
		job.firstAt = now + prefill
		events = append(events, kvEvent{at: job.firstAt, kind: "first", worker: n, job: job}, kvEvent{at: job.firstAt + decode, kind: "finish", worker: n, job: job})
	}
	advance := func(until time.Duration) error {
		for len(events) > 0 {
			sort.SliceStable(events, func(a, b int) bool { return events[a].at < events[b].at })
			if events[0].at > until {
				break
			}
			event := events[0]
			events = events[1:]
			now = event.at
			virtual = time.Unix(0, int64(now))
			e := engine[event.worker]
			switch event.kind {
			case "unblock":
				e.busy = false
				startNext(event.worker)
			case "first":
				event.job.first = true
				event.job.reservation.FirstText()
				e.actual[familyKey(event.job.arrival)] = true
				if err := emit(event.worker, []kvcache.Event{storePrefix(event.job.arrival)}, false); err != nil {
					return err
				}
			case "finish":
				job := event.job
				delete(e.active, job.arrival.ID)
				job.reservation.Done()
				e.running = nil
				sample := KVSample{ID: job.arrival.ID, Worker: workers[event.worker].ID, Outcome: "eof", HintTokens: job.hint, SimulatedCachedTokens: job.actual, TTFT: job.firstAt - job.arrival.At, Elapsed: now - job.arrival.At, Reason: job.reservation.Decision.RoutingReason}
				result.Samples = append(result.Samples, sample)
				result.Completed++
				if sample.TTFT <= result.Target {
					result.WithinTargetCompleted++
				}
				if job.hint > 0 {
					result.HintRequests++
				}
				if job.actual > 0 {
					result.SimulatedHitRequests++
				}
				if job.hint > 0 && job.actual == 0 {
					result.FalseHintRequests++
				}
				if job.hint == 0 && job.actual > 0 {
					result.MissedHintRequests++
				}
				if sample.Reason == "cache_queue_limit" || sample.Reason == "queue_cost_exceeds_cache_saving" || sample.Reason == "cache_capacity_or_slo" {
					result.Transferred++
				}
				startNext(event.worker)
			}
			if err := observe(); err != nil {
				return err
			}
		}
		now = until
		virtual = time.Unix(0, int64(now))
		return nil
	}
	for _, arrival := range trace {
		if err := advance(arrival.At); err != nil {
			return result, err
		}
		if !faulted && now >= 3*time.Second && (scenario == "eviction" || scenario == "event_loss" || scenario == "stale_events") {
			faulted = true
			if scenario == "stale_events" {
				blockedEvents = true
			}
			for n, e := range engine {
				e.actual = map[string]bool{}
				if err := emit(n, []kvcache.Event{{Type: "cleared"}}, scenario == "event_loss"); err != nil {
					return result, err
				}
			}
		}
		if err := observe(); err != nil {
			return result, err
		}
		prefix, _ := index.Prepare(arrival.Salt, arrival.Tokens)
		reservation, err := router.ReserveWithPrefix(arrival.ID, scheduler.Work{PromptTokens: 264, OutputTokens: 16}, result.AdmissionBudget, prefix)
		if err != nil {
			result.Rejected++
			result.Samples = append(result.Samples, KVSample{ID: arrival.ID, Outcome: err.Error()})
			continue
		}
		n := 0
		if reservation.Decision.WorkerID == "w1" {
			n = 1
		}
		job := &kvJob{arrival: arrival, worker: n, reservation: reservation, hint: reservation.Decision.EstimatedReusableTokens}
		engine[n].active[arrival.ID] = job
		engine[n].queue = append(engine[n].queue, job)
		startNext(n)
	}
	if err := advance(time.Hour); err != nil {
		return result, err
	}
	result.Index = index.Snapshot()
	var ttfts, elapsed []time.Duration
	for _, s := range result.Samples {
		if s.Outcome == "eof" {
			ttfts = append(ttfts, s.TTFT)
			elapsed = append(elapsed, s.Elapsed)
		}
	}
	result.TTFT = distribution(ttfts)
	result.Elapsed = distribution(elapsed)
	sort.Slice(result.Samples, func(a, b int) bool { return result.Samples[a].ID < result.Samples[b].ID })
	return result, nil
}
