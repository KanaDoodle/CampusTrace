package protocol

import (
	"bytes"
	"testing"
)

func TestStreamHeadersRoundTripAndUnaryCompatibility(t *testing.T) {
	for kind := StreamHello; kind <= StreamWindowUpdate; kind++ {
		want := Header{RequestID: 42, Kind: kind, Version: StreamVersion, Sequence: 3, Window: 8, TimeoutNanos: 12345, Code: "canceled"}
		frame, err := Encode(&Message{Header: &want, Body: []byte(`{}`)})
		if err != nil {
			t.Fatal(err)
		}
		got, err := Decode(frame)
		if err != nil || *got.Header != want {
			t.Fatal(got, err)
		}
	}
	frame, err := Encode(&Message{Header: &Header{RequestID: 1}})
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Contains(frame, []byte(`"Version"`)) || bytes.Contains(frame, []byte(`"Kind"`)) {
		t.Fatal("legacy unary wire header changed")
	}
}

func FuzzStreamHeaderRoundTrip(f *testing.F) {
	f.Add(uint64(1), uint8(StreamData), uint32(8), int64(500000), []byte(`{"chunk":"hello"}`))
	f.Fuzz(func(t *testing.T, id uint64, kind uint8, window uint32, budget int64, body []byte) {
		if len(body) > MaxStreamChunkSize {
			t.Skip()
		}
		want := Header{RequestID: id, Version: StreamVersion, Kind: Kind(kind), Window: window, TimeoutNanos: budget, Sequence: id}
		data, err := Encode(&Message{Header: &want, Body: body})
		if err != nil {
			t.Fatal(err)
		}
		got, err := Decode(data)
		if err != nil || *got.Header != want || !bytes.Equal(body, got.Body) {
			t.Fatal("stream metadata/body changed", err)
		}
	})
}
