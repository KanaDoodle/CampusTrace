# SDK 候选与正式消费边界

2026-10-31。流式接口已在工作区实现，**v0.2.0-rc.4 是本地未发布候选**。远端已核对的标签仍只有 v0.1.0 / v0.1.1。真实 vLLM / GPU 未验证；发布 SDK 也不自动建立推理性能证据。

## 候选打包

```sh
python3 scripts/package-sdk.py --version v0.2.0-rc.4 --output /tmp/kanarpc-rc4
# 准备公开发布时，从干净的已提交源码执行：
python3 scripts/package-sdk.py --version v0.2.0-rc.4 --require-clean --output /tmp/kanarpc-clean-rc4
```

目录是标准 file GOPROXY：escaped module path 下的 `@v/VERSION.mod`、`.info`、`.zip` 和 `list`，另有源文件/产物 SHA-256 清单。源码使用 Git 文件集，保留许可和测试输入；不会只挑 Go 文件造成与正式 tag 的模块内容不同。排除本地 workspace、凭据、嵌套模块和 vendor，源符号链接直接拒绝。脏工作区只生成标注 `LOCAL_UNPUBLISHED_CANDIDATE` 的本地候选。

输出目录必须全新，已有候选不会被覆盖。候选消费使用独立 GOMODCACHE，避免把尚未发布的版本内容写进公共版本缓存。ZIP 文件 SHA-256 用于交付物完整性，Go 的 `h1` 用于模块内容校验；压缩格式不同可以改变 ZIP 字节而不改变 h1。打包格式已用历史已发布 v0.1.0 做内容校验对照。

## CampusTrace 独立验收

```sh
cd ../campustrace
python3 scripts/verify-stream-sdk.py --candidate /tmp/kanarpc-rc4 --output /tmp/ct-sdk-check
python3 scripts/build-stream-sdk.py --candidate /tmp/kanarpc-rc4 --output /tmp/ct-sdk-build
```

验收复制独立 CampusTrace 源码、禁用 workspace、用明确版本从候选 proxy 下载，检查没有 replace，并从模块缓存里的 SDK 编译 worker/gateway。随后跑适配器 race 和完整 API/RPC/HTTP fixture；有 Chromium 时也验证真实浏览器流程。无需相邻 RPC 源码，根 CampusTrace go.mod/go.sum 不变。

完整结果在相邻工作区的 [M4 收尾报告](../../../campustrace/docs/verification/rpc-agent-m4/closeout/report.md)，消费说明见 [stream-sdk.md](../../../campustrace/docs/stream-sdk.md)。以上是本地工作区链接。

## 公开发布尚未执行

发布前先提交并审核 M1–M4 的完整源码，确保默认和流式构建、普通/race、etcd 集成、模型无关进程验收通过。从该干净提交重新生成候选并核对文件内容，然后由维护者执行 tag/推送。不要将本轮脏工作区 HEAD 当成包含流式实现的发布提交。

标签推送、公开 proxy 可下载性和 checksum database 验证是后续真实步骤，本轮没有执行。维护者发布后，在全新目录运行：

```sh
python3 scripts/build-stream-sdk.py --version ALREADY_PUBLISHED_V0_2_VERSION --output /tmp/ct-public-sdk-build
```

该入口实际从公开 proxy/checksum database 下载，不接受本地替换或 latest，不存在的版本失败。再与审核候选比较同版本模块 h1，并运行手动 SDK CI；通过后才考虑更新默认依赖。当前公开版本查询失败不能标成已完成发布。

没有新增 A2A、工具执行或业务写权限。当前交付证明模块打包和本地消费/取消/恢复链路，不能证明真实模型质量、缓存命中或 GPU 加速。模块格式参见 [Go 官方文档](https://go.dev/ref/mod#zip-files)。
