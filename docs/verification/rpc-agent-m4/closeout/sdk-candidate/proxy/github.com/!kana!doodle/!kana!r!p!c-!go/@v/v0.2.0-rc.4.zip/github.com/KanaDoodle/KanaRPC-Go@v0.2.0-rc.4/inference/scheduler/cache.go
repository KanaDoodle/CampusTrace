package scheduler

type routeCandidate struct {
	state                          *workerState
	decision                       Decision
	score, queueSeconds, warmScore float64
}

// chooseCache runs under the same lock that installs local reservations. Cache
// credit changes placement only; the cold TTFT gate has already been applied.
func (r *Router) chooseCache(candidates []routeCandidate, preferred string) int {
	chosen := 0
	if r.policy == CacheAffinity {
		for n := 1; n < len(candidates); n++ {
			a, b := candidates[n], candidates[chosen]
			if a.decision.EstimatedReusableTokens > b.decision.EstimatedReusableTokens || (a.decision.EstimatedReusableTokens == b.decision.EstimatedReusableTokens && a.score < b.score) {
				chosen = n
			}
		}
	} else {
		cool := false
		for _, c := range candidates {
			if c.queueSeconds <= r.cacheQueueLimit.Seconds() {
				cool = true
			}
		}
		// Limit cache attraction only. Without reusable hints, choice must
		// remain the same as token_work, even under heterogeneous load.
		eligible := func(c routeCandidate) bool {
			return c.decision.EstimatedReusableTokens == 0 || !cool || c.queueSeconds <= r.cacheQueueLimit.Seconds()
		}
		chosen = -1
		for n, c := range candidates {
			if eligible(c) && (chosen < 0 || c.score < candidates[chosen].score) {
				chosen = n
			}
		}
		baseline := chosen
		warm := chosen
		for n, c := range candidates {
			if eligible(c) && c.warmScore < candidates[warm].warmScore {
				warm = n
			}
		}
		if candidates[warm].warmScore+r.minCacheGain.Seconds() < candidates[baseline].score {
			chosen = warm
		}
	}
	d := &candidates[chosen].decision
	d.CachedWorker = preferred
	switch {
	case d.CacheState == "no_token_ids":
		d.RoutingReason = "load_no_token_ids"
	case preferred == "":
		d.RoutingReason = "load_no_fresh_prefix"
	case d.WorkerID == preferred:
		d.RoutingReason = "cache_affinity"
	default:
		d.RoutingReason = "cache_capacity_or_slo"
		for _, c := range candidates {
			if c.decision.WorkerID == preferred {
				d.RoutingReason = "queue_cost_exceeds_cache_saving"
				if r.policy == CacheAware && c.queueSeconds > r.cacheQueueLimit.Seconds() {
					d.RoutingReason = "cache_queue_limit"
				}
				break
			}
		}
	}
	return chosen
}
