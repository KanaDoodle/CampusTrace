// kv-routing-lab runs event-observed cache routing against a synthetic FIFO
// engine. Cache hits and timing results are simulated, never real inference.
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"runtime"

	"github.com/KanaDoodle/KanaRPC-Go/inference/lab"
	"github.com/KanaDoodle/KanaRPC-Go/inference/scheduler"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
func run() error {
	output := flag.String("output", "", "JSON evidence path, default stdout")
	flag.Parse()
	var results []lab.KVResult
	for _, scenario := range []string{"repeated_prefixes", "cold_prefixes", "hotspot", "eviction", "event_loss", "stale_events", "instance_slowdown"} {
		for _, seed := range []int64{1, 7, 42} {
			for _, policy := range []scheduler.Policy{scheduler.TokenWork, scheduler.CacheAffinity, scheduler.CacheAware} {
				r, err := lab.KVSimulation(seed, policy, scenario)
				if err != nil {
					return err
				}
				results = append(results, r)
			}
		}
	}
	destination := os.Stdout
	if *output != "" {
		file, err := os.Create(*output)
		if err != nil {
			return err
		}
		defer file.Close()
		destination = file
	}
	encoder := json.NewEncoder(destination)
	encoder.SetIndent("", "  ")
	return encoder.Encode(map[string]any{"evidence": "discrete-event-kv-simulation-no-model", "warning": "All cache hits, engine behavior and timing are simulated. No vLLM/GPU inference gains were measured.", "go": runtime.Version(), "platform": runtime.GOOS + "/" + runtime.GOARCH, "results": results})
}
