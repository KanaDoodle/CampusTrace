#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export GOWORK=off
work="${1:-$(mktemp -d /private/tmp/kanarpc-streaming-check.XXXXXX)}"
mkdir -p "$work"
fixture_pid=""
worker_pid=""
cleanup() {
  if [[ -n "$worker_pid" ]]; then kill "$worker_pid" 2>/dev/null || true; wait "$worker_pid" 2>/dev/null || true; fi
  if [[ -n "$fixture_pid" ]]; then kill "$fixture_pid" 2>/dev/null || true; wait "$fixture_pid" 2>/dev/null || true; fi
}
trap cleanup EXIT
go build -o "$work/inference-fixture" ./cmd/inference-fixture
go build -o "$work/inference-worker" ./cmd/inference-worker
go build -o "$work/inference-check" ./cmd/inference-check
wait_ready() {
  python3 - "$1" "$2" <<'PY'
import json, pathlib, os, sys, time
p, pid = pathlib.Path(sys.argv[1]), int(sys.argv[2])
for _ in range(150):
    os.kill(pid, 0)
    if p.exists():
        for line in p.read_text().splitlines():
            try:
                value = json.loads(line)
            except ValueError:
                continue
            if value.get('event') == 'ready':
                print(value['address'])
                sys.exit(0)
    time.sleep(0.1)
raise SystemExit('process did not report readiness')
PY
}
"$work/inference-fixture" -listen 127.0.0.1:0 > "$work/fixture.jsonl" 2> "$work/fixture.stderr" &
fixture_pid=$!
fixture_address=$(wait_ready "$work/fixture.jsonl" "$fixture_pid")
worker_args=(-listen 127.0.0.1:0 -upstream "http://$fixture_address" -model fixture-model -api-key-env KANARPC_FIXTURE_KEY)
if [[ -n "${KANARPC_TEST_ETCD:-}" ]]; then worker_args+=(-etcd "$KANARPC_TEST_ETCD"); fi
KANARPC_FIXTURE_KEY="" "$work/inference-worker" "${worker_args[@]}" > "$work/worker.jsonl" 2> "$work/worker.stderr" &
worker_pid=$!
worker_address=$(wait_ready "$work/worker.jsonl" "$worker_pid")
check_args=(-address "$worker_address" -timeout 5s)
if [[ -n "${KANARPC_TEST_ETCD:-}" ]]; then check_args+=(-etcd "$KANARPC_TEST_ETCD" -model fixture-model); fi
"$work/inference-check" "${check_args[@]}" > "$work/complete.json"
"$work/inference-check" "${check_args[@]}" -cancel-after-first > "$work/cancel.json"
python3 - "$work" <<'PY'
import json, pathlib, sys, time
p = pathlib.Path(sys.argv[1])
assert json.loads((p/'complete.json').read_text())['terminal'] == 'eof'
assert json.loads((p/'cancel.json').read_text())['terminal'] == 'canceled'
for _ in range(30):
    if any(json.loads(line).get('outcome') == 'canceled' for line in (p/'fixture.jsonl').read_text().splitlines()):
        break
    time.sleep(.1)
else:
    raise SystemExit('upstream HTTP cancellation was not observed')
print(json.dumps({'status':'passed','backend':'fixture-no-model','processes':['fixture','rpc-worker','rpc-check'],'checks':['complete stream','early cancel','upstream HTTP canceled'],'evidence':str(p)}))
PY
