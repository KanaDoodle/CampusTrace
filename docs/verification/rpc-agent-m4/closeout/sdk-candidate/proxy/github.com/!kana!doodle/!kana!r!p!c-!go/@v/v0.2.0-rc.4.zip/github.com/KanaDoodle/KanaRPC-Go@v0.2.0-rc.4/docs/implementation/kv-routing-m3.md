# M3 KV 缓存感知与饱和转移

日期：2026-10-30。基线为未提交的 M1+M2 工作区，保存在 `/private/tmp/kanarpc-before-m3.tgz` / `.patch`，不重置已有工作。

## 分阶段实施

1. **有界位置索引**：精确 tokenizer token ID 的完整块前缀；模型/模板/KV namespace/cache_salt 隔离；GPU block stored/removed/cleared 事件；worker boot、流 epoch、序列、TTL、容量上限。重复不续鲜，缺口失效并冷重建，不把请求成功或重复当成缓存已存在。测试淘汰、丢事件、重启、重复、乱序、盐隔离与并发。
2. **选址与饱和转移**：在 M2 原子预留内加入 cache_affinity 消融与 cache_aware；比较缓存 prefill 估计节省、已有排队成本和容量；有最小收益门槛及缓存排队上限。缓存不打折接纳预算，失效退回 token_work。转移仅指业务发送前改选实例，不搬 KV、不迁移已执行请求、不重放。与 M2、纯亲和策略做同轨迹对照。
3. **网关与真实协议入口**：Worker 可返回上游精确 token ID；gateway 私有控制面接事件，转发 cache_salt；独立 Python ZMQ/msgpack bridge 对齐固定 vLLM v0.32.0 事件子集。仅支持单 DP rank、单 FullAttention group、本地 GPU、文本、无 LoRA/多模态/卸载；未知布局失效。桥是实时输入入口，不声称本机有 vLLM。测试真实 loopback TCP/HTTP/ZMQ、取消/关闭和异常事件。
4. **对照与验收**：固定种子/到达轨迹，重复/冷前缀、热缓存过载、淘汰、指标陈旧、事件缺口/冷重建、失准负例；记录全部 offered、拒绝、成功、TTFT、目标内完成、提示与模拟真实缓存分开计数。普通/race/vet、必要 fuzz/benchmark、M1/M2 回归与独立进程验收。真实 vLLM/GPU 无服务明确 SKIP，提供可运行 opt-in 入口。

## 边界

- 命中提示是 fresh 事件索引对前缀的匹配估计；真实命中仅以上游 usage/引擎指标确认，不以路由决策代替。
- 索引只存派生前缀 hash 和 engine block ID，不保留原始提示词/token 序列；控制面仍接触 token ID，必须在可信网络隔离。cache_salt 不是身份认证。
- 位置索引与配额都是当前单网关内存状态，不实现跨网关一致性。
- TTL 基于事件接收时间，反复读取状态不能延长缓存寿命。首次接入/缺口后为空索引，只从新事件完整根链冷重建；本阶段不实现 vLLM replay 快照或 GPU KV 传输。
- profile、namespace、布局与校准由部署者声明；无真实引擎不声称其正确性或性能收益。

协议来源：[固定版本事件定义](https://github.com/vllm-project/vllm/blob/v0.32.0/vllm/distributed/kv_events.py)、[APC 与 cache_salt](https://docs.vllm.ai/en/v0.32.0/design/prefix_caching/)。

## 已实现的链路与语义

```mermaid
flowchart LR
    E[vLLM KV ZMQ 事件] --> B[固定协议子集 bridge]
    B -->|私有 HTTP reset / events| I[有界 KV 位置索引]
    C[请求 + cache_salt] --> T[上游 tokenizer 精确 IDs]
    T --> P[派生完整块前缀 hash]
    P --> R[M2 原子选址与预留]
    I -->|事件新鲜度与位置提示| R
    R -->|一次发送前选址| W[Worker 流式生成]
    W --> U[上游 usage 中 cached_tokens]
```

### 索引

- `inference/kvcache.Index` 不复制引擎的私有 hash 算法。用事件的 engine block ID / parent 建链，并对 namespace、cache_salt 和精确 token 块计算本地 SHA256 链。请求用相同 token ID 计算键，逐块匹配最长连续前缀。父块丢失不能把子块当根；任一祖先被移除后，不计不连续的后代。
- 只索引完整块，保留至少 1 个未命中 token 作保守估计；每次 Prepare 最多 256 块。Gateway 只接受完整且合法的上游 ID；缺失/错误/超过 65536 个 ID 时保留有效 count、禁用该次缓存提示。绝不以字数/字符串相似性替代真实 tokenizer。
- 每个 worker 最多 65536 个索引节点（实例配置通常更小），全索引最多 64 workers。批次最多 256 events / 4096 hashes / 65536 tokens；HTTP envelope 最多 1MiB。容量或格式错误清空并隔离该实例索引，要求 reset 冷重建。
- `Owner` 绑定 worker、boot instance、model、profile、tokenizer、namespace、backend_kind；观察到新 boot 会丢弃旧索引。namespace 应由部署者涵盖权重版本、模板和 KV 布局；它不是自动核验的指纹。
- 管理端 `POST /kv/reset` 用 `previous_epoch` 比较并交换流 epoch，新 epoch 为 32 字符随机 hex；迟到 reset 不可覆盖新流。`POST /kv/events` 要求严格连续的 sequence。相同序号、相同载荷重传不续 TTL；同序号冲突失效；较老序号忽略且不续鲜；缺口失效，之后必须明确 reset。
- reset 从空索引开始，可以把第一个观察到的序号作为起点；只从新观察到的完整根链重建。这是部分已知位置，不是完整引擎快照。`AllBlocksCleared` 清除全部位置；丢失的未知节点只会减少提示。
- TTL 只由成功接收的事件批次推进，`GET /kv/status` 不续鲜。来源标记为 `fixture-events-no-model` 或 `vllm-events`；已声明 fixture/simulation 的 worker 不允许上传 `vllm-events` 标签。标签仍是可信控制面的声明，不是引擎身份认证。

### 选址

`inference/scheduler` 增加 `CacheAffinity`（消融）和 `CacheAware`，默认仍为 M2 `TokenWork`。原来的 `Reserve` 保留；新 `ReserveWithPrefix` 在同一把锁内查位置、比较候选并建立预留，避免并发决策都认为实例空闲。

```text
cold_TTFT = M2 原预测（不扣缓存）
estimated_saving = matched_full_prefix_tokens / calibrated_prefill_rate * saving_fraction
estimated_warm_TTFT = cold_TTFT - estimated_saving
cache_score = token_work_score - estimated_saving
```

先应用原模型/profile/状态 TTL/并发/冷 TTFT 预算门槛；缓存收益不放宽接纳预算，运行/排队 token 预留也不打折。CacheAffinity 选最多提示 token，再以 token_work 成本打破平局。CacheAware 比较 warm score 与负载基线，并要求最小收益；如果存在低排队替代实例，限制对排队过长缓存实例的吸引力。没有有效提示时，选择严格退化为 token_work，包括异构实例情形。

- `kv.queue_limit_ns`：缓存排队上限，默认 100ms，仅约束有复用提示的候选；不是对所有负载候选的另一个接纳上限。
- `kv.min_gain_ns`：选择缓存带来的最小估计收益，默认 2ms。
- `kv.saving_fraction`：估计折扣，范围 `(0,1]`，省略/0 默认 1，是 prefill 节省的上界模型，不是已校准实测。真实部署需校准或保持 token_work。
- `Decision` 返回 `estimated_reusable_tokens`、`cache_evidence`、`cache_state`、`preferred_cached_worker`、`estimated_warm_ttft_ns`、`routing_reason`。它们全是提示/估计，不是引擎命中结果。
- `cache_queue_limit`、`queue_cost_exceeds_cache_saving`、`cache_capacity_or_slo` 表示发送前改选实例；`load_no_token_ids` / `load_no_fresh_prefix` 表示负载降级。不会搬运 KV、抢占或迁移已执行请求，也没有新的生成重试。

### 实际命中与性能

`vllm.Usage.PromptTokensDetails.CachedTokens` 只从上游原样解析，保留到 gateway summary；字段缺失仍是缺失，不以 decision 推导填充。事件只说明在某个时点观察到块位置，在检查到缺口或 TTL 到期前可能假阳性；并发淘汰、引擎内部布局和队列变化也会造成误差。

## 本地可运行验证

Go RPC 没有新增 module 依赖。ZMQ bridge 的可选 Python 依赖单独固定在 `scripts/requirements-kv.txt`，不安装 vLLM/torch/模型。

```bash
python3 -m venv /tmp/kanarpc-kv-venv
/tmp/kanarpc-kv-venv/bin/python -m pip install -r scripts/requirements-kv.txt
PYTHONDONTWRITEBYTECODE=1 /tmp/kanarpc-kv-venv/bin/python -m unittest discover -s scripts -p test_kv_event_bridge.py -v
PYTHONDONTWRITEBYTECODE=1 /tmp/kanarpc-kv-venv/bin/python scripts/verify-kv-routing.py --output /tmp/kanarpc-kv-process
go run ./cmd/kv-routing-lab -output /tmp/kv-comparison.json
python3 scripts/summarize-kv-routing.py /tmp/kv-comparison.json
```

进程验证会创建并结束本次 fixture、两个 worker、gateway、bridge、check，并用真实 ZMQ PUB/SUB 发送**手工构造的测试事件**；没有真实 vLLM 事件或模型。它验证冷/暖索引、盐隔离、饱和改选、缺口/重建、移除/不支持事件、过期和取消。结果文件均标注 fixture-no-model；fixture usage 不伪造 cached_tokens。

手动配置示例是 `configs/gateway-kv-fixture.json`，使用两个 worker 的 RPC/admin 地址，全部是无模型示例。自动验证脚本使用随机端口；该静态示例供阅读和手动调试，不代表真实部署参数。

## 真实服务验收入口（当前未运行）

目标为 vLLM v0.32.0、纯文本、单 DP rank、单 FullAttention group、本地 GPU；不支持 hybrid/Mamba/sliding window、LoRA、MM、prompt embeddings、offload、远端 KV 或 partial-tail 事件。无法归类的 GPU 事件会冷失效；CPU/STORAGE 不赋予本地 GPU 复用提示。新版本必须重新核对协议，不能直接套用 latest。

1. 用真实权重/模板/布局与速率替换示例，开启 APC、KV 事件及 usage 明细。与 bridge 同机时可使用 IPC，避免暴露事件端口：

```bash
vllm serve "$MODEL" --enable-prefix-caching --enable-prompt-tokens-details --block-size 16 \
  --kv-events-config '{"enable_kv_cache_events":true,"publisher":"zmq","endpoint":"ipc:///tmp/kanarpc-real-worker-a.sock","topic":"kv"}'
```

2. 运行现有 `inference-worker`，配置真实 model、profile、tokenizer revision 和 `-admin-listen`，保持实际 worker 与事件发布者一一对应。网关 `kv.index.namespace` 涵盖实际权重/模板/布局，block_size 与引擎一致，TTL/容量与校准参数自行实测；另填入第二个实例做性能对照。密钥留在 `VLLM_API_KEY` 环境变量，不放入事件桥或配置文件。
3. gateway 观察到 worker 后启动 bridge。`--layout` 是部署者的明确布局声明，不是自动检测：

```bash
/tmp/kanarpc-kv-venv/bin/python scripts/kv_event_bridge.py \
  --endpoint ipc:///tmp/kanarpc-real-worker-a.sock --topic kv \
  --gateway http://127.0.0.1:9095 --worker-admin http://127.0.0.1:9096 \
  --worker a --namespace YOUR_WEIGHTS_TEMPLATE_LAYOUT_REVISION --block-size 16 \
  --layout full-attention-single-group
```

生产环境的跨机事件需使用可信私有 ZMQ 网络。bridge 遇序列缺口、倒退、冲突、未知事件或转发失败会尝试 CAS 冷 reset；无法联系控制面时依赖 TTL 失效。没有实现 replay endpoint 的补洞或完整快照。桥停止时仅以自己持有的 epoch 做 CAS 失效；发现新桥持有该流则退出，不重新领取或清空新流。硬崩溃仍依赖 TTL；这不是多个并行 publisher 的聚合协议。

4. 显式配置可运行的真实 opt-in 测试：

```bash
export KANARPC_KV_GATEWAY_ADDRESS=127.0.0.1:9094
export KANARPC_KV_GATEWAY_ADMIN=http://127.0.0.1:9095
export KANARPC_VLLM_MODEL=YOUR_SERVED_MODEL
go test -count=1 -v ./inference/gateway -run '^TestRealVLLMKVEventRouting$'
```

此用例最多发送 4 次独立的预热/验收请求，检查真实流完成、`vllm-events` 提示及上游报告的正 cached_tokens；缺失任何一项即失败，不把缺失 usage 当成命中。不配置 gateway 地址则明确 SKIP。`--enable-prompt-tokens-details` 在固定版本默认关闭，需显式开启，依据[官方 serve 说明](https://docs.vllm.ai/en/v0.32.0/cli/serve/)。功能通过仍不能推出吞吐/延迟收益。

性能验收还需至少两个真实实例，相同模型/采样/硬件、固定到达轨迹，比较 token_work / cache_affinity / cache_aware 的全部 offered、拒绝、失败、TTFT、达标完成、实际 cached_tokens、队列和 GPU/KV 状态，记录预热与分词/事件开销。本轮未具备这些数据。

## 当前结果

实现与本地分阶段验证完成。测试确认并修复了首次非法批次未锁住冷重建、同序列冲突未失效、无提示时缓存队列限制改变负载降级、旧桥清理可能干扰新 epoch 四处新增实现问题。具体失败复现、最终检查、CPU 开销和所有正负对照见 [M3 验证报告](../verification/kv-routing-m3/report.md)。

管理面没有 TLS/auth；cache_salt 只隔离键空间，不授权租户身份，也不证明隐私。单网关索引/配额、静态 worker 池、静态校准及 M1 传输/关闭边界继续适用。
