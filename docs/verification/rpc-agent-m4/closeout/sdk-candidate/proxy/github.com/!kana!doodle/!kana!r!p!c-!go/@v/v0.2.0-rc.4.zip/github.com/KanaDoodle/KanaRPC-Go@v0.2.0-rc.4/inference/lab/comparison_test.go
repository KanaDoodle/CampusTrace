package lab

import (
	"context"
	"reflect"
	"testing"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/inference/scheduler"
)

func TestRoutingComparisonIsDeterministicAndCountsEveryOfferedCall(t *testing.T) {
	for _, scenario := range []string{"heterogeneous", "instance_slowdown"} {
		for _, seed := range []int64{1, 7, 42} {
			var hash string
			for _, policy := range []scheduler.Policy{scheduler.RoundRobin, scheduler.LeastInFlight, scheduler.TokenWork} {
				result, err := Routing(seed, policy, scenario)
				if err != nil {
					t.Fatal(err)
				}
				if result.Offered != 120 || result.Completed+result.Rejected != 120 || len(result.Samples) != 120 || result.TTFT.N != result.Completed {
					t.Fatal(result)
				}
				if hash != "" && hash != result.TraceSHA256 {
					t.Fatal("policies used different offered work")
				}
				hash = result.TraceSHA256
				again, err := Routing(seed, policy, scenario)
				if err != nil || !reflect.DeepEqual(result, again) {
					t.Fatal("non-deterministic simulation", err)
				}
				t.Logf("simulation only: scenario=%s seed=%d policy=%s completed=%d/%d target_met=%d p95=%s", scenario, seed, policy, result.Completed, result.Offered, result.WithinTargetCompleted, result.TTFT.P95)
			}
		}
	}
}
func TestAdmissionComparisonCountsFailuresAndBatchProgress(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
	defer cancel()
	for _, shared := range []bool{true, false} {
		result, err := AdmissionComparison(ctx, shared)
		if err != nil {
			t.Fatal(err)
		}
		if result.Offered != 20 || result.InteractiveOffered != 12 || result.BatchOffered != 8 || result.BatchCompleted == 0 || result.Gateway.Admission.Interactive.Running != 0 || result.Gateway.Workers[0].LocalReservations != 0 {
			t.Fatal(result)
		}
		total := 0
		for _, n := range result.Outcomes {
			total += n
		}
		if total != 20 {
			t.Fatal("missing outcomes", result.Outcomes)
		}
		if !shared && (result.InteractiveCompleted != 12 || result.BatchCompleted != 8) {
			t.Fatal("fixture isolation/progress failed", result.Outcomes)
		}
		t.Logf("loopback fixture only: policy=%s completed=%d/%d interactive_target=%d/12 batch=%d/8 outcomes=%v", result.Policy, result.Completed, result.Offered, result.InteractiveWithinTarget, result.BatchCompleted, result.Outcomes)
	}
}
