package transport

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net"
	"sync"
	"sync/atomic"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/internal/protocol"
)

const ControlWriteTimeout = 5 * time.Second

var ErrStreamingUnsupported = errors.New("peer does not support streaming protocol v1")

// StreamError preserves a machine-readable terminal status across the wire.
type StreamError struct{ Code, Message string }

func (e *StreamError) Error() string { return e.Code + ": " + e.Message }
func (e *StreamError) Is(target error) bool {
	return (e.Code == "canceled" && target == context.Canceled) ||
		(e.Code == "deadline_exceeded" && target == context.DeadlineExceeded)
}

type streamFrame struct {
	sequence uint64
	body     []byte
}

// ClientStream owns a bounded receive queue. Only its connection's readLoop
// delivers frames; Recv never runs in that loop. Callers must Close abandoned streams.
type ClientStream struct {
	client                  *TCPClient
	id                      uint64
	window                  uint32
	queue                   chan streamFrame
	accepted                chan struct{}
	future                  *Future
	mu                      sync.Mutex
	recvMu                  sync.Mutex
	sequence                uint64
	started, ended, discard bool
	err                     error
}

func (c *TCPClient) OpenStream(ctx context.Context, msg *protocol.Message, window uint32) (*ClientStream, error) {
	if window == 0 || window > protocol.MaxStreamWindow {
		return nil, errors.New("invalid receive window")
	}
	if msg == nil || msg.Header == nil {
		return nil, errors.New("stream header required")
	}
	if _, ok := ctx.Deadline(); !ok {
		return nil, errors.New("stream requires a deadline")
	}
	// A blank probe cannot accidentally execute a method on an old server.
	probe, err := c.SendAsyncContext(ctx, &protocol.Message{Header: &protocol.Header{Version: protocol.StreamVersion, Kind: protocol.StreamHello}})
	if err != nil {
		return nil, err
	}
	var capability struct {
		StreamVersion uint8 `json:"stream_version"`
	}
	if err := probe.GetResultWithContext(ctx, &capability); err != nil {
		if ctx.Err() != nil {
			return nil, ctx.Err()
		}
		return nil, fmt.Errorf("%w: %v", ErrStreamingUnsupported, err)
	}
	if capability.StreamVersion != protocol.StreamVersion {
		return nil, ErrStreamingUnsupported
	}
	id := c.nextSeq()
	s := &ClientStream{client: c, id: id, window: window, queue: make(chan streamFrame, window), accepted: make(chan struct{}), future: NewFuture()}
	c.streamsMu.Lock()
	if atomic.LoadInt32(&c.closed) != 0 {
		c.streamsMu.Unlock()
		return nil, net.ErrClosed
	}
	if len(c.streams) >= protocol.MaxStreamsPerConn {
		c.streamsMu.Unlock()
		return nil, &StreamError{Code: "resource_exhausted", Message: "stream limit reached"}
	}
	if c.streams == nil {
		c.streams = make(map[uint64]*ClientStream)
	}
	c.streams[id] = s
	c.streamsMu.Unlock()
	header := *msg.Header
	header.RequestID, header.Version, header.Kind, header.Window = id, protocol.StreamVersion, protocol.StreamOpen, window
	deadline, _ := ctx.Deadline()
	header.TimeoutNanos = int64(time.Until(deadline))
	if header.TimeoutNanos <= 0 {
		s.complete(context.DeadlineExceeded, true)
		return nil, context.DeadlineExceeded
	}
	wrote, err := c.conn.writeContext(ctx, &protocol.Message{Header: &header, Body: msg.Body})
	if err != nil {
		s.complete(err, true)
		if wrote {
			c.fail(err)
		}
		return nil, err
	}
	go func() {
		select {
		case <-ctx.Done():
			s.complete(ctx.Err(), true)
		case <-s.future.DoneChan():
		}
		s.mu.Lock()
		aborted := s.discard
		s.mu.Unlock()
		if aborted {
			_ = c.writeStreamControl(&protocol.Header{RequestID: id, Kind: protocol.StreamCancel})
		}
	}()
	select {
	case <-s.accepted:
		return s, nil
	case <-s.future.DoneChan():
		select {
		case <-s.accepted:
			return s, nil
		default:
		}
		s.mu.Lock()
		err := s.err
		s.mu.Unlock()
		if err == nil {
			err = errors.New("stream ended before acceptance")
		}
		return nil, err
	case <-ctx.Done():
		s.complete(ctx.Err(), true)
		return nil, ctx.Err()
	}
}

func (c *TCPClient) writeStreamControl(header *protocol.Header) error {
	header.Version = protocol.StreamVersion
	ctx, cancel := context.WithTimeout(context.Background(), ControlWriteTimeout)
	defer cancel()
	wrote, err := c.conn.writeContext(ctx, &protocol.Message{Header: header})
	if err != nil && wrote {
		c.fail(err)
	}
	return err
}

func (c *TCPClient) dispatchStream(msg *protocol.Message) bool {
	id := msg.Header.RequestID
	c.streamsMu.Lock()
	s := c.streams[id]
	c.streamsMu.Unlock()
	if s == nil {
		// Late stream frames must never complete a unary Future.
		return msg.Header.Kind == protocol.StreamAccept || msg.Header.Kind == protocol.StreamData || msg.Header.Kind == protocol.StreamEnd
	}
	if err := s.deliver(msg); err != nil {
		c.fail(err)
	}
	return true
}

func (s *ClientStream) deliver(msg *protocol.Message) error {
	h := msg.Header
	s.mu.Lock()
	if s.ended {
		s.mu.Unlock()
		return nil
	}
	if h.Version != protocol.StreamVersion {
		s.mu.Unlock()
		return errors.New("invalid stream version")
	}
	switch h.Kind {
	case protocol.StreamAccept:
		if s.started || h.Window != s.window || h.Sequence != 0 {
			s.mu.Unlock()
			return errors.New("invalid stream acceptance")
		}
		s.started = true
		close(s.accepted)
		s.mu.Unlock()
		return nil
	case protocol.StreamData:
		if !s.started || h.Sequence != s.sequence+1 || len(msg.Body) > protocol.MaxStreamChunkSize {
			s.mu.Unlock()
			return errors.New("invalid stream data or sequence")
		}
		s.sequence = h.Sequence
		select {
		case s.queue <- streamFrame{h.Sequence, msg.Body}:
			s.mu.Unlock()
			return nil
		default:
			s.mu.Unlock()
			return errors.New("peer exceeded stream receive window")
		}
	case protocol.StreamEnd:
		if h.Sequence != s.sequence+1 {
			s.mu.Unlock()
			return errors.New("invalid stream terminal sequence")
		}
		var err error
		if h.Error != "" || h.Code != "" {
			err = &StreamError{Code: h.Code, Message: h.Error}
		}
		s.mu.Unlock()
		s.complete(err, false)
		return nil
	default:
		s.mu.Unlock()
		return errors.New("unexpected stream frame")
	}
}

func (s *ClientStream) complete(err error, discard bool) {
	s.mu.Lock()
	if s.ended {
		s.mu.Unlock()
		return
	}
	s.ended, s.discard, s.err = true, discard, err
	if discard {
		s.drainLocked()
	}
	s.mu.Unlock()
	s.client.streamsMu.Lock()
	if s.client.streams[s.id] == s {
		delete(s.client.streams, s.id)
	}
	s.client.streamsMu.Unlock()
	s.future.Done(nil, err)
}

func (s *ClientStream) OnComplete(fn func(error)) { s.future.OnComplete(fn) }
func (s *ClientStream) Close() error {
	s.complete(context.Canceled, true)
	// Release unread bodies even when a remote END already retired the stream.
	s.mu.Lock()
	s.discard = true
	if s.err == nil {
		s.err = context.Canceled
	}
	s.drainLocked()
	s.mu.Unlock()
	return nil
}

func (s *ClientStream) drainLocked() {
	for {
		select {
		case <-s.queue:
		default:
			return
		}
	}
}

// Recv drains already-delivered data before a remote terminal status. A local
// cancel/connection failure discards buffered data and returns immediately.
func (s *ClientStream) Recv() ([]byte, error) {
	s.recvMu.Lock()
	defer s.recvMu.Unlock()
	for {
		s.mu.Lock()
		ended, discard, err := s.ended, s.discard, s.err
		s.mu.Unlock()
		if discard {
			return nil, err
		}
		select {
		case frame := <-s.queue:
			return s.consume(frame)
		default:
		}
		if ended {
			if err != nil {
				return nil, err
			}
			return nil, io.EOF
		}
		select {
		case frame := <-s.queue:
			return s.consume(frame)
		case <-s.future.DoneChan():
		}
	}
}

func (s *ClientStream) consume(frame streamFrame) ([]byte, error) {
	s.mu.Lock()
	if s.discard {
		err := s.err
		s.mu.Unlock()
		return nil, err
	}
	ended := s.ended
	s.mu.Unlock()
	if !ended {
		if err := s.client.writeStreamControl(&protocol.Header{RequestID: s.id, Kind: protocol.StreamWindowUpdate, Sequence: frame.sequence, Window: 1}); err != nil {
			s.complete(err, true)
			return nil, err
		}
	}
	return frame.body, nil
}
