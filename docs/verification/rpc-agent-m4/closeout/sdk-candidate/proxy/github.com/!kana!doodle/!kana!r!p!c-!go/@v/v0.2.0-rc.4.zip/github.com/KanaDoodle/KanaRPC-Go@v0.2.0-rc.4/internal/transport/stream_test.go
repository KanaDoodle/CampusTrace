package transport

import (
	"context"
	"errors"
	"net"
	"testing"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/internal/protocol"
)

func TestStreamProbeNeverSendsBusinessPayloadToLegacyPeer(t *testing.T) {
	c, peer := auditPipeClient(t)
	observed := make(chan *protocol.Message, 1)
	go func() {
		msg, _ := peer.Read()
		observed <- msg
		_ = peer.Write(&protocol.Message{Header: &protocol.Header{RequestID: msg.Header.RequestID, Error: "service not found"}})
	}()
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	_, err := c.OpenStream(ctx, &protocol.Message{Header: &protocol.Header{ServiceName: "Charge", MethodName: "Execute"}, Body: []byte(`{"secret":"business"}`)}, 2)
	if !errors.Is(err, ErrStreamingUnsupported) {
		t.Fatal(err)
	}
	probe := <-observed
	if probe.Header.Kind != protocol.StreamHello || probe.Header.ServiceName != "" || len(probe.Body) != 0 {
		t.Fatal("business payload reached legacy peer")
	}
}

func TestMalformedStreamDoesNotBlockReader(t *testing.T) {
	for _, scenario := range []string{"sequence", "overflow", "version"} {
		t.Run(scenario, func(t *testing.T) {
			c, peer := auditPipeClient(t)
			s := &ClientStream{client: c, id: 42, window: 1, queue: make(chan streamFrame, 1), accepted: make(chan struct{}), future: NewFuture()}
			c.streams = map[uint64]*ClientStream{42: s}
			if err := peer.Write(&protocol.Message{Header: &protocol.Header{RequestID: 42, Version: 1, Kind: protocol.StreamAccept, Window: 1}}); err != nil {
				t.Fatal(err)
			}
			sequence, version := uint64(1), uint8(1)
			if scenario == "sequence" {
				sequence = 2
			}
			if scenario == "version" {
				version = 2
			}
			if err := peer.Write(&protocol.Message{Header: &protocol.Header{RequestID: 42, Version: version, Kind: protocol.StreamData, Sequence: sequence}, Body: []byte(`1`)}); err != nil {
				t.Fatal(err)
			}
			if scenario == "overflow" {
				_ = peer.Write(&protocol.Message{Header: &protocol.Header{RequestID: 42, Version: 1, Kind: protocol.StreamData, Sequence: 2}, Body: []byte(`2`)})
			}
			ctx, cancel := context.WithTimeout(context.Background(), time.Second)
			defer cancel()
			if _, err := s.future.WaitWithContext(ctx); err == nil || errors.Is(err, context.DeadlineExceeded) {
				t.Fatal("invalid stream did not terminate", err)
			}
		})
	}
}

func TestOpenStreamRejectsClosedConnection(t *testing.T) {
	c, peer := auditPipeClient(t)
	_ = peer.Close()
	_ = c.Close()
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	if _, err := c.OpenStream(ctx, &protocol.Message{Header: &protocol.Header{}, Body: []byte(`{}`)}, 1); err == nil {
		t.Fatal("closed peer accepted")
	}
}

func TestStreamOpenBudgetDeductsWriteQueueTime(t *testing.T) {
	local, remote := net.Pipe()
	defer local.Close()
	defer remote.Close()
	conn := NewTCPConnection(local)
	peer := NewTCPConnection(remote)
	conn.writeMu <- struct{}{}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	finished := make(chan error, 1)
	go func() {
		finished <- conn.WriteContext(ctx, &protocol.Message{Header: &protocol.Header{Version: 1, Kind: protocol.StreamOpen, TimeoutNanos: int64(time.Second)}, Body: []byte(`{}`)})
	}()
	time.Sleep(80 * time.Millisecond)
	<-conn.writeMu
	msg, err := peer.Read()
	if err != nil {
		t.Fatal(err)
	}
	deadline, _ := ctx.Deadline()
	if msg.Header.TimeoutNanos > int64(time.Until(deadline)+40*time.Millisecond) {
		t.Fatal("write queue time was added back to remote budget", time.Duration(msg.Header.TimeoutNanos))
	}
	if err := <-finished; err != nil {
		t.Fatal(err)
	}
}

func TestStreamVersionRejectionReturnsWithoutWaitingForTimeout(t *testing.T) {
	c, peer := auditPipeClient(t)
	go func() {
		msg, _ := peer.Read()
		_ = peer.Write(&protocol.Message{Header: &protocol.Header{RequestID: msg.Header.RequestID, Version: 2, Kind: protocol.StreamEnd, Sequence: 1, Code: "unsupported_version", Error: "unsupported stream version"}})
	}()
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	_, err := c.OpenStream(ctx, &protocol.Message{Header: &protocol.Header{ServiceName: "test", MethodName: "Call"}, Body: []byte(`{}`)}, 1)
	if !errors.Is(err, ErrStreamingUnsupported) {
		t.Fatal("version rejection became a timeout", err)
	}
}
