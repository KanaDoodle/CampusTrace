package lab

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math/rand"
	"sort"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/inference/scheduler"
)

type Arrival struct {
	ID   string         `json:"id"`
	At   time.Duration  `json:"at_ns"`
	Work scheduler.Work `json:"work"`
}
type Sample struct {
	ID            string          `json:"id"`
	Worker        string          `json:"worker,omitempty"`
	Class         scheduler.Class `json:"class,omitempty"`
	Outcome       string          `json:"outcome"`
	TTFT          time.Duration   `json:"ttft_ns"`
	Elapsed       time.Duration   `json:"elapsed_ns"`
	PredictedTTFT time.Duration   `json:"predicted_ttft_ns,omitempty"`
}
type Distribution struct {
	N             int `json:"n"`
	P50, P95, P99 time.Duration
}

func distribution(values []time.Duration) Distribution {
	sort.Slice(values, func(i, j int) bool { return values[i] < values[j] })
	if len(values) == 0 {
		return Distribution{}
	}
	quantile := func(n int) time.Duration { return values[(len(values)*n+99)/100-1] }
	return Distribution{len(values), quantile(50), quantile(95), quantile(99)}
}

type RoutingResult struct {
	Evidence                                            string           `json:"evidence"`
	Scenario                                            string           `json:"scenario"`
	Seed                                                int64            `json:"seed"`
	TraceSHA256                                         string           `json:"trace_sha256"`
	Policy                                              scheduler.Policy `json:"policy"`
	Offered, Completed, Rejected, WithinTargetCompleted int
	Target                                              time.Duration `json:"target_ns"`
	AdmissionBudget                                     time.Duration `json:"admission_budget_ns"`
	TTFT, Elapsed                                       Distribution
	Samples                                             []Sample `json:"samples"`
}

func Trace(seed int64) []Arrival {
	rng := rand.New(rand.NewSource(seed))
	trace := make([]Arrival, 120)
	for i := range trace {
		work := scheduler.Work{PromptTokens: 32 + rng.Intn(65), OutputTokens: 8 + rng.Intn(25)}
		if rng.Intn(6) == 0 {
			work = scheduler.Work{PromptTokens: 1024 + rng.Intn(1025), OutputTokens: 128 + rng.Intn(129)}
		}
		trace[i] = Arrival{ID: fmt.Sprintf("request-%03d", i), At: time.Duration(i) * 120 * time.Millisecond, Work: work}
	}
	return trace
}

type simJob struct {
	arrival           Arrival
	worker            int
	reservation       *scheduler.Reservation
	first             bool
	firstAt, finishAt time.Duration
	predicted         time.Duration
}
type simEvent struct {
	at     time.Duration
	job    *simJob
	finish bool
}

// Routing runs a serial FIFO discrete-event service model, using the production
// Router unchanged. The engine model is intentionally NOT continuous batching.
// A wide 10-minute routing budget isolates placement; a separate 2s target is
// reported for every completed offered request. No failed sample is hidden.
func Routing(seed int64, policy scheduler.Policy, scenario string) (RoutingResult, error) {
	return RoutingWithBudget(seed, policy, scenario, 10*time.Minute)
}

// RoutingWithBudget additionally enables the same predicted-TTFT gate used in
// the gateway. Simulation does not hard-cancel jobs; prediction misses remain
// visible in WithinTargetCompleted instead of disappearing from the sample.
func RoutingWithBudget(seed int64, policy scheduler.Policy, scenario string, budget time.Duration) (RoutingResult, error) {
	if scenario != "heterogeneous" && scenario != "instance_slowdown" {
		return RoutingResult{}, fmt.Errorf("unknown scenario")
	}
	trace := Trace(seed)
	encoded, _ := json.Marshal(trace)
	hash := sha256.Sum256(encoded)
	result := RoutingResult{Evidence: "discrete-event-simulation-no-model", Scenario: scenario, Seed: seed, Policy: policy, TraceSHA256: hex.EncodeToString(hash[:]), Offered: len(trace), Target: 2 * time.Second, AdmissionBudget: budget}
	workers := make([]scheduler.Worker, 2)
	for i, speed := range []float64{1, .4} {
		workers[i] = scheduler.Worker{ID: fmt.Sprintf("w%d", i), Profile: scheduler.Profile{Model: Model, ID: fmt.Sprintf("synthetic-%d", i), TokenizerID: TokenizerID, PrefillTokensPerSecond: 2000 * speed, DecodeTokensPerSecond: 400 * speed, MaxInFlight: 256}}
	}
	virtual := time.Unix(0, 0)
	router, err := scheduler.NewRouter(scheduler.RouterConfig{Workers: workers, Policy: policy, StaleAfter: time.Minute, Now: func() time.Time { return virtual }})
	if err != nil {
		return result, err
	}
	active := []map[string]*simJob{{}, {}}
	nextFree := make([]time.Duration, 2)
	revision := uint64(0)
	observe := func() error {
		revision++
		for i, w := range workers {
			status := scheduler.WorkerStatus{Model: Model, ProfileID: w.Profile.ID, TokenizerID: TokenizerID, InstanceID: fmt.Sprintf("sim-%d", i), Revision: revision, Ready: true, TokenSource: "upstream_tokenizer_api", BackendKind: "discrete-event-simulation-no-model"}
			for id, j := range active[i] {
				status.Active = append(status.Active, scheduler.Invocation{ID: id, Work: j.arrival.Work, FirstText: j.first})
			}
			if err := router.Observe(w.ID, status); err != nil {
				return err
			}
		}
		return nil
	}
	if err := observe(); err != nil {
		return result, err
	}
	var events []simEvent
	advance := func(until time.Duration) error {
		for len(events) > 0 {
			sort.SliceStable(events, func(i, j int) bool { return events[i].at < events[j].at })
			if events[0].at > until {
				break
			}
			e := events[0]
			events = events[1:]
			virtual = time.Unix(0, int64(e.at))
			if e.finish {
				delete(active[e.job.worker], e.job.arrival.ID)
				e.job.reservation.Done()
				ttft := e.job.firstAt - e.job.arrival.At
				result.Completed++
				if ttft <= result.Target {
					result.WithinTargetCompleted++
				}
				result.Samples = append(result.Samples, Sample{ID: e.job.arrival.ID, Worker: workers[e.job.worker].ID, Outcome: "eof", TTFT: ttft, Elapsed: e.at - e.job.arrival.At, PredictedTTFT: e.job.predicted})
			} else {
				e.job.first = true
				e.job.reservation.FirstText()
			}
			if err := observe(); err != nil {
				return err
			}
		}
		virtual = time.Unix(0, int64(until))
		return nil
	}
	for _, arrival := range trace {
		if err := advance(arrival.At); err != nil {
			return result, err
		}
		res, err := router.Reserve(arrival.ID, arrival.Work, budget)
		if err != nil {
			result.Rejected++
			result.Samples = append(result.Samples, Sample{ID: arrival.ID, Outcome: err.Error()})
			continue
		}
		i := 0
		if res.Decision.WorkerID == "w1" {
			i = 1
		}
		profile := workers[i].Profile
		slowdown := 1.0
		start := max(nextFree[i], arrival.At)
		if scenario == "instance_slowdown" && i == 0 && start >= 5*time.Second {
			slowdown = 3
		}
		prefill := time.Duration(float64(time.Second) * float64(arrival.Work.PromptTokens) / profile.PrefillTokensPerSecond * slowdown)
		decode := time.Duration(float64(time.Second) * float64(arrival.Work.OutputTokens) / profile.DecodeTokensPerSecond * slowdown)
		job := &simJob{arrival: arrival, worker: i, reservation: res, firstAt: start + prefill, finishAt: start + prefill + decode, predicted: res.Decision.PredictedTTFT}
		nextFree[i] = job.finishAt
		active[i][arrival.ID] = job
		events = append(events, simEvent{at: job.firstAt, job: job}, simEvent{at: job.finishAt, job: job, finish: true})
		if err := observe(); err != nil {
			return result, err
		}
	}
	if err := advance(time.Hour); err != nil {
		return result, err
	}
	var ttfts, elapsed []time.Duration
	for _, s := range result.Samples {
		if s.Outcome == "eof" {
			ttfts = append(ttfts, s.TTFT)
			elapsed = append(elapsed, s.Elapsed)
		}
	}
	result.TTFT = distribution(ttfts)
	result.Elapsed = distribution(elapsed)
	sort.Slice(result.Samples, func(i, j int) bool { return result.Samples[i].ID < result.Samples[j].ID })
	return result, nil
}
