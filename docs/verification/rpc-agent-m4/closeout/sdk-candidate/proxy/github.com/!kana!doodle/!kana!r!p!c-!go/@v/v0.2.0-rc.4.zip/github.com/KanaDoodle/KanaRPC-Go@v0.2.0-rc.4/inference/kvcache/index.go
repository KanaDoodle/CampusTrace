// Package kvcache indexes event-observed prefix locations. A location is a hint,
// never proof that an inference will hit a GPU cache or finish faster.
package kvcache

import (
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"sort"
	"strings"
	"sync"
	"time"
)

const FixtureSource = "fixture-events-no-model"
const EngineSource = "vllm-events"

var ErrGap = errors.New("KV sequence gap: reset and cold rebuild required")

type Config struct {
	Namespace string           `json:"namespace"`
	BlockSize int              `json:"block_size"`
	Capacity  int              `json:"capacity_per_worker"`
	TTL       time.Duration    `json:"ttl_ns"`
	Now       func() time.Time `json:"-"`
}
type Owner struct {
	Worker      string `json:"worker"`
	Instance    string `json:"instance"`
	Model       string `json:"model"`
	Profile     string `json:"profile"`
	Tokenizer   string `json:"tokenizer"`
	Namespace   string `json:"namespace"`
	BackendKind string `json:"backend_kind,omitempty"`
}
type Reset struct {
	Owner
	PreviousEpoch string `json:"previous_epoch"`
	Epoch         string `json:"epoch"`
}
type Event struct {
	Type      string   `json:"type"`
	Hashes    []string `json:"hashes,omitempty"`
	Parent    string   `json:"parent,omitempty"`
	Tokens    []int    `json:"tokens,omitempty"`
	BlockSize int      `json:"block_size,omitempty"`
	Salt      string   `json:"salt,omitempty"`
}
type Batch struct {
	Owner
	Epoch    string  `json:"epoch"`
	Sequence uint64  `json:"sequence"`
	Source   string  `json:"source"`
	Events   []Event `json:"events"`
}
type key [32]byte
type Prefix struct {
	namespace string
	keys      []key
	blockSize int
}
type node struct {
	key   key
	salt  string
	depth int
}
type worker struct {
	owner                                                Owner
	epoch                                                string
	sequence                                             uint64
	started, valid                                       bool
	updated                                              time.Time
	source                                               string
	digest                                               key
	nodes                                                map[string]node
	keys                                                 map[key]int
	accepted, duplicates, gaps, resets, invalid, skipped uint64
}
type Index struct {
	mu      sync.Mutex
	cfg     Config
	workers map[string]*worker
}

func (i *Index) Namespace() string { return i.cfg.Namespace }

type Hint struct {
	Tokens int    `json:"estimated_reusable_tokens"`
	Source string `json:"source"`
	State  string `json:"state"`
}
type View struct {
	Worker     string `json:"worker"`
	Instance   string `json:"instance"`
	Epoch      string `json:"epoch"`
	Sequence   uint64 `json:"sequence"`
	Blocks     int    `json:"blocks"`
	Fresh      bool   `json:"fresh"`
	State      string `json:"state"`
	Source     string `json:"source"`
	Accepted   uint64 `json:"accepted_batches"`
	Duplicates uint64 `json:"duplicates"`
	Gaps       uint64 `json:"gaps"`
	Resets     uint64 `json:"resets"`
	Invalid    uint64 `json:"invalid"`
	Skipped    uint64 `json:"orphan_blocks_skipped"`
}

func New(cfg Config) (*Index, error) {
	if cfg.Namespace == "" || len(cfg.Namespace) > 256 || cfg.BlockSize < 1 || cfg.BlockSize > 1024 || cfg.Capacity < 1 || cfg.Capacity > 65536 || cfg.TTL <= 0 || cfg.TTL > time.Minute {
		return nil, errors.New("invalid KV namespace, block size, capacity or TTL")
	}
	if cfg.Now == nil {
		cfg.Now = time.Now
	}
	return &Index{cfg: cfg, workers: map[string]*worker{}}, nil
}
func (i *Index) Bind(owner Owner) error {
	if owner.Worker == "" || owner.Instance == "" || owner.Model == "" || owner.Profile == "" || owner.Tokenizer == "" || owner.Namespace != i.cfg.Namespace {
		return errors.New("invalid KV worker identity")
	}
	i.mu.Lock()
	defer i.mu.Unlock()
	if w := i.workers[owner.Worker]; w != nil && w.owner == owner {
		return nil
	}
	if i.workers[owner.Worker] == nil && len(i.workers) >= 64 {
		return errors.New("KV worker bound exceeded")
	}
	w := &worker{owner: owner}
	clear(w)
	i.workers[owner.Worker] = w
	return nil
}
func clear(w *worker) { w.nodes = map[string]node{}; w.keys = map[key]int{}; w.valid = false }
func epochValid(value string) bool {
	if len(value) != 32 {
		return false
	}
	_, err := hex.DecodeString(value)
	return err == nil
}
func (i *Index) Reset(reset Reset) error {
	i.mu.Lock()
	defer i.mu.Unlock()
	w := i.workers[reset.Worker]
	if w == nil || w.owner != reset.Owner || !epochValid(reset.Epoch) {
		return errors.New("KV reset identity or epoch mismatch")
	}
	if reset.Epoch == w.epoch {
		return nil
	} // retry of the same CAS reset is harmless
	if reset.PreviousEpoch != w.epoch {
		return errors.New("KV reset epoch compare-and-swap failed")
	}
	clear(w)
	w.epoch = reset.Epoch
	w.started = false
	w.source = ""
	w.resets++
	return nil
}
func validEvent(e Event, blockSize int) bool {
	if len(e.Hashes) > 256 || len(e.Tokens) > 256*blockSize || len(e.Salt) > 128 || len(e.Parent) > 128 {
		return false
	}
	switch e.Type {
	case "cleared":
		return len(e.Hashes) == 0 && len(e.Tokens) == 0 && e.Parent == "" && e.Salt == ""
	case "removed":
		if len(e.Tokens) != 0 || e.Parent != "" {
			return false
		}
	case "stored":
		if e.BlockSize != blockSize || len(e.Hashes) == 0 || len(e.Tokens) != len(e.Hashes)*blockSize {
			return false
		}
	default:
		return false
	}
	seen := map[string]bool{}
	for _, h := range e.Hashes {
		if h == "" || len(h) > 128 || seen[h] {
			return false
		}
		seen[h] = true
	}
	for _, token := range e.Tokens {
		if token < 0 || int64(token) > 1<<31-1 {
			return false
		}
	}
	return true
}
func root(namespace, salt string) key {
	data := []byte("KanaRPC-KV-prefix-v1\x00")
	for _, s := range []string{namespace, salt} {
		data = binary.BigEndian.AppendUint32(data, uint32(len(s)))
		data = append(data, s...)
	}
	return sha256.Sum256(data)
}
func next(parent key, tokens []int) key {
	data := make([]byte, 32, 32+4*len(tokens))
	copy(data, parent[:])
	for _, token := range tokens {
		data = binary.BigEndian.AppendUint32(data, uint32(token))
	}
	return sha256.Sum256(data)
}
func (i *Index) Prepare(salt string, tokens []int) (*Prefix, error) {
	if len(salt) > 128 || len(tokens) == 0 || len(tokens) > 1<<20 {
		return nil, errors.New("invalid prefix tokens or salt")
	}
	for _, token := range tokens {
		if token < 0 || int64(token) > 1<<31-1 {
			return nil, errors.New("invalid token id")
		}
	}
	// Keep at least one uncached token for logits; cap router hashing work.
	blocks := min((len(tokens)-1)/i.cfg.BlockSize, 256)
	p := &Prefix{namespace: i.cfg.Namespace, blockSize: i.cfg.BlockSize}
	parent := root(i.cfg.Namespace, salt)
	for b := 0; b < blocks; b++ {
		parent = next(parent, tokens[b*i.cfg.BlockSize:(b+1)*i.cfg.BlockSize])
		p.keys = append(p.keys, parent)
	}
	return p, nil
}
func (i *Index) Apply(batch Batch) error {
	i.mu.Lock()
	defer i.mu.Unlock()
	w := i.workers[batch.Worker]
	if w == nil || w.owner != batch.Owner || w.epoch == "" || batch.Epoch != w.epoch {
		return errors.New("KV batch identity or epoch mismatch")
	}
	if w.started && batch.Sequence < w.sequence {
		w.duplicates++
		return nil
	} // do not renew TTL
	if len(batch.Events) > 256 || (batch.Source != FixtureSource && batch.Source != EngineSource) || (w.source != "" && batch.Source != w.source) || ((strings.HasPrefix(w.owner.BackendKind, "fixture") || strings.HasPrefix(w.owner.BackendKind, "simulation")) && batch.Source != FixtureSource) {
		clear(w)
		w.started = true
		w.invalid++
		return errors.New("invalid KV batch bounds or source")
	}
	totalTokens, totalHashes := 0, 0
	for _, e := range batch.Events {
		totalTokens += len(e.Tokens)
		totalHashes += len(e.Hashes)
		if totalTokens > 65536 || totalHashes > 4096 {
			clear(w)
			w.started = true
			w.invalid++
			return errors.New("KV aggregate batch bound exceeded")
		}
	}
	for _, e := range batch.Events {
		if !validEvent(e, i.cfg.BlockSize) {
			clear(w)
			w.invalid++
			w.started = true
			return errors.New("invalid or unsupported KV event; cold reset required")
		}
	}
	encoded, _ := json.Marshal(struct {
		Source string
		Events []Event
	}{batch.Source, batch.Events})
	digest := sha256.Sum256(encoded)
	if w.started && batch.Sequence == w.sequence {
		if digest != w.digest {
			clear(w)
			w.invalid++
			return errors.New("conflicting KV sequence payload; cold reset required")
		}
		w.duplicates++
		return nil
	}
	if w.started && (!w.valid || batch.Sequence != w.sequence+1) {
		clear(w)
		w.gaps++
		return ErrGap
	}
	// Validate the entire batch before applying any event; malformed removals
	// must not leave a partly updated, apparently fresh index.
	for _, e := range batch.Events {
		switch e.Type {
		case "cleared":
			clear(w)
		case "removed":
			for _, id := range e.Hashes {
				remove(w, id)
			}
		case "stored":
			parent := root(i.cfg.Namespace, e.Salt)
			depth := 0
			if e.Parent != "" {
				p, ok := w.nodes[e.Parent]
				if !ok || (e.Salt != "" && e.Salt != p.salt) {
					w.skipped += uint64(len(e.Hashes))
					continue
				}
				parent = p.key
				depth = p.depth
				e.Salt = p.salt
			}
			for b, id := range e.Hashes {
				parent = next(parent, e.Tokens[b*i.cfg.BlockSize:(b+1)*i.cfg.BlockSize])
				depth++
				if previous, ok := w.nodes[id]; ok && previous != (node{parent, e.Salt, depth}) {
					clear(w)
					w.invalid++
					w.started = true
					return errors.New("conflicting KV block identity; cold reset required")
				}
				if _, ok := w.nodes[id]; ok {
					continue
				}
				if len(w.nodes) >= i.cfg.Capacity {
					clear(w)
					w.invalid++
					w.started = true
					return errors.New("KV index capacity exceeded; cold reset required")
				}
				w.nodes[id] = node{parent, e.Salt, depth}
				w.keys[parent]++
			}
		}
	}
	w.valid = true
	w.started = true
	w.sequence = batch.Sequence
	w.updated = i.cfg.Now()
	w.source = batch.Source
	w.digest = digest
	w.accepted++
	return nil
}
func remove(w *worker, id string) {
	if n, ok := w.nodes[id]; ok {
		delete(w.nodes, id)
		w.keys[n.key]--
		if w.keys[n.key] == 0 {
			delete(w.keys, n.key)
		}
	}
}
func (i *Index) state(w *worker) string {
	if w.epoch == "" {
		return "no_event_stream"
	}
	if !w.started {
		return "cold"
	}
	if !w.valid {
		return "desynchronized"
	}
	age := i.cfg.Now().Sub(w.updated)
	if age < 0 || age > i.cfg.TTL {
		return "stale"
	}
	return "fresh"
}
func (i *Index) Lookup(worker, instance string, prefix *Prefix) Hint {
	i.mu.Lock()
	defer i.mu.Unlock()
	w := i.workers[worker]
	if w == nil || w.owner.Instance != instance {
		return Hint{State: "identity_mismatch"}
	}
	state := i.state(w)
	hint := Hint{State: state, Source: w.source}
	if prefix == nil {
		hint.State = "no_token_ids"
		return hint
	}
	if prefix.namespace != i.cfg.Namespace || prefix.blockSize != i.cfg.BlockSize {
		hint.State = "namespace_mismatch"
		return hint
	}
	if state != "fresh" {
		return hint
	}
	for _, k := range prefix.keys {
		if w.keys[k] == 0 {
			break
		}
		hint.Tokens += i.cfg.BlockSize
	}
	return hint
}
func (i *Index) Snapshot() []View {
	i.mu.Lock()
	defer i.mu.Unlock()
	var result []View
	for id, w := range i.workers {
		state := i.state(w)
		result = append(result, View{Worker: id, Instance: w.owner.Instance, Epoch: w.epoch, Sequence: w.sequence, Blocks: len(w.nodes), Fresh: state == "fresh", State: state, Source: w.source, Accepted: w.accepted, Duplicates: w.duplicates, Gaps: w.gaps, Resets: w.resets, Invalid: w.invalid, Skipped: w.skipped})
	}
	sort.Slice(result, func(a, b int) bool { return result[a].Worker < result[b].Worker })
	return result
}
func (i *Index) String() string {
	return fmt.Sprintf("KV namespace=%s block_size=%d", i.cfg.Namespace, i.cfg.BlockSize)
}
