package server

import (
	"context"
	"encoding/json"
	"errors"
	"sync"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/internal/protocol"
	"github.com/KanaDoodle/KanaRPC-Go/internal/transport"
)

type StreamHandler func(context.Context, []byte, func([]byte) error) error
type streamMethod struct{ service, method string }

func (s *Server) RegisterStream(service, method string, handler StreamHandler) error {
	if service == "" || method == "" || handler == nil {
		return errors.New("stream service, method and handler required")
	}
	s.servicesMu.Lock()
	defer s.servicesMu.Unlock()
	if s.streamHandlers == nil {
		s.streamHandlers = make(map[streamMethod]StreamHandler)
	}
	key := streamMethod{service, method}
	if _, exists := s.streamHandlers[key]; exists {
		return errors.New("stream method already registered")
	}
	s.streamHandlers[key] = handler
	return nil
}

type streamSession struct {
	server   *Server
	conn     *transport.TCPConnection
	ctx      context.Context
	cancel   context.CancelFunc
	mu       sync.Mutex
	streams  map[uint64]*outboundStream
	requests *sync.WaitGroup
}

type outboundStream struct {
	session                *streamSession
	id                     uint64
	ctx                    context.Context
	cancel                 context.CancelFunc
	credits                chan struct{}
	sendMu                 sync.Mutex
	mu                     sync.Mutex
	sequence, acknowledged uint64
	ended                  bool
}

func newStreamSession(s *Server, conn *transport.TCPConnection, requests *sync.WaitGroup) *streamSession {
	ctx, cancel := context.WithCancel(context.Background())
	return &streamSession{server: s, conn: conn, ctx: ctx, cancel: cancel, streams: make(map[uint64]*outboundStream), requests: requests}
}

func (ss *streamSession) close() {
	ss.cancel()
	ss.mu.Lock()
	defer ss.mu.Unlock()
	for _, stream := range ss.streams {
		stream.cancel()
	}
}

func (ss *streamSession) write(msg *protocol.Message) error {
	ctx, cancel := context.WithTimeout(ss.ctx, transport.ControlWriteTimeout)
	defer cancel()
	return ss.conn.WriteContext(ctx, msg)
}

// handle never waits for a business execution slot. Full capacity must not stop
// the connection reader from observing CANCEL and WINDOW_UPDATE.
func (ss *streamSession) handle(msg *protocol.Message) error {
	h := msg.Header
	if h.Version != protocol.StreamVersion {
		return ss.reject(h.RequestID, "unsupported_version", "stream version 1 required")
	}
	switch h.Kind {
	case protocol.StreamHello:
		body, _ := json.Marshal(map[string]uint8{"stream_version": protocol.StreamVersion})
		return ss.write(&protocol.Message{Header: &protocol.Header{RequestID: h.RequestID, Version: protocol.StreamVersion, Kind: protocol.StreamHelloAck}, Body: body})
	case protocol.StreamCancel:
		ss.mu.Lock()
		stream := ss.streams[h.RequestID]
		ss.mu.Unlock()
		if stream != nil {
			stream.cancel()
		}
		return nil // cancellation is idempotent, including late cancellation
	case protocol.StreamWindowUpdate:
		ss.mu.Lock()
		stream := ss.streams[h.RequestID]
		ss.mu.Unlock()
		if stream == nil {
			return nil
		}
		return stream.update(h.Sequence, h.Window)
	case protocol.StreamOpen:
		return ss.open(msg)
	default:
		return errors.New("unexpected client stream frame")
	}
}

func (ss *streamSession) reject(id uint64, code, message string) error {
	return ss.write(&protocol.Message{Header: &protocol.Header{RequestID: id, Version: protocol.StreamVersion, Kind: protocol.StreamEnd, Sequence: 1, Code: code, Error: message}})
}

func (ss *streamSession) open(msg *protocol.Message) error {
	h := msg.Header
	if h.RequestID == 0 || h.Window == 0 || h.Window > protocol.MaxStreamWindow || h.TimeoutNanos <= 0 || h.Sequence != 0 ||
		(h.CodecType != 0 && h.CodecType != protocol.CodecTypeJSON) || !json.Valid(msg.Body) {
		return ss.reject(h.RequestID, "invalid_argument", "invalid stream request, window or time budget")
	}
	ss.server.servicesMu.RLock()
	handler := ss.server.streamHandlers[streamMethod{h.ServiceName, h.MethodName}]
	ss.server.servicesMu.RUnlock()
	if handler == nil {
		return ss.reject(h.RequestID, "unimplemented", "stream method not registered")
	}
	ss.mu.Lock()
	_, duplicate := ss.streams[h.RequestID]
	full := len(ss.streams) >= protocol.MaxStreamsPerConn
	ss.mu.Unlock()
	if duplicate {
		return errors.New("duplicate active stream request id")
	}
	if full {
		return ss.reject(h.RequestID, "resource_exhausted", "connection stream capacity reached")
	}
	if !ss.server.admit(ss.requests) {
		return ss.reject(h.RequestID, "resource_exhausted", "server execution capacity reached or server closing")
	}
	if !ss.server.limiter.Allow() {
		ss.requests.Done()
		<-ss.server.workerSem
		return ss.reject(h.RequestID, "resource_exhausted", "rate limit exceeded")
	}
	budget := time.Duration(h.TimeoutNanos)
	if budget > 10*time.Minute {
		budget = 10 * time.Minute
	}
	ctx, cancel := context.WithTimeout(ss.ctx, budget)
	stream := &outboundStream{session: ss, id: h.RequestID, ctx: ctx, cancel: cancel, credits: make(chan struct{}, h.Window)}
	for i := uint32(0); i < h.Window; i++ {
		stream.credits <- struct{}{}
	}
	ss.mu.Lock()
	ss.streams[h.RequestID] = stream
	ss.mu.Unlock()
	if err := ss.write(&protocol.Message{Header: &protocol.Header{RequestID: h.RequestID, Version: protocol.StreamVersion, Kind: protocol.StreamAccept, Window: h.Window}}); err != nil {
		cancel()
		ss.mu.Lock()
		delete(ss.streams, h.RequestID)
		ss.mu.Unlock()
		ss.requests.Done()
		<-ss.server.workerSem
		return err
	}
	go func() {
		defer ss.requests.Done()
		defer func() { <-ss.server.workerSem }()
		defer cancel()
		defer func() { ss.mu.Lock(); delete(ss.streams, h.RequestID); ss.mu.Unlock() }()
		var err error
		defer func() {
			if recover() != nil {
				err = errors.New("stream handler panic")
			}
			if ctx.Err() != nil {
				err = ctx.Err()
			}
			stream.finish(err)
		}()
		if ctx.Err() != nil {
			err = ctx.Err()
			return
		}
		err = handler(ctx, msg.Body, stream.send)
	}()
	return nil
}

// admit linearizes execution admission with Shutdown and never blocks a reader.
func (s *Server) admit(requests *sync.WaitGroup) bool {
	s.connsMu.Lock()
	defer s.connsMu.Unlock()
	select {
	case <-s.closing:
		return false
	default:
	}
	select {
	case s.workerSem <- struct{}{}:
		requests.Add(1)
		return true
	default:
		return false
	}
}

func (s *outboundStream) send(body []byte) error {
	if len(body) > protocol.MaxStreamChunkSize || !json.Valid(body) {
		return errors.New("stream chunk must be JSON and at most 64 KiB")
	}
	s.sendMu.Lock()
	defer s.sendMu.Unlock()
	select {
	case <-s.ctx.Done():
		return s.ctx.Err()
	case <-s.credits:
	}
	if err := s.ctx.Err(); err != nil {
		return err
	}
	s.mu.Lock()
	if s.ended {
		s.mu.Unlock()
		return errors.New("stream already ended")
	}
	s.sequence++
	sequence := s.sequence
	s.mu.Unlock()
	// Finish an already-started frame even if only this stream is canceled.
	// A socket write deadline belongs to the connection, not an individual RPC.
	ctx, cancel := context.WithTimeout(s.session.ctx, transport.ControlWriteTimeout)
	defer cancel()
	return s.session.conn.WriteContext(ctx, &protocol.Message{Header: &protocol.Header{RequestID: s.id, Version: protocol.StreamVersion, Kind: protocol.StreamData, Sequence: sequence}, Body: body})
}

func (s *outboundStream) update(sequence uint64, credit uint32) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.ended {
		return nil
	}
	if credit != 1 || sequence != s.acknowledged+1 || sequence > s.sequence {
		return errors.New("invalid stream credit acknowledgement")
	}
	s.acknowledged = sequence
	select {
	case s.credits <- struct{}{}:
		return nil
	default:
		return errors.New("stream credit overflow")
	}
}

func (s *outboundStream) finish(err error) {
	s.sendMu.Lock()
	defer s.sendMu.Unlock()
	s.mu.Lock()
	s.ended = true
	sequence := s.sequence + 1
	s.mu.Unlock()
	code, message := "", ""
	if err != nil {
		message = err.Error()
		if len(message) > 1024 {
			message = message[:1024]
		}
		switch {
		case errors.Is(err, context.Canceled):
			code = "canceled"
		case errors.Is(err, context.DeadlineExceeded):
			code = "deadline_exceeded"
		default:
			code = "internal"
			var coded interface{ RPCCode() string }
			if errors.As(err, &coded) {
				switch coded.RPCCode() {
				case "resource_exhausted", "queue_timeout", "slo_unachievable", "slo_exceeded", "unavailable", "invalid_argument":
					code = coded.RPCCode()
				}
			}
		}
	}
	if writeErr := s.session.write(&protocol.Message{Header: &protocol.Header{RequestID: s.id, Version: protocol.StreamVersion, Kind: protocol.StreamEnd, Sequence: sequence, Code: code, Error: message}}); writeErr != nil {
		_ = s.session.conn.Close()
	}
}

func overloadResponse(msg *protocol.Message) *protocol.Message {
	return &protocol.Message{Header: &protocol.Header{RequestID: msg.Header.RequestID, Error: "server execution capacity reached or server closing"}}
}
