# M3 KV 缓存感知路由与饱和转移验收

日期：2026-10-30。结论：**实现与本地分阶段验收完成；真实 vLLM KV 事件、实际缓存命中、双实例 GPU 性能仍待验。** 下述命中与延迟对照全部是模拟或无模型 fixture，没有真实推理收益结论。

基线是未提交的 M1+M2 工作区，已保存在 `/private/tmp/kanarpc-before-m3.tgz` / `.patch`。保留原有改动，没有重置、提交或发布。相对 M2 的文件和 SHA256 见 [changes-from-m2.json](changes-from-m2.json)；Go module 依赖未变，仅事件桥使用独立的可选 Python 依赖。

## 分阶段实施与验证

| 阶段 | 修改 | 证据 |
| --- | --- | --- |
| 1. 事件位置索引 | 新 `inference/kvcache`；精确 token 完整块前缀；namespace/盐/身份；stored/removed/cleared；CAS epoch、sequence、TTL、容量上限、冷重建 | 存储/移除/清空、祖先缺失、盐/模板/boot 隔离、重复不续鲜、缺口、冲突、容量/聚合上限、来源标签、并发读写；[stage1-race.txt](stage1-race.txt)，最终 [phases-final-race.txt](phases-final-race.txt) |
| 2. 路由与转移 | 复用 M2 原子预留；cache_affinity 消融、cache_aware 成本/排队比较、最小收益门槛；冷接纳预算不打折、无提示严格退回 token_work | 亲和与负载对照、热点、满容量、排队成本超过收益、冷预算拒绝、TTL、精确降级、并发容量；[stage2-race.txt](stage2-race.txt)，全项目最终回归包含新增降级用例 |
| 3. 接入与生命周期 | Worker 可返回精确 token IDs，缺失/非法/过大禁用提示；转发 cache_salt；上游 cached_tokens 可选解析；gateway KV 管理端；固定 vLLM v0.32.0 子集 bridge | 真实 TCP/HTTP 流与控制面、饱和改选、缺口失效、盐隔离、usage、取消；8 个 Python 测试及真实 ZMQ；新旧桥交接；[stage3-gateway-race.txt](stage3-gateway-race.txt)、[python-tests.txt](python-tests.txt) |
| 4. 对照与交付 | 可运行 kv-routing-lab、进程验证、示例配置、真实 opt-in 入口及 CI 步骤 | 63 组固定轨迹模拟；11 项进程检查；普通/race/vet/fuzz/benchmark；M1/M2 进程回归；完整原始结果在本目录 |

接口、算法公式、边界和运行方法见 [实施说明](../../implementation/kv-routing-m3.md)。没有新增自动生成重试、KV 数据传输、运行中迁移、跨网关协调或动态成员管理；核心 unary/Future/etcd 实现没有为 M3 重构。

## 测试确认并修复的新增实现问题

四项都先复现失败再修复；这里指 M3 开发过程中的问题，不把它们描述成此前发布版本的漏洞。

### 1. 首个非法批次未要求显式冷重建

首次事件来源非法时，清空了索引，却没设置“已开始且失效”的围栏；下一有效批次会在同 epoch 直接恢复。复现：

```bash
go test -v ./inference/kvcache -run '^TestInvalidFirstBatchRequiresExplicitReset$'
```

修复前 [invalid-first-before.txt](invalid-first-before.txt) 报 `invalid first batch healed without reset`。现在非法首批次进入 desynchronized，后续必须 CAS reset；原样本与最终普通/race 均通过。

### 2. 同序列不同载荷被误当成重复

原实现把所有 `sequence <= last_sequence` 都忽略，包含“已存储 root”与“移除 root”错误共用同一序列的冲突，旧提示仍然存在。复现：

```bash
go test -v ./inference/kvcache -run '^TestConflictingDuplicateCannotPreserveCacheCredit$'
```

修复前见 [conflicting-duplicate-before.txt](conflicting-duplicate-before.txt)。现在对有界、合法的规范化事件计算载荷摘要；同序列同摘要才作为重传且不续鲜，冲突则清空并要求冷 reset。较老序列仍忽略、不续鲜；Python bridge 同时比较载荷指纹，防止发布者重启后的序号复用被吞掉。回归通过。

### 3. 无缓存提示时，缓存排队上限改变了 token_work 降级

异构实例中，快实例已有 200ms decode 预留，慢实例冷处理要 9s；没有 token IDs 时，原 cache queue cap 仍排除快实例，错误地选择慢实例。复现：

```bash
go test -v ./inference/scheduler \
  -run '^TestMissingHintsPreserveTokenWorkChoiceUnderHeterogeneousLoad$'
```

修复前 [fallback-before.txt](fallback-before.txt) 的决策为慢实例 `b`、预测 9s，虽标注 `load_no_token_ids` 却并未真正按负载降级。现在排队上限只约束有缓存吸引力的候选，缺失提示时保持 token_work 的选择；对应测试及 3 轮 race、全项目回归通过。

### 4. 旧桥重置/关闭可能干扰新桥 epoch

Go 索引已有 CAS，但原 bridge 在每次 reset 时重新读取最新 epoch，旧桥也可能因此领取并清空新流；finally 的关闭清理沿用该逻辑。复现：

```bash
PYTHONDONTWRITEBYTECODE=1 /tmp/kanarpc-kv-venv/bin/python \
  -m unittest discover -s scripts -p test_kv_event_bridge.py -k stale_bridge -v
```

修复前见 [bridge-fence-before.txt](bridge-fence-before.txt)。现在已持有流的旧桥发现 epoch 被替换就 fenced 退出；关闭只使用自己保存的 owner/epoch 做 CAS，不读取并覆盖新流。

除了 2 个对应 Python 用例，独立进程验收还实际启动新桥接管同一 publisher，旧桥退出后新 epoch 与节点仍保留：[process/bridge-handoff-fencing.json](process/bridge-handoff-fencing.json)。8 个 Python 测试与整条进程链路均通过。

## 对照结果与负面结论

原始 63 组全样本见 [comparison.json](comparison.json)，表格见 [comparison-summary.md](comparison-summary.md)。复现：

```bash
go run ./cmd/kv-routing-lab -output /tmp/kv-comparison.json
python3 scripts/summarize-kv-routing.py /tmp/kv-comparison.json
```

### 实验模型

复用实际 Router/Index，配合**串行 FIFO 合成引擎**。2 实例，名义速率相同：prefill 2000、decode 400 token/s；每请求 264 个输入 token，最多模拟复用前 256，输出 16；每 70ms 到达一个请求。7 场景 × 种子 1/7/42 × token_work/cache_affinity/cache_aware，共 7560 offered。各场景/种子的 token/盐/到达轨迹 SHA256 在三策略间一致。

统计目标 500ms，冷模型接纳预算 3s；本模型不硬取消 500ms 超标请求，仍计入总分母。全部请求最终完成，拒绝为 0，不能把最终完成率当成 SLO 达成率。cache_aware 使用 100ms 缓存排队上限、1ms 最小估计收益、saving_fraction=1。模拟在 first-text 事件写入缓存并上报事件，未模拟 continuous batching、KV 内存带宽、容量抢占、GPU 或真实 HTTP 开销。

模拟引擎的缓存状态独立于提示索引：`HintRequests` 是选址时的提示，`SimulatedHitRequests` 是服务开始时的模拟实际命中；`FalseHintRequests` 是有提示却未命中，`MissedHintRequests` 是无提示却命中。M2 自然命中不能算成 M3 带来的全部收益。

### 主要结果（各场景 3 种子合计，各策略 offered=360）

| 场景 | token_work | cache_affinity | cache_aware | 结论边界 |
| --- | --- | --- | --- | --- |
| 重复前缀 | 模拟命中 322，p95 各 132ms | 命中 326，p95 各 132ms | 命中 324，p95 各 132ms | 命中数有小差异，没有 p95 改善；不是推理加速证明 |
| 冷前缀 | 命中 0，目标内 75/360 | 同左 | 同左 | 没有编造缓存命中；目标内完成率很低，即使最终全部完成 |
| 热点实例 | 目标内 359/360 | 344/360 | 359/360 | 饱和改选抑制纯亲和的部分退化，没有超过负载基线 |
| 淘汰 | 命中 292 | 304 | 300 | 清除事件减少旧提示；三者 p95 均为 132ms |
| 丢事件 | 假阳性提示 0（无缓存提示） | 4 | 4 | 缺口被观察到之前仍可误判；冷重建不能抹去已发生误判 |
| 事件停止 | 假阳性提示 0（无缓存提示） | 8 | 8 | TTL 到期前的窗口仍有误判，之后降级负载路由 |
| 实例减速 | 目标内 358/360 | 294/360 | 358/360 | 相比纯亲和更稳，仍不是普遍更优 |

减速场景在虚拟 3s 后把 w0 的实际处理耗时变为 4 倍，保留旧校准。token_work p95 为 **132 / 144 / 146ms**，cache_affinity 为 **2492 / 528 / 2352ms**，cache_aware 为 **132 / 158 / 138ms**。cache_aware 在种子 7 仍比负载基线更差，不能只展示它相对纯亲和的收益。热点场景的 p95 与达标数也并非总是同向，完整表格保留全部值。

这些数据只说明此合成模型与有限轨迹下的行为；没有确认真实 cache hit ratio、vLLM goodput 或 GPU 延迟收益。

## 真实网络进程验收，无模型

```bash
python3 -m venv /tmp/kanarpc-kv-venv
/tmp/kanarpc-kv-venv/bin/python -m pip install -r scripts/requirements-kv.txt
PYTHONDONTWRITEBYTECODE=1 /tmp/kanarpc-kv-venv/bin/python \
  scripts/verify-kv-routing.py --output /tmp/kanarpc-kv-process
```

实际启动 SSE fixture、2 个 RPC worker、gateway、ZMQ bridge、检查客户端，交接用例另启动新 bridge。使用真实 loopback TCP/HTTP/ZMQ 与**手工构造的固定协议事件**。11 项检查通过：冷索引、暖索引、不同盐、饱和改选、事件缺口、重建、root 淘汰、未知事件、TTL 过期、提前取消、桥交接围栏。

接收结果、最终状态及各进程日志见 [process/result.json](process/result.json)、[process/final.json](process/final.json) 和同目录文件。fixture 没有生成 cached_tokens，warm 决策也没有被伪装成实际命中。脚本会等待并停止自己启动的进程；这些不是 vLLM 或模型验证。

## 普通、race、fuzz、benchmark 与回归

环境：Apple M5、darwin/arm64、Go 1.27.1、Python 3.14.7；独立 etcd 3.7.1（32379/32380）。可选依赖在临时 venv：pyzmq 27.1.0、msgpack 1.1.2。Go module 最低版本仍为 1.25.9，未改依赖；没有远端 CI 执行结果。

| 检查 | 最终结果 |
| --- | --- |
| `KANARPC_TEST_ETCD=127.0.0.1:32379 go test -count=1 -timeout=120s -json ./...` | **141 顶层 PASS，3 SKIP，0 FAIL**；14 个含测试包 PASS |
| 同上加 `-race` | 同样 **141 PASS，3 SKIP，0 FAIL**，没有 race 报告 |
| Index / scheduler / gateway / vllm 各 3 轮 race | PASS，[phases-final-race.txt](phases-final-race.txt) |
| 实际路由/索引模拟确定性和全样本核对 | PASS，重复运行相同结果，所有策略同 trace hash，[simulation-race.txt](simulation-race.txt) |
| Python bridge 测试 | 8 PASS，[python-tests.txt](python-tests.txt) |
| 新进程链路 | 11 项 PASS，包含真正的新旧桥交接 |
| M1 原进程链路 | PASS，[m1-process-regression.txt](m1-process-regression.txt) |
| M2 进程链路 + 隔离 etcd 发现 | PASS，[m2-process-regression.txt](m2-process-regression.txt) |
| `go vet ./...`、脚本语法与文档链接 | PASS，见 checks.json |
| KV 批次 fuzz 20s、4 workers | **3,549,411 次执行，PASS**，[fuzz.txt](fuzz.txt) |

完整测试终态和包耗时见 [test-results.json](test-results.json)。三项 SKIP 明确为 `TestRealVLLMThroughRPC`、`TestRealVLLMThroughScheduledGateway`、`TestRealVLLMKVEventRouting`；未配置真实服务时不会改用 fixture 冒充通过。

### CPU 与内存开销

原始输出见 [benchmark.txt](benchmark.txt)。2 个块的已准备前缀 Lookup：约 **32–48ns/op、0B/op、0 allocs/op**，不包含 tokenization/Prepare、网络或真实推理，不能外推成全路由成本。

复用 M2 的 8 worker 路由基准：0 在途时约 **748–763ns/op、3872B/op、13 allocs/op**；每 worker 64 在途时约 **29.4–35.7µs/op、131680B/op、93 allocs/op**。与 M2 保存的同一基准相比，分配量从 2096 / 129904B 增至 3872 / 131680B，均增加 **1776B/op**，来自候选/决策元数据扩展；没有声称无性能回归。时间受当时并行检查等环境影响，不给跨轮 CPU 倍率结论。

这是新增能力的实际开销，应在生产规模前优化为更紧凑的候选/增量负载聚合；本轮没有为了掩盖该成本大规模改写 M2。没有在真实模型中测量额外 tokenize IDs、hash Prepare 和 bridge 事件处理对端到端时延的影响。

## 尚未解决的设计风险与下一步

1. **真实数据与兼容性待验。** 仅对照固定 vLLM v0.32.0 源码和手工 wire fixture；未实际运行它。仅支持单 DP、单 FullAttention group、本地 GPU、文本、无 LoRA/MM/offload/partial-tail 的子集。配置 namespace/profile/布局不是自动检测，更不是引擎身份认证。[upstream-provenance.json](upstream-provenance.json) 记录固定来源与文件摘要。
2. **提示有误差窗口。** TTL、sequence 和 CAS 减少错误，不保证从源头观察到全部淘汰。上游未发出的事件、最后一条丢失直到下一条到达、桥无法连接管理端时仍可暂时误判。模拟已经记录假阳性，所以缓存不放宽冷预算，也不伪造实际命中。
3. **重建与规模。** 当前是空索引冷重建，不实现 replay 补洞/完整快照；失去父链时只减少提示。索引超容量会整体失效，长前缀 Prepare 有上限。大型引擎与高事件率可能频繁降级；CPU/分配已有新增开销，需真实负载测量。
4. **单网关和授权。** 索引/配额只在单进程，worker 池静态；无 TLS/auth，cache_salt 只做键空间隔离，不证明租户授权或隐私。控制面接触 token ID；派生 hash 也不能被当成隐私保护证明。新旧桥支持受围栏的交接，不支持多个 publisher 聚合或全局协调。
5. **校准与饱和。** 仍是静态 prefill/decode 速率，缓存节省是假设值，没有真实 GPU/KV 压力或带宽反馈。TTFT 指网关首文本，非逐 token ITL；转移发生在发送前，不迁移已经执行的请求。M1 的 TCP 队头阻塞、64KiB 封装边界及取消后关闭语义继续存在。

最值得接着做的三件事：

1. 运行真实双实例 vLLM 验收，校准缓存收益/排队误差，保留 token_work 与纯亲和基线，按上游实际 cached_tokens 和全部 offered 统计目标内完成；在这之前不宣布推理加速。
2. 根据真实事件量决定 replay 补洞、快照/代际恢复和紧凑索引，加入真实引擎压力及校准漂移的降级策略，再优化已测到的候选分配成本。
3. 再推进多网关一致性、worker 生命周期及身份授权/摘流 drain，随后进入既定 M4 的 CampusTrace 业务接入；不把单进程测试结果扩大成集群保证。

真实验收入口和 vLLM 启动/bridge 配置见 [实施说明](../../implementation/kv-routing-m3.md)。该入口会检查流、事件提示和上游报告的 cached_tokens；即使功能通过，也仍需单独的性能实验。
