# M2 token 工作量调度与延迟目标治理验收

日期：2026-10-30。结论：**M2 实现及本地功能验收完成；真实 vLLM/GPU 功能与多实例性能验收仍待做。** 没有把模拟或 SSE fixture 数据视为真实推理收益。

本轮以前一轮未提交的 M1 工作区为基线，保留原有修改；没有 reset、提交或发布，也没有改依赖。M2 相对 M1 的文件与 SHA256 见 [changes-from-m1.json](changes-from-m1.json)。M1 原始工作区备份仍在 `/private/tmp/kanarpc-before-m2.tgz` / `.patch`。当前 HEAD 之前的差异同时包含 M1，不能把 `git diff HEAD` 当成 M2 独有改动。

## 实现范围与分阶段验证

| 阶段 | 实现 | 验证 |
| --- | --- | --- |
| 工作量与选址 | 上游 `/tokenize` 含 chat template 的输入计数；max_tokens 输出预留；模型/profile/tokenizer 身份；RR / least_in_flight / token_work；快照与本地预留去重；TTL、不可达排除和显式降级 | 长任务 vs 多个短任务；并发容量；快照去重；指标失效/不匹配；复用实际 Router 的固定轨迹对照；预算 fuzz、CPU 微基准 |
| 接纳与排队 | 交互/批量固定分区；执行数/token、排队数/token 四重上限；类内 FIFO；过期不派发；取消/授予/关闭一次性释放；shared FIFO 对照 | 隔离/共享对照；FIFO、批量进度；排队 token 上限和过期；100 次取消/授予/关闭竞争；核心包 3 轮 race |
| Worker/网关 | 独立管理 HTTP，不占满载 RPC 业务名额；count → queue → reserve → 一次 stream 转发；scheduled/chunk/summary；首文本与总执行预算；结构化状态和拒绝熔断中性 | 真实 TCP/HTTP；满载仍可读状态；正常 usage；超时取消 HTTP；排队过期不进模型；取消不使健康 worker 失效；过期状态拒绝；关闭归零；后端出错不重放；24 次 SLO 拒绝后正常调用；网关 3 轮 race |
| 对照与入口 | inference-gateway、worker 管理参数、scheduled 验收客户端、无模型实验工具、示例配置、CI 验证步骤 | 36 组固定轨迹模拟；6 组真实 loopback TCP/HTTP 定时 fixture；4 个独立进程，直接地址和隔离 etcd 各验收；旧 M1 命令链路回归 |

使用与协议语义见 [M2 实施说明](../../implementation/scheduling-m2.md)。生产 RPC 核心只补充结构化流状态与接纳拒绝的熔断分类；调度和接纳放在新 inference 包内，没有重构无关的同步 RPC、etcd 或 Future。

## 测试确认并修复的问题

### 1. 调用者在分词期间取消，误使健康 worker 不可用

**复现：** fixture tokenizer 延迟 80ms，调用者 30ms 截止。等待该请求清理后，不刷新状态，再查询 worker 可用性并发起正常请求。

```bash
go test -count=1 -v ./inference/gateway \
  -run '^TestGatewayCallerCancelDuringTokenizationKeepsWorkerHealthy$'
```

修复前失败证据见 [cancel-before.txt](cancel-before.txt)：`caller cancellation invalidated a healthy worker`。根因是控制 HTTP 抹去底层错误后，网关把所有分词错误都作为 worker 健康失败，包含调用者取消/预算耗尽。

**修改：** 在标记 worker 不可用前检查父调用的 Context；自身预算或取消直接返回，不修改 worker 健康。独立的控制请求超时、协议/身份错误仍排除实例。

**回归：** 此用例在网关 3 轮 race 和全项目普通/race 中通过，取消后无需刷新即可继续使用同一健康 worker。见 [gateway-race.txt](gateway-race.txt)。

### 2. 极大预算的浮点时间转换越过整数预算

**复现：** fuzz 给出公开 Router 的边界输入，预算 `9223372036854775801ns`，预测值转换为 `9223372036854775807ns`，比预算多 6ns。失败样本已纳入版本目录：

```bash
go test -v ./inference/scheduler \
  -run 'FuzzRouterBudgetBoundaries/f1b4c7c006b81b7e'
```

修复前见 [fuzz-before.txt](fuzz-before.txt)。根因是先比较浮点秒，再转整数 ns；极大 duration 附近浮点精度不足，转换后的整数不再满足原预算。

**修改：** 估算保守向上取整，拒绝超出 duration 可表示范围的值，并再次用整数 ns 检查预算。保留 fuzz 样本以防回归。

**回归：** 原失败样本通过，[boundary-after.txt](boundary-after.txt)；随后 fuzz 20s、4 workers，**5,058,735 次执行，PASS**，见 [fuzz-after.txt](fuzz-after.txt)。该极值约为 292 年，网关总执行预算最多 10 分钟，本问题属于独立 Router API 的边界正确性，不夸大为常规调用中的严重故障。

其余并发/取消/过期测试未确认新的故障；不把代码推测列成“已发现 bug”，也不声称有限测试证明不存在其他问题。

## 对照结果：同时保留收益与退化

全样本见 [comparison.json](comparison.json)，自动生成的完整表格见 [comparison-summary.md](comparison-summary.md)。复现：

```bash
go run ./cmd/scheduling-lab -output /tmp/scheduling-comparison.json -repeats 3
python3 scripts/summarize-scheduling.py /tmp/scheduling-comparison.json
```

### 选址：离散事件模拟，不是 vLLM

两个合成 FIFO 串行服务实例，prefill/decode 速率分别为 2000/400 与 800/160 token/s；每 120ms 到达一个请求，约 1/6 为长任务。种子 1、7、42 各 120 个请求，同一种子各策略使用相同 trace SHA256。不是 continuous batching，也没有网络/GPU/KV 模型。

- **600s 接纳预算隔离选址影响，统计目标为 2s：** 正常异构场景 token_work 的各种子 p95 为 **11.641 / 6.298 / 9.964s**，RR 为 **29.186 / 21.523 / 22.102s**。但目标内完成数分别只有 108/360 与 93/360；不能只给 p95 比例而隐去过载。
- **减速负例：** 第一个实例在服务开始时间达到 5s 后变为 3 倍耗时，校准仍保持旧值。600s 预算下 token_work p95 为 **44.562 / 24.894 / 32.939s**，全部差于 RR 的 **29.444 / 21.700 / 30.558s**。静态 token 成本不能保证负载变化时尾延迟更优。
- **相同 2s 预测接纳门槛：** 正常异构场景 token_work 达标 327/360，least_in_flight 为 328/360，未胜出；实例减速时分别为 263/360、255/360，RR 为 221/360。拒绝及已接纳但超标的调用全部保留。预测失准仍会超标，网关硬首文本预算因此必须单独执行。

这组结果支持保留可切换策略和校准/漂移风险，不支持宣布 token 路由普遍优于基线。模拟完成耗时为虚拟时间，不能折算实际 GPU goodput。

### 队列：真实本地 TCP/HTTP，后端只有定时器

每轮先到 8 个 batch，随后 12 个 interactive。SSE 首文本分别延迟 160ms / 10ms；交互目标 150ms；总接纳并行度相同，为 3。比较共享 FIFO 和交互 2 / 批量 1 固定分区，各 3 轮，输入到达时间相同。

| 策略 | 全部完成/offered（3 轮合计） | 交互目标内完成/offered | 批量完成/offered | 失败 | 单轮整体耗时 |
| --- | ---: | ---: | ---: | --- | --- |
| shared FIFO | 24/60 | 0/36 | 24/24 | 36 queue_timeout | 约 0.486–0.488s |
| 固定分区 | 60/60 | 36/36 | 24/24 | 0 | 约 1.290–1.295s |

固定分区交互成功样本的单轮 p95 为 22.17 / 11.31 / 11.76ms；共享策略没有成功交互样本，p95 为 **N/A**，不是 0ms。该构造案例验证队列隔离和批量进度，代价是批量整体完成更慢。它没有模拟实际 GPU 内部的资源争用，也没有给交互请求保留 GPU 或 KV 容量。

## 全项目验证与实际进程验证

本机：Apple M5、darwin/arm64、Go 1.27.1；go.mod 最低版本仍为 1.25.9。隔离 etcd **3.7.1**，独占本次测试端口 32379/32380；不操作共享 etcd。CI 文件仍配置其原来的 etcd 3.6.7，本轮没有远端 CI 运行结果。

| 检查 | 结果 |
| --- | --- |
| `KANARPC_TEST_ETCD=127.0.0.1:32379 go test -count=1 -timeout=120s -json ./...` | 118 个顶层测试 PASS，2 SKIP，0 FAIL；13 个含测试包 PASS |
| 同上加 `-race` | 同样 118 PASS、2 SKIP、0 FAIL；没有 race 报告 |
| scheduler 核心 3 轮 race | PASS，[core-race.txt](core-race.txt) |
| gateway 3 轮 race | PASS，[gateway-race.txt](gateway-race.txt) |
| `go vet ./...` | PASS，无输出 |
| 调度预算 fuzz 20s | PASS，5,058,735 次执行 |
| `bash -n` 两个验收脚本 | PASS |
| M2 四进程，直接地址 | 完成/批量完成/提前取消/HTTP 取消/预测 SLO 拒绝/资源归零全部 PASS |
| M2 四进程，独立 etcd 发现 gateway | 同上 PASS；M1 worker 池仍为静态配置，不把 gateway 注册发现称为动态 worker 管理 |
| 旧 M1 三进程链路 | PASS，见 [m1-process-regression.txt](m1-process-regression.txt) |

完整测试终态及包耗时见 [test-results.json](test-results.json)；四进程接收结果、最终网关/worker 状态见 `process-direct/`、`process-etcd/`。脚本会结束它创建的子进程，测试 etcd 由本轮所有者结束。

两项 SKIP 为 `TestRealVLLMThroughRPC`、`TestRealVLLMThroughScheduledGateway`，原因是未配置真实服务。它们没有用 fixture 替代成功，也没有真实模型/GPU 数据。

### CPU 路由开销（不是推理吞吐）

```bash
go test ./inference/scheduler -run '^$' -bench BenchmarkTokenRouting \
  -benchmem -benchtime=500ms -count=3
```

8 个 worker、每 worker 0 在途：约 548ns/op、2096B/op、13 allocs/op；每 worker 64 在途：约 28.2–30.6µs/op、129904B/op、93 allocs/op。原始输出见 [benchmark.txt](benchmark.txt)。测试只包含本进程 Reserve/Done 及快照去重计算，排除网络、tokenizer 和模型；每次选址复制有效在途集合带来明显分配，未来规模扩大前值得做增量聚合，但本轮不为追求指标改写整套调度。

## 尚未解决的设计风险

1. **真实引擎与校准差异：** 未连接真实 vLLM；手工速率不反映 continuous batching、GPU/KV 压力、长短请求干扰；减速模拟已经暴露 p95 退化。EWMA 只是观测，没有自动校准/漂移回退。HTTP 取消不等于已验证 GPU 立即释放。
2. **单网关与静态池：** 配额、排队、预留仅当前进程内有效；多网关会超卖，直接绕过网关调用也会使快照更新前的判断滞后。没有动态 worker 加入/退出/代际协同。
3. **身份与控制面：** profile/tokenizer revision 是部署约定；未自动核验模型权重、chat template 或引擎参数。管理入口无认证/TLS，workload class 可由可信内部调用者自报；不能当成多租户优先级授权。
4. **时间与资源语义：** TTFT 指首文本事件到达网关；ITL/端到端客户端 SLO 不在本阶段。固定分区没有借用/抢占，批量完成可能更慢；过于保守的输出预留也会降低接纳率。配置总并发不等于实际 GPU 并发。
5. **控制与传输开销：** tokenizer 目前调用两次；选址前分词顺序尝试候选，可能形成控制面热点。未见过的迟到快照可暂时高估负载；显式 local fallback 也可能低估其他网关工作量。TCP 队头阻塞、封装后 64KiB 片段边界仍在。
6. **关闭：** 网关 Close 会取消并等待自己的活动链路，不提供生产流量的先摘流再 drain 协议；核心 Server 仍为取消/关连接再等待。自定义 handler 必须合作处理 Context，不能承诺请求零丢失。

如果继续往生产推理 RPC 演进，最值得优先完成的是：

1. **真实双实例校准与失准回退**：固定模型、模板、引擎/硬件，实测分词成本与 admission 后误差，接实际引擎指标；未达性能门槛前保留 RR/least_in_flight 对照，不把 token_work 当成已验证更优的默认生产策略。
2. **跨网关接纳与 worker 生命周期**：将 worker 身份/代际、动态成员变化、全局 token 预算及取消确认纳入协调，验证网关故障/网络分区，消除单进程语义被误用为集群语义的风险。
3. **可授权、可观测、可摘流的入口**：把业务身份映射到队列等级，保护管理面；按 offered/拒绝/失败/达标完成统一测量并支持摘流 drain，再做真实开放到达负载验收。

KV 缓存路由仍在后续 M3，没有为了填补缺少 GPU 实验而添加未经验证的缓存收益故事。
