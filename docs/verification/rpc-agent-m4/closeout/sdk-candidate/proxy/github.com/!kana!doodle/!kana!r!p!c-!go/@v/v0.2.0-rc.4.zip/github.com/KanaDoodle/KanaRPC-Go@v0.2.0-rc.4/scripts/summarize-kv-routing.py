#!/usr/bin/env python3
"""Report every offered request, event hint and simulated hit separately."""
import collections
import json
import pathlib
import sys

data=json.loads(pathlib.Path(sys.argv[1]).read_text())
assert data['evidence']=='discrete-event-kv-simulation-no-model'
groups=collections.defaultdict(list);hashes={}
for r in data['results']:
    assert r['Offered']==r['Completed']+r['Rejected']==len(r['samples'])
    assert len({s['id'] for s in r['samples']})==r['Offered']
    assert hashes.setdefault((r['scenario'],r['seed']),r['trace_sha256'])==r['trace_sha256']
    groups[(r['scenario'],r['policy'])].append(r)
print('# M3 KV 路由对照摘要\n')
print('**全部缓存命中、引擎行为和时间来自离散事件模拟。未运行模型/GPU，不代表真实 vLLM 命中率或性能收益。**\n')
print(f"环境：{data['go']}，{data['platform']}。实际 Router/Index 配合合成 FIFO 引擎，7 场景 × 3 种子 × 3 策略，共 63 组。\n")
print('每种子 120 个请求；同场景/种子的 offered trace hash 在所有策略间一致。统计目标 500ms，冷模型接纳预算 3s；模拟不硬取消目标超时，超标仍留在分母中。\n')
print('| 场景 | 策略 | 完成/offered | 拒绝 | 目标内完成 | 提示请求 | 模拟实际命中 | 假阳性提示 | 无提示却命中 | 各种子 TTFT p95(ms) |')
print('| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |')
for (scenario,policy),rows in sorted(groups.items()):
    rows.sort(key=lambda r:r['seed']);total=lambda key:sum(r[key] for r in rows)
    p95=', '.join(f"{r['TTFT']['P95']/1e6:.1f}" if r['TTFT']['n'] else 'N/A' for r in rows)
    print(f"| {scenario} | {policy} | {total('Completed')}/{total('Offered')} | {total('Rejected')} | {total('WithinTargetCompleted')}/{total('Offered')} | {total('HintRequests')} | {total('SimulatedHitRequests')} | {total('FalseHintRequests')} | {total('MissedHintRequests')} | {p95} |")
print('\n提示不是实际命中：丢事件或 TTL 窗口内会有假阳性；M2 也能自然命中缓存。饱和转移抑制纯亲和的部分退化，没有证明普遍优于 token_work。')
