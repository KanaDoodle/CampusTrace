package gateway_test

import (
	"context"
	"encoding/json"
	"io"
	"os"
	"strconv"
	"testing"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/inference/gateway"
	"github.com/KanaDoodle/KanaRPC-Go/inference/lab"
	"github.com/KanaDoodle/KanaRPC-Go/inference/scheduler"
	"github.com/KanaDoodle/KanaRPC-Go/inference/vllm"
	"github.com/KanaDoodle/KanaRPC-Go/rpc"
)

// This is a functional opt-in acceptance test, never a performance benchmark.
// It requires actual tokenizer/chat-template identity and measured rates. The
// absence of a service is an explicit skip, not a fixture-backed success.
func TestRealVLLMThroughScheduledGateway(t *testing.T) {
	base := os.Getenv("KANARPC_VLLM_BASE_URL")
	if base == "" {
		t.Skip("real vLLM/GPU not configured; M2 real inference validation remains pending")
	}
	model, profile, tokenizer := os.Getenv("KANARPC_VLLM_MODEL"), os.Getenv("KANARPC_VLLM_PROFILE"), os.Getenv("KANARPC_VLLM_TOKENIZER")
	prefill, pErr := strconv.ParseFloat(os.Getenv("KANARPC_VLLM_PREFILL_TPS"), 64)
	decode, dErr := strconv.ParseFloat(os.Getenv("KANARPC_VLLM_DECODE_TPS"), 64)
	if model == "" || profile == "" || tokenizer == "" || pErr != nil || dErr != nil {
		t.Fatal("real M2 requires MODEL, PROFILE, TOKENIZER, PREFILL_TPS and DECODE_TPS environment variables; use calibrated rates")
	}
	a, err := vllm.New(vllm.Config{BaseURL: base, Model: model, APIKey: os.Getenv("VLLM_API_KEY"), Scheduling: &vllm.SchedulingConfig{ProfileID: profile, TokenizerID: tokenizer}})
	if err != nil {
		t.Fatal(err)
	}
	server, closeRPC, err := lab.StartRPC(4, a.Register)
	if err != nil {
		t.Fatal(err)
	}
	defer closeRPC()
	admin, closeAdmin, err := lab.StartHTTP(a.AdminHandler())
	if err != nil {
		t.Fatal(err)
	}
	defer closeAdmin()
	w := scheduler.Worker{ID: "real-vllm", Address: server.Addr().String(), AdminURL: admin, Profile: scheduler.Profile{Model: model, ID: profile, TokenizerID: tokenizer, PrefillTokensPerSecond: prefill, DecodeTokensPerSecond: decode, MaxInFlight: 4}}
	g, err := gateway.New(gateway.Config{Model: model, Workers: []scheduler.Worker{w}, MetricsTTL: time.Minute, MaxRequestDuration: 90 * time.Second, QueueBudget: time.Second, InteractiveTTFT: 30 * time.Second, ControlTimeout: 10 * time.Second})
	if err != nil {
		t.Fatal(err)
	}
	defer g.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 100*time.Second)
	defer cancel()
	if err := g.Refresh(ctx); err != nil {
		t.Fatal(err)
	}
	front, closeFront, err := lab.StartRPC(8, g.Register)
	if err != nil {
		t.Fatal(err)
	}
	defer closeFront()
	c, err := rpc.NewDirectClient(front.Addr().String(), rpc.ClientConfig{Timeout: 90 * time.Second})
	if err != nil {
		t.Fatal(err)
	}
	defer c.Close()
	for _, cancelFirst := range []bool{false, true} {
		s, err := c.InvokeStream(ctx, gateway.ServiceForModel(model), vllm.MethodName, gateway.Request{Class: scheduler.Interactive, Chat: vllm.ChatRequest{Messages: []vllm.Message{{Role: "user", Content: "Write a brief greeting in two sentences."}}, MaxTokens: 32}})
		if err != nil {
			t.Fatal(err)
		}
		text, summary := false, false
		for {
			var event gateway.Event
			err := s.Recv(&event)
			if err == io.EOF {
				break
			}
			if err != nil {
				t.Fatal(err)
			}
			if event.Type == "chunk" {
				var chunk vllm.ChatChunk
				if err := json.Unmarshal(event.Chunk, &chunk); err != nil {
					t.Fatal(err)
				}
				text = text || vllm.HasText(chunk)
			}
			summary = summary || event.Summary != nil
			if text && cancelFirst {
				_ = s.Close()
				break
			}
		}
		_ = s.Close()
		if !text || (!cancelFirst && !summary) {
			t.Fatal("real scheduled stream missing text or terminal summary")
		}
	}
	eventually(t, func() bool { return len(a.Status().Active) == 0 })
	t.Log("real vLLM functional scheduled completion/cancellation passed; this does not establish a scheduling performance benefit")
}
