#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export GOWORK=off
work="${1:-$(mktemp -d /private/tmp/kanarpc-scheduling-check.XXXXXX)}"
mkdir -p "$work"
fixture_pid=""; worker_pid=""; gateway_pid=""
cleanup() {
  for pid in "$gateway_pid" "$worker_pid" "$fixture_pid"; do
    if [[ -n "$pid" ]]; then kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true; fi
  done
}
trap cleanup EXIT
for name in inference-fixture inference-worker inference-gateway inference-check; do go build -o "$work/$name" "./cmd/$name"; done
wait_ready() {
  python3 - "$1" "$2" "${3:-address}" <<'PY'
import json, pathlib, os, sys, time
p, pid, key = pathlib.Path(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
for _ in range(150):
    os.kill(pid, 0)
    if p.exists():
        for line in p.read_text().splitlines():
            try: value = json.loads(line)
            except ValueError: continue
            if value.get('event') == 'ready': print(value[key]); sys.exit(0)
    time.sleep(.1)
raise SystemExit('process did not report readiness')
PY
}
"$work/inference-fixture" -listen 127.0.0.1:0 > "$work/fixture.jsonl" 2> "$work/fixture.stderr" &
fixture_pid=$!
fixture_address=$(wait_ready "$work/fixture.jsonl" "$fixture_pid")
KANARPC_FIXTURE_KEY="" "$work/inference-worker" -listen 127.0.0.1:0 -admin-listen 127.0.0.1:0 -upstream "http://$fixture_address" -model fixture-model -api-key-env KANARPC_FIXTURE_KEY -profile fixture-serial-v1 -tokenizer fixture-words-plus-template-v1 -backend-kind fixture-no-model -concurrency 4 > "$work/worker.jsonl" 2> "$work/worker.stderr" &
worker_pid=$!
worker_address=$(wait_ready "$work/worker.jsonl" "$worker_pid")
worker_admin=$(wait_ready "$work/worker.jsonl" "$worker_pid" admin_url)
python3 - "$work/gateway-config.json" "$worker_address" "$worker_admin" <<'PY'
import json, sys
config={'model':'fixture-model','policy':'token_work','refresh_interval_ns':100000000,'workers':[{'id':'fixture-worker','address':sys.argv[2],'admin_url':sys.argv[3],'profile':{'model':'fixture-model','id':'fixture-serial-v1','tokenizer_id':'fixture-words-plus-template-v1','prefill_tokens_per_second':1000,'decode_tokens_per_second':1000,'base_ttft_ns':1000000,'max_in_flight':4}}]}
with open(sys.argv[1],'w') as f: json.dump(config,f,indent=2)
PY
gateway_args=(-config "$work/gateway-config.json" -listen 127.0.0.1:0 -admin-listen 127.0.0.1:0)
if [[ -n "${KANARPC_TEST_ETCD:-}" ]]; then gateway_args+=(-etcd "$KANARPC_TEST_ETCD"); fi
"$work/inference-gateway" "${gateway_args[@]}" > "$work/gateway.jsonl" 2> "$work/gateway.stderr" &
gateway_pid=$!
gateway_address=$(wait_ready "$work/gateway.jsonl" "$gateway_pid")
gateway_admin=$(wait_ready "$work/gateway.jsonl" "$gateway_pid" admin_url)
check_args=(-address "$gateway_address" -model fixture-model -scheduled -timeout 5s)
if [[ -n "${KANARPC_TEST_ETCD:-}" ]]; then check_args+=(-etcd "$KANARPC_TEST_ETCD"); fi
"$work/inference-check" "${check_args[@]}" > "$work/interactive.json"
"$work/inference-check" "${check_args[@]}" -class batch > "$work/batch.json"
"$work/inference-check" "${check_args[@]}" -cancel-after-first > "$work/cancel.json"
long_prompt=$(python3 -c 'print("token "*500)')
if "$work/inference-check" "${check_args[@]}" -prompt "$long_prompt" -ttft-target 100ms > "$work/rejected.json" 2> "$work/rejected.stderr"; then
  printf '%s\n' 'unachievable target incorrectly succeeded' >&2; exit 1
fi
python3 - "$work" "$gateway_admin" "$worker_admin" <<'PY'
import json, pathlib, sys, time, urllib.request
p=pathlib.Path(sys.argv[1])
for name in ['interactive','batch']:
    value=json.loads((p/(name+'.json')).read_text())
    assert value['terminal']=='eof' and value['gateway_summary']['ttft_met']
    assert value['decision']['policy']=='token_work'
assert json.loads((p/'cancel.json').read_text())['terminal']=='canceled'
assert 'slo_unachievable' in (p/'rejected.stderr').read_text()
for _ in range(100):
    with urllib.request.urlopen(sys.argv[2]+'/status',timeout=2) as r: gateway=json.load(r)
    with urllib.request.urlopen(sys.argv[3]+'/status',timeout=2) as r: worker=json.load(r)
    if gateway['offered']==4 and sum(gateway['outcomes'].values())==4 and not worker['active'] and all(x['local_reservations']==0 for x in gateway['workers']): break
    time.sleep(.05)
else: raise SystemExit('running reservations failed to drain')
assert gateway['completed']==2 and gateway['batch_completed']==1
assert gateway['admission']['interactive']['running']==0 and gateway['admission']['batch']['running']==0
assert worker['completed']==2 and worker['failed']==1 and worker['backend_kind']=='fixture-no-model'
assert any(json.loads(line).get('outcome')=='canceled' for line in (p/'fixture.jsonl').read_text().splitlines())
(p/'gateway-final.json').write_text(json.dumps(gateway,indent=2))
(p/'worker-final.json').write_text(json.dumps(worker,indent=2))
print(json.dumps({'status':'passed','backend':'fixture-no-model','processes':['fixture','rpc-worker','scheduled-gateway','rpc-check'],'checks':['interactive completion','batch completion','upstream HTTP cancellation','SLO rejection','reservation cleanup'],'evidence':str(p)}))
PY
