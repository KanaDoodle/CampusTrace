#!/usr/bin/env python3
"""Summarize all offered calls; fixtures and simulation never imply GPU gains."""
import collections
import json
import pathlib
import sys

source = pathlib.Path(sys.argv[1])
data = json.loads(source.read_text())
assert data['evidence'] == 'simulation-and-loopback-fixtures-no-model'
groups = collections.defaultdict(list)
trace_hashes = {}
for row in data['routing']:
    assert row['Offered'] == row['Completed'] + row['Rejected'] == len(row['samples'])
    trace_key = (row['scenario'], row['seed'])
    assert trace_hashes.setdefault(trace_key, row['trace_sha256']) == row['trace_sha256']
    assert len({s['id'] for s in row['samples']}) == row['Offered']
    groups[(row['scenario'], row['admission_budget_ns'], row['policy'])].append(row)

print('# M2 对照原始结果摘要\n')
print('**全部结果来自离散事件模拟或本地 TCP/HTTP fixture，没有运行模型或 GPU。不能据此声称真实 vLLM 推理性能提升。**\n')
print(f"运行环境：{data['go']}，{data['platform']}。时间单位见列名；原始 JSON 时间为 ns。\n")
print('## 路由对照\n')
print('每组种子 1、7、42，各 120 个请求；同一种子的 offered trace SHA256 在所有策略/预算间一致。2s 为统计目标；600s 接纳预算隔离选址影响，2s 预算另启预测 TTFT 拒绝。模拟不硬取消执行，校准误差导致的超标请求仍保留。\n')
print('| 场景 | 接纳预算(s) | 路由 | 完成/offered | 拒绝 | 2s 内完成 | 各种子成功请求 TTFT p95(s) |')
print('| --- | ---: | --- | ---: | ---: | ---: | --- |')
for (scenario, budget, policy), rows in sorted(groups.items()):
    rows.sort(key=lambda r: r['seed'])
    offered = sum(r['Offered'] for r in rows)
    completed = sum(r['Completed'] for r in rows)
    rejected = sum(r['Rejected'] for r in rows)
    met = sum(r['WithinTargetCompleted'] for r in rows)
    p95 = ', '.join(f"{r['TTFT']['P95']/1e9:.3f}" for r in rows)
    print(f'| {scenario} | {budget/1e9:g} | {policy} | {completed}/{offered} | {rejected} | {met}/{offered} | {p95} |')

print('\n## 真实 loopback TCP/HTTP、定时 SSE fixture 的队列对照\n')
print('固定输入：8 个 batch 先到，12 个 interactive 随后到；batch 首文本定时 160ms，interactive 为 10ms；交互目标 150ms。最大并行总数均为 3；共享 FIFO 与交互 2 / 批量 1 固定分区比较。不模拟 GPU 资源竞争。\n')
print('| 轮次 | 队列策略 | 完成/offered | 交互目标内完成/offered | 批量完成/offered | 交互成功 TTFT p95(ms) | 失败 | 整轮耗时(s) |')
print('| ---: | --- | ---: | ---: | ---: | ---: | --- | ---: |')
for i, row in enumerate(data['admission']):
    assert sum(row['outcomes'].values()) == row['Offered'] == len(row['samples'])
    p95 = f"{row['InteractiveTTFT']['P95']/1e6:.2f}" if row['InteractiveTTFT']['n'] else 'N/A (无成功样本)'
    failures = ', '.join(f'{k}={v}' for k, v in row['outcomes'].items() if k != 'eof') or '无'
    print(f"| {i//2+1} | {row['policy']} | {row['Completed']}/{row['Offered']} | {row['InteractiveWithinTarget']}/{row['InteractiveOffered']} | {row['BatchCompleted']}/{row['BatchOffered']} | {p95} | {failures} | {row['elapsed_ns']/1e9:.3f} |")
print('\n固定分区保护交互容量，但不借用空闲交互名额，批量完成耗时增加。这是构造的隔离验收案例，不是一般负载下的吞吐收益。')
