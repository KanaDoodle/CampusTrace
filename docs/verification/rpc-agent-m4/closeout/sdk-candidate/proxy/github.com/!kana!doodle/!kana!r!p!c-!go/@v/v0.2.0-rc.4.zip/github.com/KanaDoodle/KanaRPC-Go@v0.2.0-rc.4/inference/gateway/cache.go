package gateway

import (
	"encoding/json"
	"io"
	"net/http"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/inference/kvcache"
)

type CacheConfig struct {
	Index          kvcache.Config `json:"index"`
	QueueLimit     time.Duration  `json:"queue_limit_ns"`
	MinGain        time.Duration  `json:"min_gain_ns"`
	SavingFraction float64        `json:"saving_fraction"`
}

func (g *Gateway) cacheHandler(mux *http.ServeMux) {
	if g.cache == nil {
		return
	}
	mux.HandleFunc("GET /kv/status", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(g.cache.Snapshot())
	})
	decode := func(w http.ResponseWriter, r *http.Request, target any) bool {
		decoder := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<20))
		decoder.DisallowUnknownFields()
		if decoder.Decode(target) != nil || decoder.Decode(&struct{}{}) != io.EOF {
			http.Error(w, "invalid KV payload", 400)
			return false
		}
		return true
	}
	mux.HandleFunc("POST /kv/reset", func(w http.ResponseWriter, r *http.Request) {
		if !g.enter() {
			http.Error(w, "gateway closed", 503)
			return
		}
		defer g.wg.Done()
		var reset kvcache.Reset
		if !decode(w, r, &reset) {
			return
		}
		if err := g.cache.Reset(reset); err != nil {
			http.Error(w, err.Error(), 409)
			return
		}
		w.WriteHeader(204)
	})
	mux.HandleFunc("POST /kv/events", func(w http.ResponseWriter, r *http.Request) {
		if !g.enter() {
			http.Error(w, "gateway closed", 503)
			return
		}
		defer g.wg.Done()
		var batch kvcache.Batch
		if !decode(w, r, &batch) {
			return
		}
		if err := g.cache.Apply(batch); err != nil {
			http.Error(w, err.Error(), 409)
			return
		}
		w.WriteHeader(204)
	})
}
