// inference-fixture is a deterministic SSE test peer. It never runs a model.
package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/inference/lab"
	"github.com/KanaDoodle/KanaRPC-Go/inference/vllm"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
func run() error {
	listen := flag.String("listen", "127.0.0.1:18000", "local fixture listen address")
	mode := flag.String("mode", "stream", "stream or narration; all modes run no model")
	flag.Parse()
	if *mode != "stream" && *mode != "narration" {
		return fmt.Errorf("unknown fixture mode")
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	var logMu sync.Mutex
	record := func(value any) { logMu.Lock(); defer logMu.Unlock(); _ = json.NewEncoder(os.Stdout).Encode(value) }
	mux := http.NewServeMux()
	var calls, completed, canceled atomic.Int64
	var scopes sync.Map
	mux.HandleFunc("GET /fixture/status", func(w http.ResponseWriter, r *http.Request) {
		scopeCount := 0
		scopes.Range(func(any, any) bool { scopeCount++; return true })
		_ = json.NewEncoder(w).Encode(map[string]any{"backend": "fixture-no-model", "mode": *mode, "calls": calls.Load(), "completed": completed.Load(), "canceled": canceled.Load(), "distinct_scopes": scopeCount})
	})
	mux.HandleFunc("/v1/models", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprint(w, `{"data":[{"id":"fixture-model"}]}`)
	})
	mux.HandleFunc("POST /tokenize", func(w http.ResponseWriter, r *http.Request) {
		var request struct {
			Model      string         `json:"model"`
			Messages   []vllm.Message `json:"messages"`
			Generation bool           `json:"add_generation_prompt"`
		}
		if json.NewDecoder(http.MaxBytesReader(w, r.Body, vllm.MaxPromptBytes+(16<<10))).Decode(&request) != nil || request.Model != lab.Model || !request.Generation {
			http.Error(w, "invalid fixture tokenize", 400)
			return
		}
		chat := vllm.ChatRequest{Messages: request.Messages}
		_ = json.NewEncoder(w).Encode(map[string]any{"count": lab.Count(chat), "tokens": lab.Tokens(chat)})
	})
	mux.HandleFunc("/v1/chat/completions", func(w http.ResponseWriter, r *http.Request) {
		var request vllm.ChatRequest
		if json.NewDecoder(http.MaxBytesReader(w, r.Body, vllm.MaxPromptBytes+(16<<10))).Decode(&request) != nil {
			http.Error(w, "invalid fixture chat", 400)
			return
		}
		calls.Add(1)
		if request.CacheSalt != "" {
			scopes.Store(request.CacheSalt, true)
		}
		words := []string{"hello", " world"}
		gap := 200 * time.Millisecond
		if *mode == "narration" {
			words = nil
			for n := 0; n < 40; n++ {
				words = append(words, "本地无模型测试片段。")
			}
			words = append(words, `<img src=x onerror="window.__narrationExecuted=true">`)
			gap = 80 * time.Millisecond
		}
		w.Header().Set("Content-Type", "text/event-stream")
		for _, word := range words {
			chunk := vllm.ChatChunk{ID: "fixture", Model: "fixture-model", Choices: []vllm.Choice{{Delta: vllm.Delta{Content: word}}}}
			data, _ := json.Marshal(chunk)
			fmt.Fprintf(w, "data: %s\n\n", data)
			w.(http.Flusher).Flush()
			timer := time.NewTimer(gap)
			select {
			case <-r.Context().Done():
				timer.Stop()
				canceled.Add(1)
				record(map[string]any{"event": "request_finished", "outcome": "canceled", "backend": "fixture-no-model"})
				return
			case <-timer.C:
			}
		}
		prompt := lab.Count(request)
		output := 2
		if *mode == "narration" {
			output = len([]rune(strings.Join(words, "")))
		}
		data, _ := json.Marshal(vllm.ChatChunk{Model: lab.Model, Usage: &vllm.Usage{PromptTokens: prompt, CompletionTokens: output, TotalTokens: prompt + output}})
		fmt.Fprintf(w, "data: %s\n\ndata: [DONE]\n\n", data)
		record(map[string]any{"event": "request_finished", "outcome": "completed", "backend": "fixture-no-model"})
		completed.Add(1)
	})
	ln, err := net.Listen("tcp", *listen)
	if err != nil {
		return err
	}
	server := &http.Server{Handler: mux, ReadHeaderTimeout: 5 * time.Second, BaseContext: func(net.Listener) context.Context { return ctx }}
	done := make(chan error, 1)
	go func() { done <- server.Serve(ln) }()
	record(map[string]any{"event": "ready", "address": ln.Addr().String(), "backend": "fixture-no-model"})
	select {
	case <-ctx.Done():
	case err := <-done:
		if err != http.ErrServerClosed {
			return err
		}
		return nil
	}
	shutdown, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	if err := server.Shutdown(shutdown); err != nil {
		_ = server.Close()
		return err
	}
	return nil
}
