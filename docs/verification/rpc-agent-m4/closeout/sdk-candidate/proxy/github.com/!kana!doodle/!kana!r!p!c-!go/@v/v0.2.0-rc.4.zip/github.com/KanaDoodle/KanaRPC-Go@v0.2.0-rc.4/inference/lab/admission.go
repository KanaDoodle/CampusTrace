package lab

import (
	"context"
	"errors"
	"fmt"
	"io"
	"sync"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/inference/gateway"
	"github.com/KanaDoodle/KanaRPC-Go/inference/scheduler"
	"github.com/KanaDoodle/KanaRPC-Go/inference/vllm"
	"github.com/KanaDoodle/KanaRPC-Go/rpc"
)

type AdmissionResult struct {
	Evidence                                                                                                            string `json:"evidence"`
	Policy                                                                                                              string `json:"policy"`
	Offered, Completed, InteractiveOffered, InteractiveCompleted, InteractiveWithinTarget, BatchOffered, BatchCompleted int
	Outcomes                                                                                                            map[string]int `json:"outcomes"`
	InteractiveTTFT, BatchTTFT                                                                                          Distribution
	Elapsed                                                                                                             time.Duration    `json:"elapsed_ns"`
	Gateway                                                                                                             gateway.Snapshot `json:"gateway"`
	Samples                                                                                                             []Sample         `json:"samples"`
}

// AdmissionComparison uses actual loopback TCP RPC and HTTP SSE, with fixture
// timers (batch 160ms, interactive 10ms). It is a constructed isolation test,
// not a vLLM capacity benchmark. Arrival times and work are identical in both
// policies. All offered calls, including queue expirations, are retained.
func AdmissionComparison(ctx context.Context, shared bool) (AdmissionResult, error) {
	result := AdmissionResult{Evidence: "loopback-tcp-http-fixture-no-model", Policy: "isolated", Outcomes: map[string]int{}}
	if shared {
		result.Policy = "shared_fifo"
	}
	backend := &Backend{Delay: func(request vllm.ChatRequest) time.Duration {
		if request.Messages[0].Content == "batch" {
			return 160 * time.Millisecond
		}
		return 10 * time.Millisecond
	}}
	worker, err := StartWorker("w0", backend, 16)
	if err != nil {
		return result, err
	}
	defer worker.Close()
	admission := gateway.DefaultAdmission()
	admission.SharedFIFO = shared
	admission.Interactive.Queued = 32
	admission.Batch.Queued = 32
	g, err := gateway.New(gateway.Config{Model: Model, Workers: []scheduler.Worker{worker.Endpoint}, MetricsTTL: 10 * time.Second, QueueBudget: 2 * time.Second, InteractiveTTFT: 150 * time.Millisecond, BatchTTFT: 3 * time.Second, MaxRequestDuration: 4 * time.Second, Admission: admission})
	if err != nil {
		return result, err
	}
	defer g.Close()
	if err := g.Refresh(ctx); err != nil {
		return result, err
	}
	server, closeServer, err := StartRPC(64, g.Register)
	if err != nil {
		return result, err
	}
	defer closeServer()
	client, err := rpc.NewDirectClient(server.Addr().String(), rpc.ClientConfig{Timeout: 5 * time.Second})
	if err != nil {
		return result, err
	}
	defer client.Close()
	var wg sync.WaitGroup
	var mu sync.Mutex
	started := time.Now()
	for i := 0; i < 20; i++ {
		class := scheduler.Batch
		content := "batch"
		at := time.Duration(i) * 3 * time.Millisecond
		if i >= 8 {
			class = scheduler.Interactive
			content = "interactive"
			at = 35*time.Millisecond + time.Duration(i-8)*8*time.Millisecond
		}
		wg.Add(1)
		go func(i int, class scheduler.Class, content string, at time.Duration) {
			defer wg.Done()
			if !Wait(ctx, time.Until(started.Add(at))) {
				return
			}
			start := time.Now()
			sample := Sample{ID: fmt.Sprintf("request-%02d", i), Class: class, Outcome: "eof"}
			request := gateway.Request{Class: class, Chat: vllm.ChatRequest{Messages: []vllm.Message{{Role: "user", Content: content}}, MaxTokens: 16}}
			stream, err := client.InvokeStream(ctx, gateway.ServiceForModel(Model), vllm.MethodName, request)
			if err == nil {
				defer stream.Close()
				for {
					var event gateway.Event
					err = stream.Recv(&event)
					if err != nil {
						break
					}
					if event.Summary != nil {
						sample.TTFT = event.Summary.GatewayTTFT
					}
					if event.Decision != nil {
						sample.Worker = event.Decision.WorkerID
						sample.PredictedTTFT = event.Decision.PredictedTTFT
					}
				}
			}
			if err != io.EOF {
				var status *rpc.StreamError
				if errors.As(err, &status) {
					sample.Outcome = status.Code
				} else if errors.Is(err, context.Canceled) {
					sample.Outcome = "canceled"
				} else {
					sample.Outcome = "transport_error"
				}
			}
			sample.Elapsed = time.Since(start)
			mu.Lock()
			result.Samples = append(result.Samples, sample)
			mu.Unlock()
		}(i, class, content, at)
	}
	wg.Wait()
	result.Elapsed = time.Since(started)
	// Join gateway execution before taking final counters. A terminal frame can
	// reach the caller just before the handler's deferred accounting executes.
	g.Close()
	result.Gateway = g.Snapshot()
	var interactive, batch []time.Duration
	for _, s := range result.Samples {
		result.Offered++
		result.Outcomes[s.Outcome]++
		if s.Class == scheduler.Interactive {
			result.InteractiveOffered++
		} else {
			result.BatchOffered++
		}
		if s.Outcome != "eof" {
			continue
		}
		result.Completed++
		if s.Class == scheduler.Interactive {
			result.InteractiveCompleted++
			interactive = append(interactive, s.TTFT)
			if s.TTFT <= 150*time.Millisecond {
				result.InteractiveWithinTarget++
			}
		} else {
			result.BatchCompleted++
			batch = append(batch, s.TTFT)
		}
	}
	result.InteractiveTTFT = distribution(interactive)
	result.BatchTTFT = distribution(batch)
	return result, ctx.Err()
}
