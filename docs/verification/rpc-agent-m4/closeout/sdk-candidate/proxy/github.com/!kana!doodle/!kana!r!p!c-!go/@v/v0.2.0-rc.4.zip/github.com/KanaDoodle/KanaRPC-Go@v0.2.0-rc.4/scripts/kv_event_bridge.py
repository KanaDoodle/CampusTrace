#!/usr/bin/env python3
"""vLLM v0.32.0 KV ZMQ -> KanaRPC private HTTP, text/full-attention subset.

No vLLM/model dependency. This bridge reports event observations, not GPU hits.
It cold-resets on loss, regression, unsupported data or failed forwarding. No
history/snapshot is invented and no inference is retried. See kv-routing-m3.md.
"""
import argparse
import base64
import hashlib
import json
import signal
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

MAX_WIRE = 1 << 20

class Unsupported(ValueError):
    pass

class Fenced(Unsupported):
    pass

def block_id(value):
    if isinstance(value, bool):
        raise Unsupported('boolean block hash')
    if isinstance(value, int) and 0 <= value < (1 << 256):
        return 'i:' + str(value)
    if isinstance(value, bytes) and 0 < len(value) <= 64:
        return 'b:' + base64.b64encode(value).decode('ascii')
    raise Unsupported('unsupported external block hash')

def normalize(payload, block_size):
    """Input is the decoded array-like KVEventBatch, not our JSON envelope."""
    if not isinstance(payload, list) or len(payload) not in (2, 3):
        raise Unsupported('unsupported KVEventBatch shape')
    if len(payload) == 3 and (isinstance(payload[2], bool) or payload[2] not in (None, 0)):
        raise Unsupported('only a dedicated DP rank 0 endpoint is supported')
    events = payload[1]
    if not isinstance(events, list) or len(events) > 256:
        raise Unsupported('event batch bound exceeded')
    result = []
    for event in events:
        if not isinstance(event, dict):
            raise Unsupported('event must be a tagged map')
        kind = event.get('type')
        if kind == 'AllBlocksCleared':
            result.append({'type': 'cleared'})
            continue
        if kind not in ('BlockStored', 'BlockRemoved'):
            raise Unsupported('unsupported event type')
        medium = event.get('medium')
        if medium in ('CPU', 'STORAGE'):
            continue  # offloaded copies never grant local GPU credit
        if medium != 'GPU' or event.get('locality') not in (None, 'LOCAL'):
            raise Unsupported('unknown or nonlocal GPU medium')
        if event.get('group_idx') not in (None, 0) or event.get('ownership') is not None:
            raise Unsupported('multi-group/offloaded ownership unsupported')
        hashes = event.get('block_hashes')
        if not isinstance(hashes, list) or not 0 < len(hashes) <= 256:
            raise Unsupported('invalid block hashes')
        ids = [block_id(x) for x in hashes]
        if len(set(ids)) != len(ids):
            raise Unsupported('duplicate IDs within store/remove')
        if kind == 'BlockRemoved':
            result.append({'type': 'removed', 'hashes': ids})
            continue
        if event.get('lora_id') not in (None, 0) or event.get('lora_name') not in (None, ''):
            raise Unsupported('LoRA unsupported')
        if event.get('kv_cache_spec_kind') not in (None, 'full_attention', 'FullAttentionSpec') or event.get('kv_cache_spec_sliding_window') is not None:
            raise Unsupported('only FullAttention layout is supported')
        size = event.get('block_size')
        tokens = event.get('token_ids')
        if isinstance(size, bool) or size != block_size or not isinstance(tokens, list) or len(tokens) != len(ids)*block_size:
            raise Unsupported('partial/nonaligned blocks unsupported')
        if any(isinstance(t, bool) or not isinstance(t, int) or not 0 <= t < (1 << 31) for t in tokens):
            raise Unsupported('invalid token ID')
        parent = event.get('parent_block_hash')
        salt = ''
        extras = event.get('extra_keys')
        if extras is not None:
            if not isinstance(extras, list) or len(extras) != len(ids):
                raise Unsupported('extra_keys must align with blocks')
            for n, keys in enumerate(extras):
                if keys is None or keys == []:
                    continue
                # v0.32 emits untagged salt only on root, without LoRA/MM.
                if n != 0 or parent is not None or not isinstance(keys, list) or len(keys) != 1 or not isinstance(keys[0], str) or len(keys[0].encode()) > 128:
                    raise Unsupported('unsupported MM/embedding/nonroot extra keys')
                salt = keys[0]
        result.append({'type': 'stored', 'hashes': ids, 'parent': '' if parent is None else block_id(parent), 'tokens': tokens, 'block_size': size, 'salt': salt})
    return result

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None

class Bridge:
    def __init__(self, gateway, worker_admin, worker, namespace, block_size, source):
        self.gateway = self.endpoint(gateway)
        self.worker_admin = self.endpoint(worker_admin)
        self.worker, self.namespace, self.block_size, self.source = worker, namespace, block_size, source
        self.opener = urllib.request.build_opener(NoRedirect)
        self.owner, self.epoch, self.sequence = None, '', None
        self.fingerprint = None

    @staticmethod
    def endpoint(value):
        parsed = urllib.parse.urlsplit(value)
        if parsed.scheme not in ('http', 'https') or not parsed.netloc or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError('invalid private control endpoint')
        return value.rstrip('/')

    def http(self, base, path, payload=None):
        data = None if payload is None else json.dumps(payload, separators=(',', ':')).encode()
        if data is not None and len(data) > MAX_WIRE:
            raise Unsupported('normalized batch exceeds 1 MiB')
        request = urllib.request.Request(base+path, data=data, headers={'Content-Type': 'application/json'})
        with self.opener.open(request, timeout=2) as response:
            body = response.read(MAX_WIRE+1)
            if len(body) > MAX_WIRE:
                raise Unsupported('control response too large')
            return json.loads(body) if body else None

    def reset(self):
        status = self.http(self.worker_admin, '/status')
        if not status['ready']:
            raise Unsupported('worker not ready')
        owner = {'worker': self.worker, 'instance': status['instance_id'], 'model': status['model'], 'profile': status['profile_id'], 'tokenizer': status['tokenizer_id'], 'namespace': self.namespace, 'backend_kind':status.get('backend_kind','')}
        views = self.http(self.gateway, '/kv/status')
        view = next((v for v in views if v['worker'] == self.worker and v['instance'] == owner['instance']), None)
        if view is None:
            raise Unsupported('worker generation not yet bound by gateway refresh')
        if self.owner == owner and self.epoch and view['epoch'] != self.epoch:
            raise Fenced('a newer bridge owns this stream epoch')
        epoch = uuid.uuid4().hex
        self.http(self.gateway, '/kv/reset', dict(owner, previous_epoch=view['epoch'], epoch=epoch))
        self.owner, self.epoch, self.sequence = owner, epoch, None
        self.fingerprint = None

    def invalidate_owned(self):
        if self.owner and self.epoch:
            # No latest-epoch read here: a stale bridge cannot clear a new one.
            self.http(self.gateway, '/kv/reset',dict(self.owner,previous_epoch=self.epoch,epoch=uuid.uuid4().hex))

    def forward(self, sequence, payload):
        events = normalize(payload, self.block_size)
        fingerprint = hashlib.sha256(json.dumps(events,sort_keys=True,separators=(',',':')).encode()).digest()
        if not self.epoch or (self.sequence is not None and sequence != self.sequence+1 and (sequence != self.sequence or fingerprint != self.fingerprint)):
            self.reset()  # cold rebuild; never pretend bounded replay is a snapshot
        if self.sequence == sequence:
            return False  # retransmission must not renew TTL
        batch = dict(self.owner, epoch=self.epoch, sequence=sequence, source=self.source, events=events)
        self.http(self.gateway, '/kv/events', batch)
        self.sequence = sequence
        self.fingerprint = fingerprint
        return True

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--endpoint', required=True, help='dedicated vLLM ZMQ PUB endpoint')
    parser.add_argument('--topic', default='')
    parser.add_argument('--gateway', required=True)
    parser.add_argument('--worker-admin', required=True)
    parser.add_argument('--worker', required=True)
    parser.add_argument('--namespace', required=True)
    parser.add_argument('--block-size', type=int, required=True)
    parser.add_argument('--layout', required=True, choices=['full-attention-single-group'])
    parser.add_argument('--source', default='vllm-events', choices=['vllm-events', 'fixture-events-no-model'])
    args = parser.parse_args()
    if not 1 <= args.block_size <= 1024:
        parser.error('block size must be 1..1024')
    try:
        import msgpack
        import zmq
    except ImportError:
        parser.error('install optional scripts/requirements-kv.txt in an isolated venv')
    bridge = Bridge(args.gateway, args.worker_admin, args.worker, args.namespace, args.block_size, args.source)
    running = True
    def stop(*_):
        nonlocal running
        running = False
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    context = zmq.Context()
    socket = context.socket(zmq.SUB)
    socket.setsockopt(zmq.RCVHWM, 128)
    socket.setsockopt(zmq.MAXMSGSIZE, MAX_WIRE)
    socket.setsockopt(zmq.LINGER, 0)
    socket.setsockopt(zmq.SUBSCRIBE, args.topic.encode())
    socket.connect(args.endpoint)
    print(json.dumps({'event': 'ready', 'source': args.source, 'meaning': 'subscriber started; no model execution or cache-hit validation'}), flush=True)
    try:
        while running:
            if not socket.poll(100):
                continue
            frames = socket.recv_multipart()
            try:
                if len(frames) != 3 or frames[0] != args.topic.encode() or len(frames[1]) != 8 or len(frames[2]) > MAX_WIRE:
                    raise Unsupported('invalid ZMQ multipart framing')
                payload = msgpack.unpackb(frames[2], raw=False, strict_map_key=True, max_array_len=262144, max_map_len=64, max_str_len=4096, max_bin_len=128)
                changed = bridge.forward(int.from_bytes(frames[1], 'big'), payload)
                print(json.dumps({'event': 'forwarded' if changed else 'duplicate', 'source': args.source}), flush=True)
            except Fenced:
                running = False
                print(json.dumps({'event':'fenced','source':args.source}),flush=True)
            except (ValueError, KeyError, TypeError, urllib.error.URLError):
                # Do not log prompts, tokens, salts or HTTP response bodies.
                try:
                    bridge.reset()
                except Fenced:
                    running = False
                except (ValueError, KeyError, TypeError, urllib.error.URLError):
                    bridge.epoch = ''
                print(json.dumps({'event': 'invalidated', 'source': args.source, 'meaning': 'cold reset required; no cache benefit assumed'}), flush=True)
    finally:
        # Best effort invalidation on deliberate shutdown; otherwise TTL fences.
        try:
            bridge.invalidate_owned()
        except (ValueError, KeyError, TypeError, urllib.error.URLError):
            pass
        socket.close()
        context.term()

if __name__ == '__main__':
    main()
