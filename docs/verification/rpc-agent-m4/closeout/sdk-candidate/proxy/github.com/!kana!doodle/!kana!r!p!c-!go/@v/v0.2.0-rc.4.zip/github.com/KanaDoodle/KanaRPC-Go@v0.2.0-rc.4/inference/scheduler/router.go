// Package scheduler implements local admission and model-aware placement.
// Token work and latency estimates are accounting models, not GPU guarantees.
package scheduler

import (
	"errors"
	"fmt"
	"math"
	"sort"
	"sync"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/inference/kvcache"
)

type Error struct{ Code, Message string }

func (e *Error) Error() string { return e.Code + ": " + e.Message }

type Work struct {
	PromptTokens int `json:"prompt_tokens"`
	OutputTokens int `json:"reserved_output_tokens"`
}

func (w Work) Valid() bool {
	return w.PromptTokens > 0 && w.PromptTokens <= 1<<20 && w.OutputTokens > 0 && w.OutputTokens <= 8192
}
func (w Work) Tokens() int { return w.PromptTokens + w.OutputTokens }

type Invocation struct {
	ID string `json:"id"`
	Work
	FirstText bool `json:"first_text"`
}
type WorkerStatus struct {
	Model                 string        `json:"model"`
	ProfileID             string        `json:"profile_id"`
	TokenizerID           string        `json:"tokenizer_id"`
	InstanceID            string        `json:"instance_id"`
	Revision              uint64        `json:"revision"`
	BackendKind           string        `json:"backend_kind"`
	TokenSource           string        `json:"token_source"`
	Ready                 bool          `json:"ready"`
	Active                []Invocation  `json:"active"`
	WaitingForFirstText   int           `json:"waiting_for_first_text"`
	Completed             uint64        `json:"completed"`
	Failed                uint64        `json:"failed"`
	TTFTEWMA              time.Duration `json:"adapter_ttft_ewma_ns"`
	GapEWMA               time.Duration `json:"adapter_text_event_gap_ewma_ns"`
	LastUsagePromptTokens int           `json:"last_usage_prompt_tokens"`
	LastUsageOutputTokens int           `json:"last_usage_output_tokens"`
}
type Profile struct {
	Model                  string        `json:"model"`
	ID                     string        `json:"id"`
	TokenizerID            string        `json:"tokenizer_id"`
	PrefillTokensPerSecond float64       `json:"prefill_tokens_per_second"`
	DecodeTokensPerSecond  float64       `json:"decode_tokens_per_second"`
	BaseTTFT               time.Duration `json:"base_ttft_ns"`
	MaxInFlight            int           `json:"max_in_flight"`
}
type Worker struct {
	ID       string  `json:"id"`
	Address  string  `json:"address"`
	AdminURL string  `json:"admin_url"`
	Profile  Profile `json:"profile"`
}
type Policy string

const (
	RoundRobin    Policy = "round_robin"
	LeastInFlight Policy = "least_in_flight"
	TokenWork     Policy = "token_work"
	CacheAffinity Policy = "cache_affinity"
	CacheAware    Policy = "cache_aware"
)

type RouterConfig struct {
	Workers             []Worker
	Policy              Policy
	StaleAfter          time.Duration
	AllowLocalFallback  bool
	Now                 func() time.Time
	Cache               *kvcache.Index
	CacheQueueLimit     time.Duration
	MinCacheGain        time.Duration
	CacheSavingFraction float64
}
type workerState struct {
	worker             Worker
	status             WorkerStatus
	observed           time.Time
	known, unavailable bool
	local              map[string]*Reservation
	ignore             map[string]bool
}
type Router struct {
	mu                            sync.Mutex
	workers                       []*workerState
	byID                          map[string]*workerState
	policy                        Policy
	ttl                           time.Duration
	fallback                      bool
	now                           func() time.Time
	next                          uint64
	cache                         *kvcache.Index
	cacheQueueLimit, minCacheGain time.Duration
	cacheSavingFraction           float64
}
type Decision struct {
	WorkerID                string        `json:"worker_id"`
	Policy                  Policy        `json:"policy"`
	MetricsSource           string        `json:"metrics_source"`
	PredictedTTFT           time.Duration `json:"predicted_ttft_ns"`
	EffectiveInFlight       int           `json:"effective_in_flight"`
	Work                    Work          `json:"work"`
	EstimatedReusableTokens int           `json:"estimated_reusable_tokens,omitempty"`
	CacheEvidence           string        `json:"cache_evidence,omitempty"`
	CacheState              string        `json:"cache_state,omitempty"`
	RoutingReason           string        `json:"routing_reason,omitempty"`
	CachedWorker            string        `json:"preferred_cached_worker,omitempty"`
	EstimatedWarmTTFT       time.Duration `json:"estimated_warm_ttft_ns,omitempty"`
}
type Reservation struct {
	router   *Router
	worker   *workerState
	id       string
	work     Work
	first    bool
	once     sync.Once
	Decision Decision
}

func NewRouter(cfg RouterConfig) (*Router, error) {
	if len(cfg.Workers) == 0 || len(cfg.Workers) > 64 {
		return nil, errors.New("worker pool must contain 1 to 64 endpoints")
	}
	if cfg.Policy == "" {
		cfg.Policy = TokenWork
	}
	if cfg.Policy != RoundRobin && cfg.Policy != LeastInFlight && cfg.Policy != TokenWork && cfg.Policy != CacheAffinity && cfg.Policy != CacheAware {
		return nil, errors.New("unknown routing policy")
	}
	if cfg.StaleAfter <= 0 {
		return nil, errors.New("positive metrics TTL required")
	}
	if cfg.Now == nil {
		cfg.Now = time.Now
	}
	if cfg.Policy == CacheAffinity || cfg.Policy == CacheAware {
		if cfg.Cache == nil {
			return nil, errors.New("cache routing requires an explicit event index")
		}
		if cfg.CacheQueueLimit == 0 {
			cfg.CacheQueueLimit = 100 * time.Millisecond
		}
		if cfg.MinCacheGain == 0 {
			cfg.MinCacheGain = 2 * time.Millisecond
		}
		if cfg.CacheSavingFraction == 0 {
			cfg.CacheSavingFraction = 1
		}
		if cfg.CacheQueueLimit < 0 || cfg.CacheQueueLimit > time.Minute || cfg.MinCacheGain < 0 || cfg.MinCacheGain > time.Minute || !positiveFinite(cfg.CacheSavingFraction) || cfg.CacheSavingFraction > 1 {
			return nil, errors.New("invalid cache routing cost parameters")
		}
	}
	r := &Router{byID: make(map[string]*workerState), policy: cfg.Policy, ttl: cfg.StaleAfter, fallback: cfg.AllowLocalFallback, now: cfg.Now}
	r.cache, r.cacheQueueLimit, r.minCacheGain, r.cacheSavingFraction = cfg.Cache, cfg.CacheQueueLimit, cfg.MinCacheGain, cfg.CacheSavingFraction
	model, tokenizer := cfg.Workers[0].Profile.Model, cfg.Workers[0].Profile.TokenizerID
	for _, w := range cfg.Workers {
		p := w.Profile
		if w.ID == "" || r.byID[w.ID] != nil || p.Model == "" || p.ID == "" || p.TokenizerID == "" || p.Model != model || p.TokenizerID != tokenizer ||
			!positiveFinite(p.PrefillTokensPerSecond) || !positiveFinite(p.DecodeTokensPerSecond) || p.BaseTTFT < 0 || p.BaseTTFT > time.Minute || p.MaxInFlight < 1 || p.MaxInFlight > 256 {
			return nil, errors.New("invalid or incompatible worker profile")
		}
		state := &workerState{worker: w, local: make(map[string]*Reservation), ignore: make(map[string]bool)}
		r.workers = append(r.workers, state)
		r.byID[w.ID] = state
	}
	sort.Slice(r.workers, func(i, j int) bool { return r.workers[i].worker.ID < r.workers[j].worker.ID })
	return r, nil
}
func positiveFinite(value float64) bool {
	return value > 0 && !math.IsNaN(value) && !math.IsInf(value, 0)
}

// Observe uses receive time from the router's clock, never a remote wall clock.
func (r *Router) Observe(id string, status WorkerStatus) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	w := r.byID[id]
	if w == nil {
		return errors.New("unknown worker")
	}
	if status.Model != w.worker.Profile.Model || status.ProfileID != w.worker.Profile.ID || status.TokenizerID != w.worker.Profile.TokenizerID || status.InstanceID == "" || len(status.Active) > 256 || status.TokenSource != "upstream_tokenizer_api" {
		w.unavailable = true
		return errors.New("worker status identity or token units mismatch")
	}
	if status.InstanceID == w.status.InstanceID && status.Revision < w.status.Revision {
		return errors.New("out of order worker status")
	}
	seen := make(map[string]bool, len(status.Active))
	for _, active := range status.Active {
		if active.ID == "" || seen[active.ID] || !active.Work.Valid() {
			w.unavailable = true
			return errors.New("invalid active invocation accounting")
		}
		seen[active.ID] = true
	}
	for id := range w.ignore {
		if !seen[id] {
			delete(w.ignore, id)
		}
	}
	status.Active = append([]Invocation(nil), status.Active...)
	if r.cache != nil {
		if err := r.cache.Bind(kvcache.Owner{Worker: id, Instance: status.InstanceID, Model: status.Model, Profile: status.ProfileID, Tokenizer: status.TokenizerID, Namespace: r.cache.Namespace(), BackendKind: status.BackendKind}); err != nil {
			w.unavailable = true
			return err
		}
	}
	w.status, w.observed, w.known, w.unavailable = status, r.now(), true, !status.Ready
	return nil
}
func (r *Router) MarkUnavailable(id string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if w := r.byID[id]; w != nil {
		w.unavailable = true
	}
}

func (r *Router) effective(w *workerState, now time.Time) (map[string]Invocation, string, bool) {
	if !w.known || w.unavailable || !w.status.Ready {
		return nil, "unavailable", false
	}
	fresh := now.Sub(w.observed) >= 0 && now.Sub(w.observed) <= r.ttl
	if !fresh && !r.fallback {
		return nil, "stale", false
	}
	active := make(map[string]Invocation)
	source := "local_fallback"
	if fresh {
		source = "worker_snapshot_and_local"
		for _, a := range w.status.Active {
			if !w.ignore[a.ID] {
				active[a.ID] = a
			}
		}
	}
	for id, res := range w.local {
		first := res.first || active[id].FirstText
		active[id] = Invocation{ID: id, Work: res.work, FirstText: first}
	}
	return active, source, true
}

func (r *Router) Reserve(id string, work Work, remainingTTFT time.Duration) (*Reservation, error) {
	return r.ReserveWithPrefix(id, work, remainingTTFT, nil)
}

func (r *Router) ReserveWithPrefix(id string, work Work, remainingTTFT time.Duration, prefix *kvcache.Prefix) (*Reservation, error) {
	if id == "" || !work.Valid() {
		return nil, &Error{Code: "invalid_argument", Message: "valid invocation id and token work required"}
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	for _, w := range r.workers {
		if w.local[id] != nil {
			return nil, &Error{Code: "invalid_argument", Message: "duplicate invocation id"}
		}
	}
	if remainingTTFT <= 0 {
		return nil, &Error{Code: "slo_unachievable", Message: "first text budget exhausted"}
	}
	var candidates []routeCandidate
	preferred := ""
	mostCached := 0
	hadEligible := false
	now := r.now()
	for _, w := range r.workers {
		active, source, ok := r.effective(w, now)
		if !ok {
			continue
		}
		hadEligible = true
		var hint kvcache.Hint
		if r.cache != nil && (r.policy == CacheAffinity || r.policy == CacheAware) {
			hint = r.cache.Lookup(w.worker.ID, w.status.InstanceID, prefix)
			if hint.Tokens > work.PromptTokens-1 {
				hint.Tokens = 0
				hint.State = "token_count_mismatch"
			}
			if hint.Tokens > mostCached {
				mostCached = hint.Tokens
				preferred = w.worker.ID
			}
		}
		if len(active) >= w.worker.Profile.MaxInFlight {
			continue
		}
		prefill, decode := work.PromptTokens, 0
		for _, a := range active {
			if !a.FirstText {
				prefill += a.PromptTokens
			}
			decode += a.OutputTokens
		}
		p := w.worker.Profile
		seconds := p.BaseTTFT.Seconds() + float64(prefill)/p.PrefillTokensPerSecond + float64(decode)/p.DecodeTokensPerSecond
		if seconds > remainingTTFT.Seconds() {
			continue
		}
		// Float seconds lose nanosecond precision near Duration's upper bound.
		// Check the integer budget as well and conservatively round work up.
		nanos := math.Ceil(seconds * float64(time.Second))
		if nanos >= float64(math.MaxInt64) {
			continue
		}
		predicted := time.Duration(nanos)
		if predicted < 0 || predicted > remainingTTFT {
			continue
		}
		decision := Decision{WorkerID: w.worker.ID, Policy: r.policy, MetricsSource: source, PredictedTTFT: predicted, EffectiveInFlight: len(active), Work: work}
		score := seconds + float64(work.OutputTokens)/p.DecodeTokensPerSecond
		if r.policy == LeastInFlight {
			score = float64(len(active))
		}
		queueSeconds := float64(prefill-work.PromptTokens)/p.PrefillTokensPerSecond + float64(decode)/p.DecodeTokensPerSecond
		warmSeconds := seconds
		if r.cache != nil && hint.Tokens > 0 {
			warmSeconds -= float64(hint.Tokens) / p.PrefillTokensPerSecond * r.cacheSavingFraction
		}
		decision.EstimatedReusableTokens = hint.Tokens
		decision.CacheEvidence = hint.Source
		decision.CacheState = hint.State
		if r.cache != nil {
			decision.EstimatedWarmTTFT = time.Duration(math.Ceil(max(0, warmSeconds) * float64(time.Second)))
		}
		candidates = append(candidates, routeCandidate{state: w, decision: decision, score: score, queueSeconds: queueSeconds, warmScore: score - (seconds - warmSeconds)})
	}
	if len(candidates) == 0 {
		if !hadEligible {
			return nil, &Error{Code: "unavailable", Message: "no fresh reachable compatible worker"}
		}
		return nil, &Error{Code: "slo_unachievable", Message: "capacity or predicted first text budget unavailable"}
	}
	chosen := 0
	if r.policy == CacheAware || r.policy == CacheAffinity {
		chosen = r.chooseCache(candidates, preferred)
	} else if r.policy == RoundRobin {
		chosen = int(r.next % uint64(len(candidates)))
		r.next++
	} else {
		for i := 1; i < len(candidates); i++ {
			if candidates[i].score < candidates[chosen].score {
				chosen = i
			}
		}
	}
	c := candidates[chosen]
	res := &Reservation{router: r, worker: c.state, id: id, work: work, Decision: c.decision}
	c.state.local[id] = res
	return res, nil
}
func (res *Reservation) FirstText() {
	res.router.mu.Lock()
	defer res.router.mu.Unlock()
	if res.worker.local[res.id] == res {
		res.first = true
	}
}
func (res *Reservation) Done() {
	res.once.Do(func() {
		r := res.router
		r.mu.Lock()
		defer r.mu.Unlock()
		delete(res.worker.local, res.id)
		for _, a := range res.worker.status.Active {
			if a.ID == res.id {
				res.worker.ignore[res.id] = true
				break
			}
		}
	})
}
func (res *Reservation) Worker() Worker { return res.worker.worker }

type WorkerView struct {
	ID                string `json:"id"`
	Available         bool   `json:"available"`
	Source            string `json:"source"`
	InFlight          int    `json:"in_flight"`
	LocalReservations int    `json:"local_reservations"`
}

func (r *Router) Snapshot() []WorkerView {
	r.mu.Lock()
	defer r.mu.Unlock()
	views := make([]WorkerView, 0, len(r.workers))
	for _, w := range r.workers {
		active, source, ok := r.effective(w, r.now())
		views = append(views, WorkerView{w.worker.ID, ok, source, len(active), len(w.local)})
	}
	return views
}
func (r *Router) EligibleWorkers() []Worker {
	r.mu.Lock()
	defer r.mu.Unlock()
	var out []Worker
	for _, w := range r.workers {
		_, _, ok := r.effective(w, r.now())
		if ok {
			out = append(out, w.worker)
		}
	}
	return out
}
func (r *Router) String() string { return fmt.Sprintf("routing policy=%s", r.policy) }
