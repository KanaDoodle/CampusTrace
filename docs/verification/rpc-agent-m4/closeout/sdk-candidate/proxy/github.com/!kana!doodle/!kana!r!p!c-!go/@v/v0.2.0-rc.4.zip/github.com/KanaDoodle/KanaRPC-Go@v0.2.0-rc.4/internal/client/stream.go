package client

import (
	"context"
	"errors"

	"github.com/KanaDoodle/KanaRPC-Go/internal/codec"
	"github.com/KanaDoodle/KanaRPC-Go/internal/protocol"
	"github.com/KanaDoodle/KanaRPC-Go/internal/transport"
)

func (c *Client) InvokeStream(ctx context.Context, service, method string, request any, window uint32) (*transport.ClientStream, error) {
	c.mu.Lock()
	closed := c.closed
	c.mu.Unlock()
	if closed {
		return nil, ErrClientClosed
	}
	if c.codecType != codec.JSON {
		return nil, errors.New("streaming currently requires JSON codec")
	}
	callCtx, cancel := context.WithTimeout(ctx, c.timeout)
	transferred := false
	defer func() {
		if !transferred {
			cancel()
		}
	}()
	if err := callCtx.Err(); err != nil {
		return nil, err
	}
	if !c.limiter.Allow() {
		return nil, errors.New("rate limit exceeded")
	}
	body, err := c.codec.Marshal(request)
	if err != nil {
		return nil, err
	}
	addr, finish, err := c.selectInstance(callCtx, service)
	if err != nil {
		return nil, err
	}
	pool, err := c.getPool(addr)
	if err != nil {
		finish(context.Canceled)
		return nil, err
	}
	conn, err := pool.Acquire(callCtx)
	if err != nil {
		finish(streamOutcome(err))
		return nil, err
	}
	stream, err := conn.OpenStream(callCtx, &protocol.Message{Header: &protocol.Header{ServiceName: service, MethodName: method, CodecType: protocol.CodecTypeJSON}, Body: body}, window)
	if err != nil {
		finish(streamOutcome(err))
		return nil, err
	}
	stream.OnComplete(func(err error) { cancel(); finish(streamOutcome(err)) })
	transferred = true
	return stream, nil
}

func streamOutcome(err error) error {
	var remote *transport.StreamError
	if errors.As(err, &remote) {
		switch remote.Code {
		case "resource_exhausted", "queue_timeout", "slo_unachievable", "slo_exceeded", "invalid_argument", "unimplemented":
			return context.Canceled
		}
	}
	return err
}
