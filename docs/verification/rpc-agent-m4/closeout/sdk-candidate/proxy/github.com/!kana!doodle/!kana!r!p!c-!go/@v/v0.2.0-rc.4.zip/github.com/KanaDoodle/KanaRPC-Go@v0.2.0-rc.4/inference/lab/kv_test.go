package lab

import (
	"reflect"
	"testing"

	"github.com/KanaDoodle/KanaRPC-Go/inference/scheduler"
)

func TestKVComparisonsDeterministicAndKeepMissesAndRejectedRequests(t *testing.T) {
	for _, scenario := range []string{"repeated_prefixes", "cold_prefixes", "hotspot", "eviction", "event_loss", "stale_events", "instance_slowdown"} {
		var hash string
		for _, policy := range []scheduler.Policy{scheduler.TokenWork, scheduler.CacheAffinity, scheduler.CacheAware} {
			r, err := KVSimulation(7, policy, scenario)
			if err != nil {
				t.Fatal(err)
			}
			again, err := KVSimulation(7, policy, scenario)
			if err != nil || !reflect.DeepEqual(r, again) {
				t.Fatal("nondeterministic simulation", err)
			}
			if r.Offered != 120 || r.Completed+r.Rejected != 120 || len(r.Samples) != 120 || r.TTFT.N != r.Completed {
				t.Fatal(r)
			}
			if hash != "" && hash != r.TraceSHA256 {
				t.Fatal("policies changed offered work")
			}
			hash = r.TraceSHA256
			if scenario == "cold_prefixes" && (r.HintRequests != 0 || r.SimulatedHitRequests != 0) {
				t.Fatal("cold trace invented hits")
			}
			t.Logf("simulation only: %s %s done=%d rejected=%d target_met=%d hint=%d simulated_hit=%d false_hint=%d p95=%s", scenario, policy, r.Completed, r.Rejected, r.WithinTargetCompleted, r.HintRequests, r.SimulatedHitRequests, r.FalseHintRequests, r.TTFT.P95)
		}
	}
}
