// Package lab contains explicitly synthetic peers and comparisons. It never
// loads a model, runs GPU inference, or measures vLLM capacity.
package lab

import (
	"context"
	"crypto/sha256"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"net/http"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/inference/scheduler"
	"github.com/KanaDoodle/KanaRPC-Go/inference/vllm"
	"github.com/KanaDoodle/KanaRPC-Go/rpc"
)

const Model = "fixture-model"
const ProfileID = "fixture-serial-v1"
const TokenizerID = "fixture-words-plus-template-v1"

type Backend struct {
	// Delay and Gap are wall-clock fixture timers, not GPU measurements.
	Delay                                              func(vllm.ChatRequest) time.Duration
	Gap                                                time.Duration
	TokenizeDelay                                      time.Duration
	FailChat                                           bool
	NoTokenIDs                                         bool
	OnChat                                             func(vllm.ChatRequest)
	ChatCalls, TokenCalls, Active, Completed, Canceled atomic.Int64
}

func Wait(ctx context.Context, d time.Duration) bool {
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-ctx.Done():
		return false
	case <-t.C:
		return true
	}
}
func Count(request vllm.ChatRequest) int {
	count := 3 // Deliberately fake chat template; never call this a model tokenizer.
	for _, message := range request.Messages {
		count += len(strings.Fields(message.Content))
	}
	return count
}

// Tokens is a fake word tokenizer used only by fixtures, never by real routing.
func Tokens(request vllm.ChatRequest) []int {
	tokens := []int{1, 2}
	for _, message := range request.Messages {
		for _, word := range strings.Fields(message.Content) {
			hash := sha256.Sum256([]byte(message.Role + "\x00" + word))
			tokens = append(tokens, int(binary.BigEndian.Uint32(hash[:4])&0x7fffffff))
		}
	}
	return append(tokens, 3)
}
func (b *Backend) Handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /v1/models", func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode(map[string]any{"data": []map[string]string{{"id": Model}}})
	})
	mux.HandleFunc("POST /tokenize", func(w http.ResponseWriter, r *http.Request) {
		b.TokenCalls.Add(1)
		var request struct {
			Messages   []vllm.Message `json:"messages"`
			Model      string         `json:"model"`
			Generation bool           `json:"add_generation_prompt"`
		}
		if json.NewDecoder(http.MaxBytesReader(w, r.Body, 100<<10)).Decode(&request) != nil || request.Model != Model || !request.Generation {
			http.Error(w, "bad fixture tokenizer request", 400)
			return
		}
		if !Wait(r.Context(), b.TokenizeDelay) {
			return
		}
		chat := vllm.ChatRequest{Messages: request.Messages}
		result := map[string]any{"count": Count(chat)}
		if !b.NoTokenIDs {
			result["tokens"] = Tokens(chat)
		}
		_ = json.NewEncoder(w).Encode(result)
	})
	mux.HandleFunc("POST /v1/chat/completions", func(w http.ResponseWriter, r *http.Request) {
		b.ChatCalls.Add(1)
		if b.FailChat {
			http.Error(w, "synthetic upstream failure", 503)
			return
		}
		var request vllm.ChatRequest
		if json.NewDecoder(http.MaxBytesReader(w, r.Body, 100<<10)).Decode(&request) != nil {
			http.Error(w, "bad fixture chat", 400)
			return
		}
		if request.InvocationID != "" {
			http.Error(w, "internal metadata leaked to fixture upstream", 400)
			return
		}
		if b.OnChat != nil {
			b.OnChat(request)
		}
		b.Active.Add(1)
		defer b.Active.Add(-1)
		w.Header().Set("Content-Type", "text/event-stream")
		w.(http.Flusher).Flush()
		delay := time.Duration(0)
		if b.Delay != nil {
			delay = b.Delay(request)
		}
		if !Wait(r.Context(), delay) {
			b.Canceled.Add(1)
			return
		}
		for _, text := range []string{"fixture", " output"} {
			data, _ := json.Marshal(vllm.ChatChunk{Model: Model, Choices: []vllm.Choice{{Delta: vllm.Delta{Content: text}}}})
			if _, err := fmt.Fprintf(w, "data: %s\n\n", data); err != nil {
				b.Canceled.Add(1)
				return
			}
			w.(http.Flusher).Flush()
			if !Wait(r.Context(), b.Gap) {
				b.Canceled.Add(1)
				return
			}
		}
		prompt := Count(request)
		data, _ := json.Marshal(vllm.ChatChunk{Model: Model, Usage: &vllm.Usage{PromptTokens: prompt, CompletionTokens: 2, TotalTokens: prompt + 2}})
		_, _ = fmt.Fprintf(w, "data: %s\n\ndata: [DONE]\n\n", data)
		b.Completed.Add(1)
	})
	return mux
}

// StartHTTP and StartRPC own only their loopback listeners and join on close.
func StartHTTP(handler http.Handler) (string, func(), error) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return "", nil, err
	}
	server := &http.Server{Handler: handler, ReadHeaderTimeout: time.Second}
	done := make(chan struct{})
	go func() { defer close(done); _ = server.Serve(listener) }()
	var once sync.Once
	return "http://" + listener.Addr().String(), func() { once.Do(func() { _ = server.Close(); <-done }) }, nil
}
func StartRPC(capacity int, register func(*rpc.Server) error) (*rpc.Server, func(), error) {
	server, err := rpc.NewServer(rpc.ServerConfig{Address: "127.0.0.1:0", MaxConcurrentRequests: capacity})
	if err != nil {
		return nil, nil, err
	}
	if err := register(server); err != nil {
		return nil, nil, err
	}
	done := make(chan error, 1)
	go func() { done <- server.Start() }()
	until := time.Now().Add(3 * time.Second)
	for server.Addr() == nil {
		select {
		case err := <-done:
			return nil, nil, err
		default:
		}
		if time.Now().After(until) {
			server.Shutdown()
			<-done
			return nil, nil, errors.New("fixture listener startup timeout")
		}
		time.Sleep(time.Millisecond)
	}
	var once sync.Once
	return server, func() { once.Do(func() { server.Shutdown(); <-done }) }, nil
}

type Worker struct {
	Endpoint scheduler.Worker
	Adapter  *vllm.Adapter
	close    func()
}

func (w *Worker) Close() { w.close() }
func StartWorker(id string, backend *Backend, capacity int) (*Worker, error) {
	upstream, closeUpstream, err := StartHTTP(backend.Handler())
	if err != nil {
		return nil, err
	}
	adapter, err := vllm.New(vllm.Config{BaseURL: upstream, Model: Model, Scheduling: &vllm.SchedulingConfig{ProfileID: ProfileID, TokenizerID: TokenizerID, BackendKind: "fixture-no-model"}})
	if err != nil {
		closeUpstream()
		return nil, err
	}
	admin, closeAdmin, err := StartHTTP(adapter.AdminHandler())
	if err != nil {
		closeUpstream()
		return nil, err
	}
	server, closeRPC, err := StartRPC(capacity, adapter.Register)
	if err != nil {
		closeAdmin()
		closeUpstream()
		return nil, err
	}
	var once sync.Once
	return &Worker{Endpoint: scheduler.Worker{ID: id, Address: server.Addr().String(), AdminURL: admin, Profile: scheduler.Profile{Model: Model, ID: ProfileID, TokenizerID: TokenizerID, PrefillTokensPerSecond: 100000, DecodeTokensPerSecond: 100000, BaseTTFT: time.Millisecond, MaxInFlight: capacity}}, Adapter: adapter, close: func() { once.Do(func() { closeRPC(); closeAdmin(); closeUpstream() }) }}, nil
}
