package vllm_test

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/inference/lab"
	"github.com/KanaDoodle/KanaRPC-Go/inference/vllm"
	"github.com/KanaDoodle/KanaRPC-Go/rpc"
)

func TestTokenIDsMustBeCompleteExactAndBounded(t *testing.T) {
	for _, test := range []struct {
		body, state string
		tokens      int
	}{{`{"count":3,"tokens":[1,2,3]}`, "available", 3}, {`{"count":3}`, "unavailable", 0}, {`{"count":3,"tokens":[1,2]}`, "invalid", 0}, {`{"count":3,"tokens":[-1,2,3]}`, "invalid", 0}, {`{"count":3,"tokens":[2147483648,2,3]}`, "invalid", 0}, {`{"count":3,"tokens":["1",2,3]}`, "invalid", 0}} {
		t.Run(test.state+test.body, func(t *testing.T) {
			up := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { fmt.Fprint(w, test.body) }))
			defer up.Close()
			a, err := vllm.New(vllm.Config{BaseURL: up.URL, Model: lab.Model})
			if err != nil {
				t.Fatal(err)
			}
			request := vllm.ChatRequest{Messages: []vllm.Message{{Role: "user", Content: "no heuristic fallback"}}}
			details, err := a.TokenizeDetails(context.Background(), request)
			if err != nil || details.Count != 3 || details.TokenIDsState != test.state || len(details.Tokens) != test.tokens {
				t.Fatal(details, err)
			}
			count, err := a.Tokenize(context.Background(), request)
			if err != nil || count != 3 {
				t.Fatal("cache metadata broke count-only routing", count, err)
			}
		})
	}
}
func TestCacheSaltForwardingAndCachedUsageRemainUpstreamReported(t *testing.T) {
	up := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/tokenize" {
			fmt.Fprint(w, `{"count":3,"tokens":[1,2,3]}`)
			return
		}
		var request map[string]any
		if json.NewDecoder(r.Body).Decode(&request) != nil || request["cache_salt"] != "tenant-a" || request["invocation_id"] != nil {
			t.Error("salt or internal metadata forwarding", request)
		}
		w.Header().Set("Content-Type", "text/event-stream")
		fmt.Fprint(w, "data: {\"model\":\"fixture-model\",\"choices\":[{\"delta\":{\"content\":\"fixture\"}}]}\n\ndata: {\"choices\":[],\"usage\":{\"prompt_tokens\":3,\"completion_tokens\":1,\"total_tokens\":4,\"prompt_tokens_details\":{\"cached_tokens\":2}}}\n\ndata: [DONE]\n\n")
	}))
	defer up.Close()
	a, err := vllm.New(vllm.Config{BaseURL: up.URL, Model: lab.Model, Scheduling: &vllm.SchedulingConfig{ProfileID: lab.ProfileID, TokenizerID: lab.TokenizerID}})
	if err != nil {
		t.Fatal(err)
	}
	server, closeServer, err := lab.StartRPC(2, a.Register)
	if err != nil {
		t.Fatal(err)
	}
	defer closeServer()
	c, err := rpc.NewDirectClient(server.Addr().String(), rpc.ClientConfig{Timeout: 3 * time.Second})
	if err != nil {
		t.Fatal(err)
	}
	defer c.Close()
	s, err := c.InvokeStream(context.Background(), vllm.ServiceForModel(lab.Model), vllm.MethodName, vllm.ChatRequest{Messages: []vllm.Message{{Role: "user", Content: "hello"}}, CacheSalt: "tenant-a", InvocationID: "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"})
	if err != nil {
		t.Fatal(err)
	}
	defer s.Close()
	var usage *vllm.Usage
	for {
		var chunk vllm.ChatChunk
		err := s.Recv(&chunk)
		if err == io.EOF {
			break
		}
		if err != nil {
			t.Fatal(err)
		}
		if chunk.Usage != nil {
			usage = chunk.Usage
		}
	}
	if usage == nil || usage.PromptTokensDetails == nil || usage.PromptTokensDetails.CachedTokens != 2 {
		t.Fatal(usage)
	}
	t.Log("synthetic upstream usage forwarding only; not real KV cache evidence")
}

func TestLargeTokenIDResponseKeepsCountWithoutControlAmplification(t *testing.T) {
	up := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode(map[string]any{"count": 65537, "tokens": make([]int, 65537)})
	}))
	defer up.Close()
	a, err := vllm.New(vllm.Config{BaseURL: up.URL, Model: lab.Model})
	if err != nil {
		t.Fatal(err)
	}
	details, err := a.TokenizeDetails(context.Background(), vllm.ChatRequest{Messages: []vllm.Message{{Role: "user", Content: "test"}}})
	if err != nil || details.Count != 65537 || details.TokenIDsState != "too_large" || len(details.Tokens) != 0 {
		t.Fatal(details, err)
	}
}
