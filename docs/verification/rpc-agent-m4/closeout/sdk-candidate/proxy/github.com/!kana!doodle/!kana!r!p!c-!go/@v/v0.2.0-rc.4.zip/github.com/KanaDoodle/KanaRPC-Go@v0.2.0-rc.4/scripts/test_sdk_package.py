"""Packaging guards; temporary source fixtures, no network or model."""
import hashlib
import importlib.util
import pathlib
import subprocess
import tempfile
import unittest
import zipfile

spec = importlib.util.spec_from_file_location('sdk_package', pathlib.Path(__file__).with_name('package-sdk.py'))
sdk = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sdk)


class PackageGuards(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = pathlib.Path(self.temp.name)
        self.repo = self.root / 'repo'
        self.repo.mkdir()
        for name in ['rpc/rpc.go', 'rpc/stream.go', 'inference/gateway/gateway.go']:
            p = self.repo / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text('package fixture\n')
        (self.repo / 'go.mod').write_text('module ' + sdk.MODULE + '\n\ngo 1.25.9\n')
        (self.repo / 'go.sum').write_text('')
        (self.repo / 'LICENSE').write_text('fixture attribution')
        subprocess.run(['git', 'init', '-q'], cwd=self.repo, check=True)
        subprocess.run(['git', 'add', '.'], cwd=self.repo, check=True)
        subprocess.run(['git', '-c', 'user.name=fixture', '-c', 'user.email=fixture@example.invalid',
                        'commit', '-qm', 'fixture'], cwd=self.repo, check=True)

    def tearDown(self):
        self.temp.cleanup()

    def test_reproducible_archive_excludes_local_config_and_preserves_license(self):
        (self.repo / '.env').write_text('SYNTHETIC_NOT_A_SECRET=1')
        (self.repo / 'go.work').write_text('go 1.25.9\nuse .\n')
        for name in ['one', 'two']:
            sdk.package(self.repo, self.root / name, 'v0.2.0-rc.2')
        a = next((self.root / 'one').rglob('*.zip'))
        b = next((self.root / 'two').rglob('*.zip'))
        self.assertEqual(hashlib.sha256(a.read_bytes()).hexdigest(), hashlib.sha256(b.read_bytes()).hexdigest())
        with zipfile.ZipFile(a) as archive:
            files = archive.namelist()
        self.assertIn(sdk.MODULE + '@v0.2.0-rc.2/LICENSE', files)
        self.assertFalse(any(p.endswith(('.env', 'go.work')) for p in files))

    def test_version_is_not_overwritten(self):
        sdk.package(self.repo, self.root / 'one', 'v0.2.0-rc.2')
        with self.assertRaises(ValueError):
            sdk.package(self.repo, self.root / 'one', 'v0.2.0-rc.2')

    def test_clean_release_gate(self):
        self.assertFalse(sdk.package(self.repo, self.root / 'one', 'v0.2.0-rc.2', True)['source_dirty'])
        (self.repo / 'dirty.go').write_text('package fixture\n')
        with self.assertRaises(ValueError):
            sdk.package(self.repo, self.root / 'two', 'v0.2.0-rc.2', True)

    def test_malformed_version_cannot_escape_proxy_directory(self):
        for version in ['../../x', 'latest', 'v2.0.0', 'v0.2.0-rc.1/../x']:
            with self.assertRaises(ValueError):
                sdk.package(self.repo, self.root / 'one', version)

    def test_symlink_is_not_followed(self):
        secret = self.root / 'outside.go'
        secret.write_text('synthetic outside file')
        (self.repo / 'link.go').symlink_to(secret)
        with self.assertRaises(ValueError):
            sdk.package(self.repo, self.root / 'one', 'v0.2.0-rc.2')


if __name__ == '__main__':
    unittest.main()
