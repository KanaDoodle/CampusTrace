// Package gateway composes model-aware routing and bounded local admission on
// top of KanaRPC streams. It never retries an inference after dispatch.
package gateway

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/inference/kvcache"
	"github.com/KanaDoodle/KanaRPC-Go/inference/scheduler"
	"github.com/KanaDoodle/KanaRPC-Go/inference/vllm"
	"github.com/KanaDoodle/KanaRPC-Go/rpc"
)

type Config struct {
	Model              string                    `json:"model"`
	Workers            []scheduler.Worker        `json:"workers"`
	Policy             scheduler.Policy          `json:"policy"`
	MetricsTTL         time.Duration             `json:"metrics_ttl_ns"`
	AllowLocalFallback bool                      `json:"allow_local_fallback"`
	RefreshInterval    time.Duration             `json:"refresh_interval_ns"`
	ControlTimeout     time.Duration             `json:"control_timeout_ns"`
	MaxRequestDuration time.Duration             `json:"max_request_ns"`
	QueueBudget        time.Duration             `json:"queue_budget_ns"`
	InteractiveTTFT    time.Duration             `json:"interactive_ttft_ns"`
	BatchTTFT          time.Duration             `json:"batch_ttft_ns"`
	Admission          scheduler.AdmissionConfig `json:"admission"`
	HTTPClient         *http.Client              `json:"-"`
	KV                 *CacheConfig              `json:"kv,omitempty"`
}
type Request struct {
	Chat          vllm.ChatRequest `json:"chat"`
	Class         scheduler.Class  `json:"class"`
	QueueBudgetMS int              `json:"queue_budget_ms,omitempty"`
	TargetTTFTMS  int              `json:"target_ttft_ms,omitempty"`
}
type Event struct {
	Type         string              `json:"type"`
	Decision     *scheduler.Decision `json:"decision,omitempty"`
	QueueWait    time.Duration       `json:"queue_wait_ns,omitempty"`
	TokenizeTime time.Duration       `json:"tokenize_ns,omitempty"`
	Chunk        json.RawMessage     `json:"chunk,omitempty"`
	Summary      *Summary            `json:"summary,omitempty"`
}
type Summary struct {
	Terminal     string        `json:"terminal"`
	GatewayTTFT  time.Duration `json:"gateway_ttft_ns"`
	TextEventGap time.Duration `json:"gateway_max_text_event_gap_ns"`
	Elapsed      time.Duration `json:"elapsed_ns"`
	TTFTMet      bool          `json:"ttft_met"`
	Usage        *vllm.Usage   `json:"usage,omitempty"`
}
type endpoint struct {
	worker scheduler.Worker
	client *rpc.Client
	base   string
}
type Gateway struct {
	cfg                                         Config
	router                                      *scheduler.Router
	admission                                   *scheduler.Admission
	endpoints                                   map[string]*endpoint
	ordered                                     []*endpoint
	http                                        *http.Client
	ctx                                         context.Context
	cancel                                      context.CancelFunc
	mu                                          sync.Mutex
	closed                                      bool
	wg                                          sync.WaitGroup
	pollGate                                    chan struct{}
	offered, completed, ttftMet, batchCompleted uint64
	outcomes                                    map[string]uint64
	cache                                       *kvcache.Index
}

func ServiceForModel(model string) string { return vllm.ServiceForModel(model) + ".scheduled" }
func DefaultAdmission() scheduler.AdmissionConfig {
	return scheduler.AdmissionConfig{Interactive: scheduler.ClassLimit{Running: 2, RunningTokens: 16384, Queued: 16, QueuedTokens: 65536}, Batch: scheduler.ClassLimit{Running: 1, RunningTokens: 65536, Queued: 16, QueuedTokens: 262144}}
}

func New(cfg Config) (*Gateway, error) {
	if cfg.Policy == "" {
		cfg.Policy = scheduler.TokenWork
	}
	if cfg.MetricsTTL == 0 {
		cfg.MetricsTTL = 2 * time.Second
	}
	if cfg.ControlTimeout == 0 {
		cfg.ControlTimeout = time.Second
	}
	if cfg.MaxRequestDuration == 0 {
		cfg.MaxRequestDuration = time.Minute
	}
	if cfg.QueueBudget == 0 {
		cfg.QueueBudget = time.Second
	}
	if cfg.InteractiveTTFT == 0 {
		cfg.InteractiveTTFT = 500 * time.Millisecond
	}
	if cfg.BatchTTFT == 0 {
		cfg.BatchTTFT = 5 * time.Second
	}
	if cfg.Admission.Interactive.Running == 0 && cfg.Admission.Batch.Running == 0 {
		cfg.Admission = DefaultAdmission()
	}
	if cfg.Model == "" || cfg.MetricsTTL <= 0 || cfg.ControlTimeout <= 0 || cfg.ControlTimeout > 10*time.Second || cfg.MaxRequestDuration <= 0 || cfg.MaxRequestDuration > 10*time.Minute || cfg.QueueBudget <= 0 || cfg.QueueBudget > time.Minute || cfg.InteractiveTTFT <= 0 || cfg.BatchTTFT <= 0 || cfg.RefreshInterval < 0 || (cfg.RefreshInterval > 0 && cfg.RefreshInterval < 10*time.Millisecond) {
		return nil, errors.New("invalid gateway model or budgets")
	}
	for _, w := range cfg.Workers {
		if w.Profile.Model != cfg.Model {
			return nil, errors.New("gateway worker model mismatch")
		}
	}
	var index *kvcache.Index
	var cacheQueue, minGain time.Duration
	var savingFraction float64
	if cfg.KV != nil {
		var err error
		index, err = kvcache.New(cfg.KV.Index)
		if err != nil {
			return nil, err
		}
		cacheQueue = cfg.KV.QueueLimit
		minGain = cfg.KV.MinGain
		savingFraction = cfg.KV.SavingFraction
	}
	route, err := scheduler.NewRouter(scheduler.RouterConfig{Workers: cfg.Workers, Policy: cfg.Policy, StaleAfter: cfg.MetricsTTL, AllowLocalFallback: cfg.AllowLocalFallback, Cache: index, CacheQueueLimit: cacheQueue, MinCacheGain: minGain, CacheSavingFraction: savingFraction})
	if err != nil {
		return nil, err
	}
	admission, err := scheduler.NewAdmission(cfg.Admission)
	if err != nil {
		return nil, err
	}
	h := cfg.HTTPClient
	if h == nil {
		transport := http.DefaultTransport.(*http.Transport).Clone()
		transport.ResponseHeaderTimeout = cfg.ControlTimeout
		h = &http.Client{Transport: transport}
	}
	copyHTTP := *h
	copyHTTP.CheckRedirect = func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }
	ctx, cancel := context.WithCancel(context.Background())
	g := &Gateway{cfg: cfg, router: route, admission: admission, endpoints: make(map[string]*endpoint), http: &copyHTTP, ctx: ctx, cancel: cancel, pollGate: make(chan struct{}, 1), outcomes: make(map[string]uint64)}
	g.cache = index
	for _, w := range cfg.Workers {
		u, e := url.Parse(w.AdminURL)
		if e != nil || u.Host == "" || (u.Scheme != "http" && u.Scheme != "https") || u.User != nil || u.RawQuery != "" || u.Fragment != "" {
			g.Close()
			return nil, errors.New("invalid worker control URL")
		}
		client, e := rpc.NewDirectClient(w.Address, rpc.ClientConfig{Timeout: cfg.MaxRequestDuration})
		if e != nil {
			g.Close()
			return nil, e
		}
		entry := &endpoint{worker: w, client: client, base: strings.TrimRight(u.String(), "/")}
		g.endpoints[w.ID] = entry
		g.ordered = append(g.ordered, entry)
	}
	if cfg.RefreshInterval > 0 {
		g.wg.Add(1)
		go func() {
			defer g.wg.Done()
			ticker := time.NewTicker(cfg.RefreshInterval)
			defer ticker.Stop()
			for {
				_ = g.Refresh(g.ctx)
				select {
				case <-g.ctx.Done():
					return
				case <-ticker.C:
				}
			}
		}()
	}
	return g, nil
}

func (g *Gateway) enter() bool {
	g.mu.Lock()
	defer g.mu.Unlock()
	if g.closed {
		return false
	}
	g.wg.Add(1)
	return true
}
func (g *Gateway) merged(parent context.Context) (context.Context, context.CancelFunc) {
	ctx, cancel := context.WithTimeout(parent, g.cfg.MaxRequestDuration)
	stop := context.AfterFunc(g.ctx, cancel)
	return ctx, func() { stop(); cancel() }
}
func (g *Gateway) Close() {
	g.mu.Lock()
	if g.closed {
		g.mu.Unlock()
		return
	}
	g.closed = true
	g.cancel()
	g.mu.Unlock()
	g.admission.Close()
	for _, e := range g.ordered {
		e.client.Close()
	}
	g.wg.Wait()
	g.http.CloseIdleConnections()
}

func (g *Gateway) control(ctx context.Context, e *endpoint, method, path string, body io.Reader, target any) error {
	ctx, cancel := context.WithTimeout(ctx, g.cfg.ControlTimeout)
	defer cancel()
	request, err := http.NewRequestWithContext(ctx, method, e.base+path, body)
	if err != nil {
		return err
	}
	request.Header.Set("Content-Type", "application/json")
	response, err := g.http.Do(request)
	if err != nil {
		return errors.New("worker control request failed")
	}
	defer response.Body.Close()
	if response.StatusCode != 200 {
		return errors.New("worker control returned non-success status")
	}
	data, err := io.ReadAll(io.LimitReader(response.Body, (1<<20)+1))
	if err != nil || len(data) > 1<<20 {
		return errors.New("worker control body invalid or too large")
	}
	if err := json.Unmarshal(data, target); err != nil {
		return errors.New("worker control JSON invalid")
	}
	return nil
}

// Refresh is bounded and serialized; partial failure excludes only that worker.
func (g *Gateway) Refresh(parent context.Context) error {
	if !g.enter() {
		return &scheduler.Error{Code: "unavailable", Message: "gateway closed"}
	}
	defer g.wg.Done()
	ctx, cancel := g.merged(parent)
	defer cancel()
	select {
	case g.pollGate <- struct{}{}:
	case <-ctx.Done():
		return ctx.Err()
	}
	defer func() { <-g.pollGate }()
	var wg sync.WaitGroup
	slots := make(chan struct{}, 8)
	var ready atomic.Int32
	for _, entry := range g.ordered {
		select {
		case slots <- struct{}{}:
		case <-ctx.Done():
			wg.Wait()
			return ctx.Err()
		}
		wg.Add(1)
		go func(e *endpoint) {
			defer wg.Done()
			defer func() { <-slots }()
			var status scheduler.WorkerStatus
			if err := g.control(ctx, e, http.MethodGet, "/status", nil, &status); err != nil {
				g.router.MarkUnavailable(e.worker.ID)
				return
			}
			if err := g.router.Observe(e.worker.ID, status); err != nil {
				g.router.MarkUnavailable(e.worker.ID)
				return
			}
			if status.Ready {
				ready.Add(1)
			}
		}(entry)
	}
	wg.Wait()
	if ready.Load() == 0 {
		return &scheduler.Error{Code: "unavailable", Message: "no ready compatible worker"}
	}
	return nil
}
func (g *Gateway) count(ctx context.Context, chat vllm.ChatRequest) (int, *kvcache.Prefix, error) {
	chat.InvocationID = ""
	body, err := json.Marshal(chat)
	if err != nil {
		return 0, nil, err
	}
	for _, w := range g.router.EligibleWorkers() {
		if ctx.Err() != nil {
			return 0, nil, ctx.Err()
		}
		e := g.endpoints[w.ID]
		var result struct {
			Count         int    `json:"count"`
			Model         string `json:"model"`
			ProfileID     string `json:"profile_id"`
			TokenizerID   string `json:"tokenizer_id"`
			Source        string `json:"source"`
			Tokens        []int  `json:"tokens"`
			TokenIDsState string `json:"token_ids_state"`
		}
		path := "/tokenize"
		if g.cache != nil && (g.cfg.Policy == scheduler.CacheAware || g.cfg.Policy == scheduler.CacheAffinity) {
			path += "?include_tokens=1"
		}
		if err := g.control(ctx, e, http.MethodPost, path, bytes.NewReader(body), &result); err != nil {
			// A caller's cancellation/budget says nothing about worker health.
			if ctx.Err() != nil {
				return 0, nil, ctx.Err()
			}
			g.router.MarkUnavailable(w.ID)
			continue
		}
		if result.Count < 1 || result.Count > 1<<20 || result.Model != w.Profile.Model || result.ProfileID != w.Profile.ID || result.TokenizerID != w.Profile.TokenizerID || result.Source != "upstream_tokenizer_api" {
			g.router.MarkUnavailable(w.ID)
			continue
		}
		var prefix *kvcache.Prefix
		if g.cache != nil && result.TokenIDsState == "available" && len(result.Tokens) == result.Count {
			prefix, _ = g.cache.Prepare(chat.CacheSalt, result.Tokens)
		}
		return result.Count, prefix, nil
	}
	return 0, nil, &scheduler.Error{Code: "unavailable", Message: "no compatible upstream tokenizer available"}
}

func (g *Gateway) Register(server *rpc.Server) error {
	return server.RegisterStream(ServiceForModel(g.cfg.Model), vllm.MethodName, g.Handle)
}
func statusError(err error) error {
	var scheduled *scheduler.Error
	if errors.As(err, &scheduled) {
		return &rpc.StatusError{Code: scheduled.Code, Message: scheduled.Message}
	}
	return err
}
func outcome(err error) string {
	if err == nil {
		return "eof"
	}
	if errors.Is(err, context.Canceled) {
		return "canceled"
	}
	if errors.Is(err, context.DeadlineExceeded) {
		return "deadline_exceeded"
	}
	var status *rpc.StatusError
	if errors.As(err, &status) {
		return status.Code
	}
	var remote *rpc.StreamError
	if errors.As(err, &remote) {
		return remote.Code
	}
	return "internal"
}

func (g *Gateway) Handle(parent context.Context, raw json.RawMessage, out *rpc.ServerStream) (result error) {
	if !g.enter() {
		return &rpc.StatusError{Code: "unavailable", Message: "gateway closed"}
	}
	defer g.wg.Done()
	started := time.Now()
	ctx, cancel := g.merged(parent)
	defer cancel()
	class := scheduler.Interactive
	success, met := false, false
	g.mu.Lock()
	g.offered++
	g.mu.Unlock()
	defer func() {
		g.mu.Lock()
		defer g.mu.Unlock()
		g.outcomes[outcome(result)]++
		if success {
			g.completed++
			if met {
				g.ttftMet++
			}
			if class == scheduler.Batch {
				g.batchCompleted++
			}
		}
	}()
	var request Request
	if len(raw) > vllm.MaxPromptBytes+(16<<10) {
		return &rpc.StatusError{Code: "invalid_argument", Message: "request too large"}
	}
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&request); err != nil {
		return &rpc.StatusError{Code: "invalid_argument", Message: "invalid scheduled request"}
	}
	if request.Class != "" {
		class = request.Class
	}
	if class != scheduler.Interactive && class != scheduler.Batch {
		return &rpc.StatusError{Code: "invalid_argument", Message: "unknown workload class"}
	}
	if err := vllm.ValidateRequest(&request.Chat); err != nil {
		return &rpc.StatusError{Code: "invalid_argument", Message: "invalid chat input"}
	}
	target := g.cfg.InteractiveTTFT
	if class == scheduler.Batch {
		target = g.cfg.BatchTTFT
	}
	if request.TargetTTFTMS != 0 {
		if request.TargetTTFTMS < 1 || request.TargetTTFTMS > 30000 {
			return &rpc.StatusError{Code: "invalid_argument", Message: "TTFT target must be 1 to 30000 ms"}
		}
		target = time.Duration(request.TargetTTFTMS) * time.Millisecond
	}
	queueBudget := g.cfg.QueueBudget
	if request.QueueBudgetMS != 0 {
		if request.QueueBudgetMS < 1 || time.Duration(request.QueueBudgetMS)*time.Millisecond > g.cfg.QueueBudget {
			return &rpc.StatusError{Code: "invalid_argument", Message: "queue budget exceeds gateway limit"}
		}
		queueBudget = time.Duration(request.QueueBudgetMS) * time.Millisecond
	}
	ttftUntil := started.Add(target)
	queueUntil := started.Add(queueBudget)
	if ttftUntil.Before(queueUntil) {
		queueUntil = ttftUntil
	}
	countCtx, countCancel := context.WithDeadline(ctx, ttftUntil)
	prompt, prefix, err := g.count(countCtx, request.Chat)
	countCancel()
	tokenizeTime := time.Since(started)
	if err != nil {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		if !time.Now().Before(ttftUntil) {
			return &rpc.StatusError{Code: "slo_exceeded", Message: "first text budget exhausted during tokenization"}
		}
		return statusError(err)
	}
	work := scheduler.Work{PromptTokens: prompt, OutputTokens: request.Chat.MaxTokens}
	permit, err := g.admission.Acquire(ctx, class, work, queueUntil)
	if err != nil {
		return statusError(err)
	}
	defer permit.Release()
	if !time.Now().Before(queueUntil) {
		return &rpc.StatusError{Code: "queue_timeout", Message: "queue budget exhausted before dispatch"}
	}
	id, err := vllm.NewInvocationID()
	if err != nil {
		return err
	}
	request.Chat.InvocationID = id
	reservation, err := g.router.ReserveWithPrefix(id, work, time.Until(ttftUntil), prefix)
	if err != nil {
		return statusError(err)
	}
	defer reservation.Done()
	if err := out.Send(Event{Type: "scheduled", Decision: &reservation.Decision, QueueWait: permit.QueueWait, TokenizeTime: tokenizeTime}); err != nil {
		return err
	}
	runCtx, runCancel := context.WithCancel(ctx)
	defer runCancel()
	timer := time.AfterFunc(time.Until(ttftUntil), runCancel)
	defer timer.Stop()
	endpoint := g.endpoints[reservation.Decision.WorkerID]
	stream, err := endpoint.client.InvokeStream(runCtx, vllm.ServiceForModel(g.cfg.Model), vllm.MethodName, request.Chat)
	if err != nil {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		if runCtx.Err() != nil {
			return &rpc.StatusError{Code: "slo_exceeded", Message: "worker missed first text deadline"}
		}
		return err
	}
	defer stream.Close()
	var first, last, maxGap time.Duration
	var usage *vllm.Usage
	for {
		var data json.RawMessage
		err := stream.Recv(&data)
		if err == io.EOF {
			break
		}
		if err != nil {
			if ctx.Err() != nil {
				return ctx.Err()
			}
			if first == 0 && runCtx.Err() != nil {
				return &rpc.StatusError{Code: "slo_exceeded", Message: "worker missed first text deadline"}
			}
			return err
		}
		var chunk vllm.ChatChunk
		if err := json.Unmarshal(data, &chunk); err != nil {
			return errors.New("invalid upstream chat chunk")
		}
		if chunk.Model != "" && chunk.Model != g.cfg.Model {
			return errors.New("worker returned a different model")
		}
		if chunk.Usage != nil {
			usage = chunk.Usage
		}
		if vllm.HasText(chunk) {
			elapsed := time.Since(started)
			if first == 0 {
				if !time.Now().Before(ttftUntil) {
					return &rpc.StatusError{Code: "slo_exceeded", Message: "first text arrived after target"}
				}
				first = elapsed
				timer.Stop()
				reservation.FirstText()
			} else {
				if gap := elapsed - last; gap > maxGap {
					maxGap = gap
				}
			}
			last = elapsed
		}
		if err := out.Send(Event{Type: "chunk", Chunk: data}); err != nil {
			return err
		}
	}
	if first == 0 {
		return errors.New("worker completed without text")
	}
	met = first <= target
	if err := out.Send(Event{Type: "summary", Summary: &Summary{Terminal: "eof", GatewayTTFT: first, TextEventGap: maxGap, Elapsed: time.Since(started), TTFTMet: met, Usage: usage}}); err != nil {
		return err
	}
	success = true
	return nil
}

type Snapshot struct {
	Ready          bool                    `json:"ready"`
	Offered        uint64                  `json:"offered"`
	Completed      uint64                  `json:"completed"`
	TTFTMet        uint64                  `json:"ttft_met"`
	BatchCompleted uint64                  `json:"batch_completed"`
	Outcomes       map[string]uint64       `json:"outcomes"`
	Admission      scheduler.AdmissionView `json:"admission"`
	Workers        []scheduler.WorkerView  `json:"workers"`
	KV             []kvcache.View          `json:"kv,omitempty"`
}

func (g *Gateway) Snapshot() Snapshot {
	g.mu.Lock()
	snapshot := Snapshot{Offered: g.offered, Completed: g.completed, TTFTMet: g.ttftMet, BatchCompleted: g.batchCompleted, Outcomes: make(map[string]uint64)}
	closed := g.closed
	for key, value := range g.outcomes {
		snapshot.Outcomes[key] = value
	}
	g.mu.Unlock()
	snapshot.Admission = g.admission.Snapshot()
	snapshot.Workers = g.router.Snapshot()
	if g.cache != nil {
		snapshot.KV = g.cache.Snapshot()
	}
	for _, w := range snapshot.Workers {
		if w.Available && !closed {
			snapshot.Ready = true
		}
	}
	return snapshot
}
func (g *Gateway) AdminHandler() http.Handler {
	mux := http.NewServeMux()
	g.cacheHandler(mux)
	mux.HandleFunc("GET /status", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(g.Snapshot())
	})
	return mux
}
