package vllm_test

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/inference/lab"
	"github.com/KanaDoodle/KanaRPC-Go/inference/scheduler"
	"github.com/KanaDoodle/KanaRPC-Go/inference/vllm"
	"github.com/KanaDoodle/KanaRPC-Go/rpc"
)

func TestTokenizerUsesRootAPIAndChatTemplate(t *testing.T) {
	up := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/tokenize" || r.Header.Get("Authorization") != "Bearer secret" {
			t.Error("wrong tokenizer endpoint/auth")
		}
		var body map[string]any
		if json.NewDecoder(r.Body).Decode(&body) != nil || body["model"] != "test-model" || body["add_generation_prompt"] != true || body["invocation_id"] != nil {
			t.Error(body)
		}
		fmt.Fprint(w, `{"count":123,"tokens":[1,2,3]}`)
	}))
	defer up.Close()
	a, err := vllm.New(vllm.Config{BaseURL: up.URL + "/v1", Model: "test-model", APIKey: "secret"})
	if err != nil {
		t.Fatal(err)
	}
	count, err := a.Tokenize(context.Background(), vllm.ChatRequest{Messages: []vllm.Message{{Role: "user", Content: "中文 prompt"}}, MaxTokens: 16, InvocationID: "not-forwarded"})
	if err != nil || count != 123 {
		t.Fatal(count, err)
	}
}
func TestTokenizerFailsClosedWithoutHeuristicFallback(t *testing.T) {
	for _, reply := range []string{`{}`, `{"count":0}`, `{"count":-1}`, `{"count":1048577}`, `{"count":1.5}`, `broken`, strings.Repeat("x", (8<<20)+1)} {
		t.Run(fmt.Sprintf("bytes_%d_%s", len(reply), reply[:min(8, len(reply))]), func(t *testing.T) {
			up := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { fmt.Fprint(w, reply) }))
			defer up.Close()
			a, err := vllm.New(vllm.Config{BaseURL: up.URL, Model: lab.Model})
			if err != nil {
				t.Fatal(err)
			}
			_, err = a.Tokenize(context.Background(), vllm.ChatRequest{Messages: []vllm.Message{{Role: "user", Content: "long enough for a hidden fallback"}}})
			if err == nil {
				t.Fatal("invalid tokenizer silently accepted")
			}
		})
	}
}
func TestTokenizerCancellationInterruptsHTTP(t *testing.T) {
	stopped := make(chan struct{})
	up := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = io.Copy(io.Discard, r.Body)
		<-r.Context().Done()
		close(stopped)
	}))
	defer up.Close()
	a, _ := vllm.New(vllm.Config{BaseURL: up.URL, Model: lab.Model})
	ctx, cancel := context.WithTimeout(context.Background(), 80*time.Millisecond)
	defer cancel()
	_, err := a.Tokenize(ctx, vllm.ChatRequest{Messages: []vllm.Message{{Role: "user", Content: "cancel"}}})
	if !errors.Is(err, context.DeadlineExceeded) {
		t.Fatal(err)
	}
	select {
	case <-stopped:
	case <-time.After(time.Second):
		t.Fatal("tokenizer HTTP not canceled")
	}
}
func TestWorkerControlRemainsAvailableAtRPCExecutionCapacity(t *testing.T) {
	b := &lab.Backend{Delay: func(vllm.ChatRequest) time.Duration { return time.Second }, Gap: time.Second}
	w, err := lab.StartWorker("full", b, 1)
	if err != nil {
		t.Fatal(err)
	}
	defer w.Close()
	c, err := rpc.NewDirectClient(w.Endpoint.Address, rpc.ClientConfig{Timeout: 4 * time.Second})
	if err != nil {
		t.Fatal(err)
	}
	defer c.Close()
	s, err := c.InvokeStream(context.Background(), vllm.ServiceForModel(lab.Model), vllm.MethodName, vllm.ChatRequest{Messages: []vllm.Message{{Role: "user", Content: "hold"}}, MaxTokens: 16})
	if err != nil {
		t.Fatal(err)
	}
	defer s.Close()
	until := time.Now().Add(time.Second)
	for len(w.Adapter.Status().Active) != 1 {
		if time.Now().After(until) {
			t.Fatal("no active invocation")
		}
		time.Sleep(time.Millisecond)
	}
	response, err := http.Get(w.Endpoint.AdminURL + "/status")
	if err != nil {
		t.Fatal(err)
	}
	var status scheduler.WorkerStatus
	err = json.NewDecoder(response.Body).Decode(&status)
	response.Body.Close()
	if err != nil || !status.Ready || status.WaitingForFirstText != 1 || len(status.Active) != 1 || status.BackendKind != "fixture-no-model" {
		t.Fatal(status, err)
	}
	_, err = c.InvokeStream(context.Background(), vllm.ServiceForModel(lab.Model), vllm.MethodName, vllm.ChatRequest{Messages: []vllm.Message{{Role: "user", Content: "overload"}}})
	var remote *rpc.StreamError
	if !errors.As(err, &remote) || remote.Code != "resource_exhausted" {
		t.Fatal(err)
	}
	_ = s.Close()
	until = time.Now().Add(time.Second)
	for len(w.Adapter.Status().Active) != 0 {
		if time.Now().After(until) {
			t.Fatal("tracking leaked")
		}
		time.Sleep(time.Millisecond)
	}
	if w.Adapter.Status().Failed != 1 {
		t.Fatal(w.Adapter.Status())
	}
}
