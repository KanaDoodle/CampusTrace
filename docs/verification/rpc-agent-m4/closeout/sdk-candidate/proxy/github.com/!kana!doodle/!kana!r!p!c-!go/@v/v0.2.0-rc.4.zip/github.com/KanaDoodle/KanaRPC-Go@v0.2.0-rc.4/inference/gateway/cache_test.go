package gateway_test

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"strings"
	"testing"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/inference/gateway"
	"github.com/KanaDoodle/KanaRPC-Go/inference/kvcache"
	"github.com/KanaDoodle/KanaRPC-Go/inference/lab"
	"github.com/KanaDoodle/KanaRPC-Go/inference/scheduler"
	"github.com/KanaDoodle/KanaRPC-Go/inference/vllm"
	"github.com/KanaDoodle/KanaRPC-Go/rpc"
)

const cacheNamespace = "fixture-weights-template-layout-v1"
const cacheEpoch = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"

func postKV(t *testing.T, url string, value any) int {
	t.Helper()
	data, _ := json.Marshal(value)
	resp, err := http.Post(url, "application/json", bytes.NewReader(data))
	if err != nil {
		t.Fatal(err)
	}
	_, _ = io.Copy(io.Discard, resp.Body)
	resp.Body.Close()
	return resp.StatusCode
}
func cacheSetup(t *testing.T, noTokens bool) (*gateway.Gateway, *rpc.Client, []*lab.Worker, string, *lab.Backend) {
	t.Helper()
	var workers []*lab.Worker
	var endpoints []scheduler.Worker
	var second *lab.Backend
	for _, id := range []string{"a", "b"} {
		backend := &lab.Backend{NoTokenIDs: noTokens, Gap: time.Millisecond, Delay: func(request vllm.ChatRequest) time.Duration {
			if strings.HasPrefix(request.Messages[0].Content, "busy") {
				return 500 * time.Millisecond
			}
			return 0
		}}
		w, err := lab.StartWorker(id, backend, 8)
		if err != nil {
			t.Fatal(err)
		}
		t.Cleanup(w.Close)
		workers = append(workers, w)
		e := w.Endpoint
		e.Profile.PrefillTokensPerSecond = 1000
		e.Profile.DecodeTokensPerSecond = 1000
		endpoints = append(endpoints, e)
		second = backend
	}
	g, err := gateway.New(gateway.Config{Model: lab.Model, Workers: endpoints, Policy: scheduler.CacheAware, MetricsTTL: time.Minute, InteractiveTTFT: time.Second, KV: &gateway.CacheConfig{Index: kvcache.Config{Namespace: cacheNamespace, BlockSize: 2, Capacity: 128, TTL: time.Second}, QueueLimit: 50 * time.Millisecond}})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(g.Close)
	if err := g.Refresh(context.Background()); err != nil {
		t.Fatal(err)
	}
	server, closeFront, err := lab.StartRPC(32, g.Register)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(closeFront)
	c, err := rpc.NewDirectClient(server.Addr().String(), rpc.ClientConfig{Timeout: 3 * time.Second})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(c.Close)
	admin, closeAdmin, err := lab.StartHTTP(g.AdminHandler())
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(closeAdmin)
	return g, c, workers, admin, second
}
func seedCache(t *testing.T, worker *lab.Worker, admin string, chat vllm.ChatRequest) kvcache.Owner {
	t.Helper()
	status := worker.Adapter.Status()
	owner := kvcache.Owner{Worker: worker.Endpoint.ID, Instance: status.InstanceID, Model: lab.Model, Profile: lab.ProfileID, Tokenizer: lab.TokenizerID, Namespace: cacheNamespace, BackendKind: status.BackendKind}
	if code := postKV(t, admin+"/kv/reset", kvcache.Reset{Owner: owner, Epoch: cacheEpoch}); code != 204 {
		t.Fatal(code)
	}
	tokens := lab.Tokens(chat)
	n := (len(tokens) - 1) / 2
	var hashes []string
	for k := 0; k < n; k++ {
		hashes = append(hashes, strings.Repeat("h", k+1))
	}
	if code := postKV(t, admin+"/kv/events", kvcache.Batch{Owner: owner, Epoch: cacheEpoch, Sequence: 0, Source: kvcache.FixtureSource, Events: []kvcache.Event{{Type: "stored", Hashes: hashes, Tokens: tokens[:n*2], BlockSize: 2, Salt: chat.CacheSalt}}}); code != 204 {
		t.Fatal(code)
	}
	return owner
}
func TestCacheGatewayUsesExactTokensSaltAndSpillsBeforeDispatch(t *testing.T) {
	g, c, workers, admin, backend := cacheSetup(t, false)
	request := input("alpha beta gamma delta epsilon zeta eta theta")
	request.Chat.CacheSalt = "tenant-a"
	owner := seedCache(t, workers[1], admin, request.Chat)
	events, err := collect(context.Background(), c, request)
	if err != nil {
		t.Fatal(err)
	}
	if d := events[0].Decision; d.WorkerID != "b" || d.EstimatedReusableTokens == 0 || d.CacheEvidence != kvcache.FixtureSource {
		t.Fatal(d)
	}
	other := request
	other.Chat.CacheSalt = "tenant-b"
	events, err = collect(context.Background(), c, other)
	if err != nil {
		t.Fatal(err)
	}
	if d := events[0].Decision; d.EstimatedReusableTokens != 0 || d.WorkerID != "a" {
		t.Fatal("cross-salt hint", d)
	}
	busyClient, err := rpc.NewDirectClient(workers[1].Endpoint.Address, rpc.ClientConfig{Timeout: 3 * time.Second})
	if err != nil {
		t.Fatal(err)
	}
	defer busyClient.Close()
	busy, err := busyClient.InvokeStream(context.Background(), vllm.ServiceForModel(lab.Model), vllm.MethodName, vllm.ChatRequest{Messages: []vllm.Message{{Role: "user", Content: "busy " + strings.Repeat("long ", 200)}}, MaxTokens: 16})
	if err != nil {
		t.Fatal(err)
	}
	defer busy.Close()
	eventually(t, func() bool { return backend.Active.Load() == 1 })
	if err := g.Refresh(context.Background()); err != nil {
		t.Fatal(err)
	}
	events, err = collect(context.Background(), c, request)
	if err != nil {
		t.Fatal(err)
	}
	if d := events[0].Decision; d.WorkerID != "a" || d.RoutingReason != "cache_queue_limit" {
		t.Fatal(d)
	}
	if code := postKV(t, admin+"/kv/events", kvcache.Batch{Owner: owner, Epoch: cacheEpoch, Sequence: 2, Source: kvcache.FixtureSource}); code != 409 {
		t.Fatal("gap accepted", code)
	}
	events, err = collect(context.Background(), c, request)
	if err != nil {
		t.Fatal(err)
	}
	if d := events[0].Decision; d.EstimatedReusableTokens != 0 {
		t.Fatal("gap kept cache credit", d)
	}
	_ = busy.Close()
	eventually(t, func() bool { return backend.Active.Load() == 0 })
	g.Close()
	for _, view := range g.Snapshot().Workers {
		if view.LocalReservations != 0 {
			t.Fatal(view)
		}
	}
}
func TestCacheGatewayMissingTokenIDsFallsBackWithoutInventingPrefix(t *testing.T) {
	_, c, workers, admin, _ := cacheSetup(t, true)
	request := input("alpha beta gamma delta")
	request.Chat.CacheSalt = "tenant-a"
	seedCache(t, workers[1], admin, request.Chat)
	events, err := collect(context.Background(), c, request)
	if err != nil {
		t.Fatal(err)
	}
	if d := events[0].Decision; d.EstimatedReusableTokens != 0 || d.RoutingReason != "load_no_token_ids" || d.WorkerID != "a" {
		t.Fatal(d)
	}
}
func TestCacheControlRejectsUnknownWorkersMalformedAndStaleReset(t *testing.T) {
	_, _, workers, admin, _ := cacheSetup(t, false)
	owner := seedCache(t, workers[1], admin, input("alpha beta gamma").Chat)
	bad := owner
	bad.Worker = "unknown"
	if code := postKV(t, admin+"/kv/reset", kvcache.Reset{Owner: bad, Epoch: cacheEpoch}); code != 409 {
		t.Fatal(code)
	}
	if code := postKV(t, admin+"/kv/reset", kvcache.Reset{Owner: owner, PreviousEpoch: cacheEpoch, Epoch: "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"}); code != 204 {
		t.Fatal(code)
	}
	if code := postKV(t, admin+"/kv/reset", kvcache.Reset{Owner: owner, Epoch: cacheEpoch}); code != 409 {
		t.Fatal(code)
	}
	resp, err := http.Post(admin+"/kv/events", "application/json", strings.NewReader(`{} {}`))
	if err != nil {
		t.Fatal(err)
	}
	resp.Body.Close()
	if resp.StatusCode != 400 {
		t.Fatal(resp.StatusCode)
	}
}
