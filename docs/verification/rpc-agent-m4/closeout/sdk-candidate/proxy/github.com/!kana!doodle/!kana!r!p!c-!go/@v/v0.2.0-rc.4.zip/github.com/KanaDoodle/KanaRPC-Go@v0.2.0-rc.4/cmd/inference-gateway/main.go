package main

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/inference/gateway"
	"github.com/KanaDoodle/KanaRPC-Go/rpc"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
func run() error {
	configPath := flag.String("config", "", "gateway JSON config (required; durations in ns)")
	listen := flag.String("listen", "127.0.0.1:9094", "scheduled RPC address")
	adminListen := flag.String("admin-listen", "127.0.0.1:9095", "private HTTP status address")
	etcd := flag.String("etcd", "", "optional service discovery endpoint")
	flag.Parse()
	if *configPath == "" {
		return errors.New("-config is required")
	}
	file, err := os.Open(*configPath)
	if err != nil {
		return err
	}
	data, readErr := io.ReadAll(io.LimitReader(file, (1<<20)+1))
	file.Close()
	// Config is small, local, and contains no upstream API key.
	if readErr != nil {
		return errors.New("cannot read config")
	}
	if len(data) > 1<<20 {
		return errors.New("config exceeds 1 MiB")
	}
	var cfg gateway.Config
	decoder := json.NewDecoder(bytes.NewReader(data))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&cfg); err != nil {
		return fmt.Errorf("config: %w", err)
	}
	if cfg.RefreshInterval == 0 {
		cfg.RefreshInterval = 250 * time.Millisecond
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	g, err := gateway.New(cfg)
	if err != nil {
		return err
	}
	defer g.Close()
	preflight, cancel := context.WithTimeout(ctx, 10*time.Second)
	err = g.Refresh(preflight)
	cancel()
	if err != nil {
		return fmt.Errorf("worker preflight: %w", err)
	}
	server, err := rpc.NewServer(rpc.ServerConfig{Address: *listen, MaxConcurrentRequests: 256})
	if err != nil {
		return err
	}
	if err := g.Register(server); err != nil {
		return err
	}
	done := make(chan error, 1)
	go func() { done <- server.Start() }()
	defer func() { g.Close(); server.Shutdown(); <-done }()
	until := time.NewTimer(5 * time.Second)
	defer until.Stop()
	tick := time.NewTicker(time.Millisecond)
	defer tick.Stop()
	for server.Addr() == nil {
		select {
		case err := <-done:
			done <- err
			return err
		case <-ctx.Done():
			return nil
		case <-until.C:
			return errors.New("RPC startup timeout")
		case <-tick.C:
		}
	}
	listener, err := net.Listen("tcp", *adminListen)
	if err != nil {
		return err
	}
	admin := &http.Server{Handler: g.AdminHandler(), ReadHeaderTimeout: 2 * time.Second, ReadTimeout: 3 * time.Second, WriteTimeout: 3 * time.Second, IdleTimeout: 30 * time.Second, MaxHeaderBytes: 8192}
	adminDone := make(chan error, 1)
	go func() { adminDone <- admin.Serve(listener) }()
	defer func() { _ = admin.Close(); <-adminDone }()
	if *etcd != "" {
		reg, err := rpc.NewRegistry([]string{*etcd})
		if err != nil {
			return err
		}
		defer reg.Close()
		if err := reg.Register(gateway.ServiceForModel(cfg.Model), server.Addr().String(), 10); err != nil {
			return err
		}
	}
	if err := json.NewEncoder(os.Stdout).Encode(map[string]any{"event": "ready", "address": server.Addr().String(), "admin_url": "http://" + listener.Addr().String(), "model": cfg.Model, "policy": cfg.Policy, "discovery": *etcd != ""}); err != nil {
		return err
	}
	select {
	case <-ctx.Done():
		return nil
	case err := <-done:
		done <- err
		return err
	case err := <-adminDone:
		adminDone <- err
		return err
	}
}
