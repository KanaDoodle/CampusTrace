package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/inference/vllm"
	"github.com/KanaDoodle/KanaRPC-Go/rpc"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
func run() error {
	listen := flag.String("listen", "127.0.0.1:9093", "RPC listen address")
	upstream := flag.String("upstream", "http://127.0.0.1:8000", "vLLM HTTP base URL")
	model := flag.String("model", "", "model served by this worker (required)")
	keyEnv := flag.String("api-key-env", "VLLM_API_KEY", "environment variable containing upstream bearer key")
	etcd := flag.String("etcd", "", "optional isolated/service etcd endpoint")
	concurrency := flag.Int("concurrency", 16, "maximum executing RPCs")
	adminListen := flag.String("admin-listen", "", "optional private HTTP control address; enables M2 token accounting")
	profile := flag.String("profile", "", "engine calibration profile ID (required with admin-listen)")
	tokenizer := flag.String("tokenizer", "", "tokenizer/chat-template revision ID (required with admin-listen)")
	backendKind := flag.String("backend-kind", "configured-upstream", "evidence label, e.g. fixture-no-model; not engine attestation")
	flag.Parse()
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	var scheduling *vllm.SchedulingConfig
	if *adminListen != "" {
		scheduling = &vllm.SchedulingConfig{ProfileID: *profile, TokenizerID: *tokenizer, BackendKind: *backendKind, MaxTracked: *concurrency}
	}
	a, err := vllm.New(vllm.Config{BaseURL: *upstream, Model: *model, APIKey: os.Getenv(*keyEnv), Scheduling: scheduling})
	if err != nil {
		return err
	}
	preflight, cancel := context.WithTimeout(ctx, 15*time.Second)
	models, err := a.Models(preflight)
	cancel()
	if err != nil {
		return fmt.Errorf("model preflight: %w", err)
	}
	found := false
	for _, id := range models {
		if id == *model {
			found = true
		}
	}
	if !found {
		return errors.New("configured model not advertised by upstream")
	}
	adminAddress := ""
	adminDone := make(chan error, 1)
	if *adminListen != "" {
		listener, err := net.Listen("tcp", *adminListen)
		if err != nil {
			return err
		}
		adminAddress = "http://" + listener.Addr().String()
		admin := &http.Server{Handler: a.AdminHandler(), ReadHeaderTimeout: 2 * time.Second, ReadTimeout: 3 * time.Second, WriteTimeout: 4 * time.Second, IdleTimeout: 30 * time.Second, MaxHeaderBytes: 8192}
		go func() { adminDone <- admin.Serve(listener) }()
		defer func() { _ = admin.Close(); <-adminDone }()
	}
	s, err := rpc.NewServer(rpc.ServerConfig{Address: *listen, MaxConcurrentRequests: *concurrency})
	if err != nil {
		return err
	}
	if err := a.Register(s); err != nil {
		return err
	}
	done := make(chan error, 1)
	go func() { done <- s.Start() }()
	// Always wait for the server owner; signal handling never outlives main.
	defer func() { s.Shutdown(); <-done }()
	until := time.NewTimer(5 * time.Second)
	defer until.Stop()
	tick := time.NewTicker(time.Millisecond)
	defer tick.Stop()
	for s.Addr() == nil {
		select {
		case err := <-done:
			done <- err
			return err
		case <-ctx.Done():
			return nil
		case <-until.C:
			return errors.New("RPC listener startup timed out")
		case <-tick.C:
		}
	}
	var reg *rpc.Registry
	if *etcd != "" {
		reg, err = rpc.NewRegistry([]string{*etcd})
		if err != nil {
			return err
		}
		defer reg.Close()
		if err := reg.Register(vllm.ServiceForModel(*model), s.Addr().String(), 10); err != nil {
			return err
		}
	}
	if err := json.NewEncoder(os.Stdout).Encode(map[string]any{"event": "ready", "address": s.Addr().String(), "admin_url": adminAddress, "model": *model, "discovery": reg != nil, "backend": *backendKind}); err != nil {
		return err
	}
	select {
	case <-ctx.Done():
		return nil
	case err := <-done:
		done <- err
		return err
	case err := <-adminDone:
		adminDone <- err
		return err
	}
}
