package kvcache

import (
	"encoding/json"
	"errors"
	"fmt"
	"sync"
	"testing"
	"time"
)

const epochA = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
const epochB = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"

func setup(t testing.TB) (*Index, Owner, *time.Time) {
	t.Helper()
	now := time.Unix(100, 0)
	index, err := New(Config{Namespace: "model-weights-template-layout-v1", BlockSize: 2, Capacity: 16, TTL: time.Second, Now: func() time.Time { return now }})
	if err != nil {
		t.Fatal(err)
	}
	owner := Owner{Worker: "w0", Instance: "boot", Model: "m", Profile: "p", Tokenizer: "t", Namespace: index.cfg.Namespace}
	if err := index.Bind(owner); err != nil {
		t.Fatal(err)
	}
	if err := index.Reset(Reset{Owner: owner, Epoch: epochA}); err != nil {
		t.Fatal(err)
	}
	return index, owner, &now
}
func stored(ids ...string) Event {
	return Event{Type: "stored", Hashes: ids, Tokens: []int{1, 2, 3, 4}[:2*len(ids)], BlockSize: 2, Salt: "tenant-a"}
}
func apply(t testing.TB, index *Index, owner Owner, seq uint64, events ...Event) {
	t.Helper()
	if err := index.Apply(Batch{Owner: owner, Epoch: epochA, Sequence: seq, Source: FixtureSource, Events: events}); err != nil {
		t.Fatal(err)
	}
}
func hint(t testing.TB, index *Index, owner Owner, salt string) Hint {
	t.Helper()
	p, err := index.Prepare(salt, []int{1, 2, 3, 4, 5})
	if err != nil {
		t.Fatal(err)
	}
	return index.Lookup(owner.Worker, owner.Instance, p)
}
func TestPrefixIndexTracksStoredRemovedAndClearedEvents(t *testing.T) {
	i, o, _ := setup(t)
	if h := hint(t, i, o, "tenant-a"); h.Tokens != 0 || h.State != "cold" {
		t.Fatal(h)
	}
	apply(t, i, o, 10, stored("root", "child"))
	if h := hint(t, i, o, "tenant-a"); h.Tokens != 4 || h.Source != FixtureSource {
		t.Fatal(h)
	}
	apply(t, i, o, 11, stored("root", "child"))
	if i.Snapshot()[0].Blocks != 2 {
		t.Fatal("duplicate store inflated blocks")
	}
	apply(t, i, o, 12, Event{Type: "removed", Hashes: []string{"root"}})
	if h := hint(t, i, o, "tenant-a"); h.Tokens != 0 {
		t.Fatal("child counted without root", h)
	}
	apply(t, i, o, 13, stored("root"))
	if h := hint(t, i, o, "tenant-a"); h.Tokens != 4 {
		t.Fatal(h)
	}
	apply(t, i, o, 14, Event{Type: "cleared"})
	if h := hint(t, i, o, "tenant-a"); h.Tokens != 0 {
		t.Fatal(h)
	}
}
func TestSaltTemplateAndWorkerIdentityIsolation(t *testing.T) {
	i, o, _ := setup(t)
	apply(t, i, o, 0, stored("root", "child"))
	if h := hint(t, i, o, "tenant-b"); h.Tokens != 0 {
		t.Fatal("cross-salt cache hint", h)
	}
	other := o
	other.Instance = "other-boot"
	if h := hint(t, i, other, "tenant-a"); h.Tokens != 0 {
		t.Fatal(h)
	}
	other = o
	other.Tokenizer = "other-template"
	if err := i.Apply(Batch{Owner: other, Epoch: epochA, Sequence: 1, Source: FixtureSource}); err == nil {
		t.Fatal("wrong template accepted")
	}
	if err := i.Bind(other); err != nil {
		t.Fatal(err)
	}
	if h := hint(t, i, other, "tenant-a"); h.Tokens != 0 {
		t.Fatal("rebind preserved old contents", h)
	}
}
func TestSequenceGapRequiresColdResetAndRootRebuild(t *testing.T) {
	i, o, _ := setup(t)
	apply(t, i, o, 8, stored("root", "child"))
	if err := i.Apply(Batch{Owner: o, Epoch: epochA, Sequence: 10, Source: FixtureSource}); !errors.Is(err, ErrGap) {
		t.Fatal(err)
	}
	if h := hint(t, i, o, "tenant-a"); h.Tokens != 0 || h.State != "desynchronized" {
		t.Fatal(h)
	}
	if err := i.Apply(Batch{Owner: o, Epoch: epochA, Sequence: 9, Source: FixtureSource, Events: []Event{stored("root")}}); !errors.Is(err, ErrGap) {
		t.Fatal("implicitly healed gap", err)
	}
	if err := i.Reset(Reset{Owner: o, PreviousEpoch: epochA, Epoch: epochB}); err != nil {
		t.Fatal(err)
	}
	if err := i.Reset(Reset{Owner: o, Epoch: epochA}); err == nil {
		t.Fatal("late reset reverted current epoch")
	}
	e := stored("child")
	e.Parent = "missing"
	e.Tokens = []int{3, 4}
	e.Salt = ""
	if err := i.Apply(Batch{Owner: o, Epoch: epochB, Sequence: 50, Source: FixtureSource, Events: []Event{e}}); err != nil {
		t.Fatal(err)
	}
	if h := hint(t, i, o, "tenant-a"); h.Tokens != 0 {
		t.Fatal("orphan invented root", h)
	}
	if err := i.Apply(Batch{Owner: o, Epoch: epochB, Sequence: 51, Source: FixtureSource, Events: []Event{stored("root", "child")}}); err != nil {
		t.Fatal(err)
	}
	if h := hint(t, i, o, "tenant-a"); h.Tokens != 4 {
		t.Fatal("cold rebuild failed", h)
	}
}
func TestDuplicateAndStatusReadsDoNotRenewFreshness(t *testing.T) {
	i, o, now := setup(t)
	apply(t, i, o, 3, stored("root"))
	*now = now.Add(2 * time.Second)
	for n := 0; n < 10; n++ {
		apply(t, i, o, 3, stored("root"))
		_ = i.Snapshot()
	}
	if h := hint(t, i, o, "tenant-a"); h.Tokens != 0 || h.State != "stale" {
		t.Fatal(h)
	}
	other := o
	other.Instance = "restarted"
	if err := i.Bind(other); err != nil {
		t.Fatal(err)
	}
	if err := i.Apply(Batch{Owner: o, Epoch: epochA, Sequence: 4, Source: FixtureSource}); err == nil {
		t.Fatal("old boot accepted")
	}
	if h := hint(t, i, other, "tenant-a"); h.Tokens != 0 {
		t.Fatal(h)
	}
}
func TestMalformedAndCapacityOverflowInvalidateWholeBatch(t *testing.T) {
	for _, mode := range []string{"unknown_event", "wrong_block_size", "capacity", "conflicting_hash", "source_change"} {
		t.Run(mode, func(t *testing.T) {
			i, o, _ := setup(t)
			apply(t, i, o, 0, stored("root", "child"))
			e := Event{Type: "future_event"}
			source := FixtureSource
			switch mode {
			case "wrong_block_size":
				e = stored("new")
				e.BlockSize = 4
			case "capacity":
				i.cfg.Capacity = 2
				e = stored("new", "new2")
			case "conflicting_hash":
				e = stored("child")
				e.Tokens = []int{9, 9}
			case "source_change":
				e = Event{Type: "cleared"}
				source = EngineSource
			}
			if err := i.Apply(Batch{Owner: o, Epoch: epochA, Sequence: 1, Source: source, Events: []Event{Event{Type: "removed", Hashes: []string{"root"}}, e}}); err == nil {
				t.Fatal("invalid batch accepted")
			}
			if v := i.Snapshot()[0]; v.Fresh || v.Blocks != 0 {
				t.Fatal("partial index remained valid", v)
			}
		})
	}
}

func TestInvalidFirstBatchRequiresExplicitReset(t *testing.T) {
	i, o, _ := setup(t)
	if err := i.Apply(Batch{Owner: o, Epoch: epochA, Sequence: 1, Source: "unknown-source"}); err == nil {
		t.Fatal("unknown source accepted")
	}
	if err := i.Apply(Batch{Owner: o, Epoch: epochA, Sequence: 2, Source: FixtureSource, Events: []Event{stored("root")}}); !errors.Is(err, ErrGap) {
		t.Fatal("invalid first batch healed without reset", err)
	}
}

func TestConflictingDuplicateCannotPreserveCacheCredit(t *testing.T) {
	i, o, _ := setup(t)
	apply(t, i, o, 3, stored("root"))
	if err := i.Apply(Batch{Owner: o, Epoch: epochA, Sequence: 3, Source: FixtureSource, Events: []Event{{Type: "removed", Hashes: []string{"root"}}}}); err == nil {
		t.Fatal("conflicting payload reused a sequence without invalidation")
	}
	if h := hint(t, i, o, "tenant-a"); h.Tokens != 0 {
		t.Fatal(h)
	}
}

func TestAggregateBoundsAndFixtureLabels(t *testing.T) {
	i, o, _ := setup(t)
	i.cfg.Capacity = 4096
	e := Event{Type: "stored", BlockSize: 2, Tokens: make([]int, 512)}
	for n := 0; n < 256; n++ {
		e.Hashes = append(e.Hashes, fmt.Sprintf("block-%d", n))
	}
	events := make([]Event, 129)
	for n := range events {
		events[n] = e
	}
	if err := i.Apply(Batch{Owner: o, Epoch: epochA, Sequence: 1, Source: FixtureSource, Events: events}); err == nil {
		t.Fatal("aggregate token limit bypassed")
	}
	o.BackendKind = "fixture-no-model"
	if err := i.Bind(o); err != nil {
		t.Fatal(err)
	}
	if err := i.Reset(Reset{Owner: o, Epoch: epochA}); err != nil {
		t.Fatal(err)
	}
	if err := i.Apply(Batch{Owner: o, Epoch: epochA, Sequence: 1, Source: EngineSource, Events: []Event{stored("root")}}); err == nil {
		t.Fatal("fixture was labeled as real vLLM events")
	}
}
func TestConcurrentLookupAndEventApply(t *testing.T) {
	i, o, _ := setup(t)
	var wg sync.WaitGroup
	for n := 0; n < 8; n++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for k := 0; k < 200; k++ {
				_ = hint(t, i, o, "tenant-a")
				_ = i.Snapshot()
			}
		}()
	}
	for n := 0; n < 200; n++ {
		e := stored("root", "child")
		if n%2 == 0 {
			e = Event{Type: "cleared"}
		}
		apply(t, i, o, uint64(n), e)
	}
	wg.Wait()
}
func FuzzBoundedKVBatch(f *testing.F) {
	f.Add([]byte(`{"sequence":1,"events":[{"type":"removed","hashes":["r"]}]}`))
	f.Fuzz(func(t *testing.T, data []byte) {
		if len(data) > 8192 {
			t.Skip()
		}
		var b Batch
		if json.Unmarshal(data, &b) != nil {
			return
		}
		i, o, _ := setup(t)
		b.Owner = o
		b.Epoch = epochA
		b.Source = FixtureSource
		_ = i.Apply(b)
		if i.Snapshot()[0].Blocks > 16 {
			t.Fatal("index capacity bypass")
		}
		_ = hint(t, i, o, "tenant-a")
	})
}
func BenchmarkPrefixLookup(b *testing.B) {
	i, o, _ := setup(b)
	apply(b, i, o, 0, stored("root", "child"))
	p, _ := i.Prepare("tenant-a", []int{1, 2, 3, 4, 5})
	b.ReportAllocs()
	b.ResetTimer()
	for n := 0; n < b.N; n++ {
		if h := i.Lookup(o.Worker, o.Instance, p); h.Tokens != 4 {
			b.Fatal(fmt.Sprint(h))
		}
	}
}
