#!/usr/bin/env python3
"""Build/run real loopback RPC + HTTP + ZMQ processes with NO MODEL/GPU."""
import argparse
import json
import os
import pathlib
import signal
import subprocess
import sys
import tempfile
import time
import urllib.request

def main():
    import msgpack, zmq
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',default=None)
    args=parser.parse_args()
    repo=pathlib.Path(__file__).resolve().parents[1];os.chdir(repo)
    work=pathlib.Path(args.output or tempfile.mkdtemp(prefix='kanarpc-m3-')).resolve();work.mkdir(parents=True,exist_ok=True)
    processes=[];handles=[]
    context=zmq.Context();pub=context.socket(zmq.PUB);pub.setsockopt(zmq.LINGER,0);port=pub.bind_to_random_port('tcp://127.0.0.1')
    def get(url):
        with urllib.request.urlopen(url,timeout=2) as r:return json.load(r)
    def wait(check,seconds=5):
        until=time.monotonic()+seconds
        while time.monotonic()<until:
            value=check()
            if value:return value
            time.sleep(.02)
        raise RuntimeError('fixture condition timed out')
    def launch(name,command):
        out=open(work/(name+'.jsonl'),'w');err=open(work/(name+'.stderr'),'w');handles.extend([out,err])
        p=subprocess.Popen(command,stdout=out,stderr=err);processes.append(p)
        return p
    def ready(name,p):
        def check():
            if p.poll() is not None:raise RuntimeError(name+' exited before ready')
            for line in (work/(name+'.jsonl')).read_text().splitlines():
                try:value=json.loads(line)
                except ValueError:continue
                if value.get('event')=='ready':return value
        return wait(check,15)
    try:
        for name in ['inference-fixture','inference-worker','inference-gateway','inference-check']:
            subprocess.run(['go','build','-o',str(work/name),'./cmd/'+name],check=True,env=dict(os.environ,GOWORK='off'))
        fixture=ready('fixture',launch('fixture',[str(work/'inference-fixture'),'-listen','127.0.0.1:0']))
        workers=[]
        for name in ['a','b']:
            p=launch(name,[str(work/'inference-worker'),'-listen','127.0.0.1:0','-admin-listen','127.0.0.1:0','-upstream','http://'+fixture['address'],'-model','fixture-model','-profile','fixture-serial-v1','-tokenizer','fixture-words-plus-template-v1','-backend-kind','fixture-no-model','-api-key-env','KANARPC_UNUSED_FIXTURE_KEY','-concurrency','4'])
            workers.append(ready(name,p))
        config={'model':'fixture-model','policy':'cache_aware','refresh_interval_ns':20000000,'interactive_ttft_ns':1000000000,'workers':[],'kv':{'index':{'namespace':'fixture-weights-template-layout-v1','block_size':2,'capacity_per_worker':128,'ttl_ns':2000000000},'queue_limit_ns':50000000,'min_gain_ns':1000,'saving_fraction':1}}
        for name,w in zip(['a','b'],workers):
            config['workers'].append({'id':name,'address':w['address'],'admin_url':w['admin_url'],'profile':{'model':'fixture-model','id':'fixture-serial-v1','tokenizer_id':'fixture-words-plus-template-v1','prefill_tokens_per_second':1000,'decode_tokens_per_second':1000,'base_ttft_ns':1000000,'max_in_flight':4}})
        (work/'config.json').write_text(json.dumps(config,indent=2))
        gateway=ready('gateway',launch('gateway',[str(work/'inference-gateway'),'-config',str(work/'config.json'),'-listen','127.0.0.1:0','-admin-listen','127.0.0.1:0']))
        prompt='alpha beta gamma delta epsilon zeta eta theta'
        common=[str(work/'inference-check'),'-address',gateway['address'],'-model','fixture-model','-scheduled','-prompt',prompt,'-cache-salt','tenant-a','-timeout','5s']
        results={}
        def check(name,*extra):
            result=subprocess.run(common+list(extra),check=True,capture_output=True,text=True,timeout=7)
            value=json.loads(result.stdout);results[name]=value;(work/(name+'.json')).write_text(json.dumps(value,indent=2));return value
        cold=check('cold');assert cold['decision'].get('estimated_reusable_tokens',0)==0
        bridge_command=[sys.executable,'scripts/kv_event_bridge.py','--endpoint','tcp://127.0.0.1:'+str(port),'--gateway',gateway['admin_url'],'--worker-admin',workers[1]['admin_url'],'--worker','b','--namespace',config['kv']['index']['namespace'],'--block-size','2','--layout','full-attention-single-group','--source','fixture-events-no-model']
        bridge=launch('bridge',bridge_command)
        ready('bridge',bridge)
        request=urllib.request.Request(workers[1]['admin_url']+'/tokenize?include_tokens=1',data=json.dumps({'messages':[{'role':'user','content':prompt}],'max_tokens':16}).encode(),headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(request,timeout=2) as r:tokens=json.load(r)['tokens']
        blocks=(len(tokens)-1)//2
        stored={'type':'BlockStored','block_hashes':list(range(1,blocks+1)),'parent_block_hash':None,'token_ids':tokens[:2*blocks],'block_size':2,'medium':'GPU','lora_id':None,'lora_name':None,'group_idx':0,'extra_keys':[['tenant-a']]+[None]*(blocks-1)}
        def publish(sequence,events):pub.send_multipart([b'',sequence.to_bytes(8,'big'),msgpack.packb([time.time(),events,0],use_bin_type=True)])
        def view():return next(x for x in get(gateway['admin_url']+'/kv/status') if x['worker']=='b')
        # PUB/SUB subscription is asynchronous. Retry an identical sequence;
        # duplicates cannot make a stale entry fresh in the receiver.
        wait(lambda:(publish(0,[stored]) or (view()['blocks']==blocks)),5)
        warm=check('warm');assert warm['decision']['worker_id']=='b' and warm['decision']['estimated_reusable_tokens']==blocks*2
        assert warm['decision']['cache_evidence']=='fixture-events-no-model'
        assert 'prompt_tokens_details' not in warm['usage'] # hints never fabricated as actual engine hits
        cross=check('different-salt','-cache-salt','tenant-b');assert cross['decision'].get('estimated_reusable_tokens',0)==0
        busy=launch('busy',[str(work/'inference-check'),'-address',workers[1]['address'],'-model','fixture-model','-max-tokens','200','-timeout','5s'])
        wait(lambda:get(workers[1]['admin_url']+'/status')['active'])
        wait(lambda:next(x for x in get(gateway['admin_url']+'/status')['workers'] if x['id']=='b')['in_flight']==1)
        shifted=check('saturated-transfer');assert shifted['decision']['worker_id']=='a' and shifted['decision']['routing_reason']=='cache_queue_limit'
        assert busy.wait(timeout=5)==0
        previous=view()['epoch'];publish(2,[]);wait(lambda:view()['epoch']!=previous and view()['blocks']==0)
        assert check('event-gap')['decision'].get('estimated_reusable_tokens',0)==0
        publish(3,[stored]);wait(lambda:view()['blocks']==blocks)
        assert check('rebuilt')['decision']['estimated_reusable_tokens']==blocks*2
        publish(4,[{'type':'BlockRemoved','block_hashes':[1],'medium':'GPU','group_idx':0}]);wait(lambda:view()['sequence']==4)
        assert check('evicted-root')['decision'].get('estimated_reusable_tokens',0)==0
        previous=view()['epoch'];publish(5,[{'type':'UnsupportedNewLayout'}]);wait(lambda:view()['epoch']!=previous and view()['blocks']==0)
        assert check('unsupported-event')['decision'].get('estimated_reusable_tokens',0)==0
        publish(6,[stored]);wait(lambda:view()['blocks']==blocks)
        wait(lambda:view()['state']=='stale',4)
        assert check('expired')['decision'].get('estimated_reusable_tokens',0)==0
        publish(7,[stored]);wait(lambda:view()['fresh'])
        assert check('cancel','-cancel-after-first')['terminal']=='canceled'
        def drained():
            status=get(gateway['admin_url']+'/status')
            return all(w['local_reservations']==0 for w in status['workers']) and status['admission']['interactive']['running']==0 and all(not get(w['admin_url']+'/status')['active'] for w in workers)
        wait(drained)
        previous=view()['epoch']
        newer=launch('bridge-new',bridge_command);ready('bridge-new',newer)
        wait(lambda:(publish(8,[stored]) or (view()['epoch']!=previous and view()['blocks']==blocks)),5)
        new_epoch=view()['epoch']
        publish(9,[])
        wait(lambda:bridge.poll() is not None)
        assert view()['epoch']==new_epoch and view()['blocks']==blocks
        results['bridge-handoff-fencing']={'old_bridge_exit':bridge.returncode,'new_epoch_preserved':True}
        (work/'bridge-handoff-fencing.json').write_text(json.dumps(results['bridge-handoff-fencing'],indent=2))
        (work/'final.json').write_text(json.dumps(get(gateway['admin_url']+'/status'),indent=2))
        summary={'status':'PASS','evidence':'loopback-tcp-http-zmq-fixture-no-model','checks':list(results),'warning':'No model/GPU used; cache hints and timer delays are not real inference hits or gains.'}
        (work/'result.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))
    finally:
        for p in reversed(processes):
            if p.poll() is None:p.send_signal(signal.SIGTERM)
            try:p.wait(timeout=7)
            except subprocess.TimeoutExpired:p.kill();p.wait()
        for handle in handles:handle.close()
        pub.close(0);context.term()

if __name__=='__main__':main()
