package scheduler

import (
	"context"
	"errors"
	"sync"
	"time"
)

type Class string

const (
	Interactive Class = "interactive"
	Batch       Class = "batch"
)

type ClassLimit struct {
	Running       int `json:"running"`
	RunningTokens int `json:"running_tokens"`
	Queued        int `json:"queued"`
	QueuedTokens  int `json:"queued_tokens"`
}
type AdmissionConfig struct {
	Interactive ClassLimit `json:"interactive"`
	Batch       ClassLimit `json:"batch"`
	// SharedFIFO is an explicit comparison/control policy. Default is isolation.
	SharedFIFO bool `json:"shared_fifo"`
}
type admissionBucket struct {
	limit                         ClassLimit
	running, tokens, queuedTokens int
	queue                         []*waiter
}
type Admission struct {
	mu                                               sync.Mutex
	interactive, batch                               *admissionBucket
	closed                                           bool
	accepted, rejected, expired, canceled, completed uint64
}
type waiter struct {
	ctx            context.Context
	class          Class
	work           Work
	until, entered time.Time
	ready          chan grant
	permit         *Permit
	queued         bool
}
type grant struct {
	permit *Permit
	err    error
}
type Permit struct {
	owner     *Admission
	bucket    *admissionBucket
	work      Work
	once      sync.Once
	QueueWait time.Duration
}

func NewAdmission(cfg AdmissionConfig) (*Admission, error) {
	valid := func(l ClassLimit) bool {
		return l.Running >= 1 && l.Running <= 256 && l.RunningTokens >= 1 && l.RunningTokens <= 1<<28 && l.Queued >= 1 && l.Queued <= 1024 && l.QueuedTokens >= 1 && l.QueuedTokens <= 1<<29
	}
	if !valid(cfg.Interactive) || !valid(cfg.Batch) {
		return nil, errors.New("invalid bounded class limits")
	}
	a := &Admission{interactive: &admissionBucket{limit: cfg.Interactive}, batch: &admissionBucket{limit: cfg.Batch}}
	if cfg.SharedFIFO {
		i, b := cfg.Interactive, cfg.Batch
		shared := &admissionBucket{limit: ClassLimit{i.Running + b.Running, i.RunningTokens + b.RunningTokens, i.Queued + b.Queued, i.QueuedTokens + b.QueuedTokens}}
		a.interactive, a.batch = shared, shared
	}
	return a, nil
}
func (a *Admission) bucket(class Class) *admissionBucket {
	if class == Interactive {
		return a.interactive
	}
	return a.batch
}
func (a *Admission) Acquire(ctx context.Context, class Class, work Work, until time.Time) (*Permit, error) {
	if class != Interactive && class != Batch || !work.Valid() || until.IsZero() {
		return nil, &Error{Code: "invalid_argument", Message: "class, work and queue deadline required"}
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	w := &waiter{ctx: ctx, class: class, work: work, until: until, entered: time.Now(), ready: make(chan grant, 1), queued: true}
	a.mu.Lock()
	if a.closed {
		a.mu.Unlock()
		return nil, &Error{Code: "unavailable", Message: "admission closed"}
	}
	b := a.bucket(class)
	a.dispatch(b, time.Now())
	if work.Tokens() > b.limit.RunningTokens {
		a.rejected++
		a.mu.Unlock()
		return nil, &Error{Code: "resource_exhausted", Message: "request exceeds class token reservation"}
	}
	if !time.Now().Before(until) {
		a.expired++
		a.mu.Unlock()
		return nil, &Error{Code: "queue_timeout", Message: "queue budget exhausted"}
	}
	// If dispatch is immediately possible, a full waiting quota does not apply.
	immediate := len(b.queue) == 0 && b.running < b.limit.Running && b.tokens+work.Tokens() <= b.limit.RunningTokens
	if !immediate && (len(b.queue) >= b.limit.Queued || b.queuedTokens+work.Tokens() > b.limit.QueuedTokens) {
		a.rejected++
		a.mu.Unlock()
		return nil, &Error{Code: "resource_exhausted", Message: "class queue capacity reached"}
	}
	b.queue = append(b.queue, w)
	b.queuedTokens += work.Tokens()
	a.dispatch(b, time.Now())
	a.mu.Unlock()
	timer := time.NewTimer(time.Until(until))
	defer timer.Stop()
	select {
	case result := <-w.ready:
		if result.permit != nil && ctx.Err() != nil {
			result.permit.Release()
			return nil, ctx.Err()
		}
		if result.permit != nil && !time.Now().Before(until) {
			result.permit.Release()
			return nil, &Error{Code: "queue_timeout", Message: "queue budget exhausted before caller resumed"}
		}
		return result.permit, result.err
	case <-ctx.Done():
		a.withdraw(w, ctx.Err(), false)
		return nil, ctx.Err()
	case <-timer.C:
		err := &Error{Code: "queue_timeout", Message: "queue budget exhausted"}
		a.withdraw(w, err, true)
		return nil, err
	}
}
func (a *Admission) withdraw(w *waiter, err error, expired bool) {
	a.mu.Lock()
	b := a.bucket(w.class)
	if w.queued {
		for i, entry := range b.queue {
			if entry == w {
				b.queue = append(b.queue[:i], b.queue[i+1:]...)
				b.queuedTokens -= w.work.Tokens()
				break
			}
		}
		w.queued = false
		if expired {
			a.expired++
		} else {
			a.canceled++
		}
		a.dispatch(b, time.Now())
	}
	permit := w.permit
	a.mu.Unlock()
	// A grant racing the cancellation is returned even when the caller never
	// observes its ready channel. No execution slot or token reservation leaks.
	if permit != nil {
		permit.Release()
	}
}
func (a *Admission) dispatch(b *admissionBucket, now time.Time) {
	kept := b.queue[:0]
	for _, w := range b.queue {
		var err error
		if w.ctx.Err() != nil {
			err = w.ctx.Err()
			a.canceled++
		} else if !now.Before(w.until) {
			err = &Error{Code: "queue_timeout", Message: "queue budget exhausted"}
			a.expired++
		}
		if err != nil {
			w.queued = false
			b.queuedTokens -= w.work.Tokens()
			w.ready <- grant{err: err}
		} else {
			kept = append(kept, w)
		}
	}
	for i := len(kept); i < len(b.queue); i++ {
		b.queue[i] = nil
	}
	b.queue = kept
	for len(b.queue) > 0 && !a.closed {
		w := b.queue[0]
		if b.running >= b.limit.Running || b.tokens+w.work.Tokens() > b.limit.RunningTokens {
			return
		}
		b.queue[0] = nil
		b.queue = b.queue[1:]
		b.queuedTokens -= w.work.Tokens()
		w.queued = false
		b.running++
		b.tokens += w.work.Tokens()
		a.accepted++
		p := &Permit{owner: a, bucket: b, work: w.work, QueueWait: now.Sub(w.entered)}
		w.permit = p
		w.ready <- grant{permit: p}
	}
}
func (p *Permit) Release() {
	p.once.Do(func() {
		a := p.owner
		a.mu.Lock()
		defer a.mu.Unlock()
		p.bucket.running--
		p.bucket.tokens -= p.work.Tokens()
		a.completed++
		a.dispatch(p.bucket, time.Now())
	})
}

type BucketView struct {
	Running       int `json:"running"`
	RunningTokens int `json:"running_tokens"`
	Queued        int `json:"queued"`
	QueuedTokens  int `json:"queued_tokens"`
}
type AdmissionView struct {
	Interactive BucketView `json:"interactive"`
	Batch       BucketView `json:"batch"`
	Shared      bool       `json:"shared"`
	Accepted    uint64     `json:"accepted"`
	Rejected    uint64     `json:"rejected"`
	Expired     uint64     `json:"expired"`
	Canceled    uint64     `json:"canceled"`
	Completed   uint64     `json:"completed"`
}

func (a *Admission) Snapshot() AdmissionView {
	a.mu.Lock()
	defer a.mu.Unlock()
	view := func(b *admissionBucket) BucketView {
		return BucketView{b.running, b.tokens, len(b.queue), b.queuedTokens}
	}
	return AdmissionView{view(a.interactive), view(a.batch), a.interactive == a.batch, a.accepted, a.rejected, a.expired, a.canceled, a.completed}
}
func (a *Admission) Close() {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.closed {
		return
	}
	a.closed = true
	for _, b := range []*admissionBucket{a.interactive, a.batch} {
		for _, w := range b.queue {
			w.queued = false
			w.ready <- grant{err: &Error{Code: "unavailable", Message: "admission closed"}}
		}
		b.queue = nil
		b.queuedTokens = 0
	}
}
