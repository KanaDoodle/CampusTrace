package scheduler

import (
	"fmt"
	"sync"
	"testing"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/inference/kvcache"
)

func cacheRouter(t *testing.T, policy Policy, queueLimit time.Duration) (*Router, *kvcache.Index, *kvcache.Prefix, *time.Time) {
	t.Helper()
	now := time.Unix(100, 0)
	index, err := kvcache.New(kvcache.Config{Namespace: "m-t-full-attention", BlockSize: 2, Capacity: 128, TTL: time.Second, Now: func() time.Time { return now }})
	if err != nil {
		t.Fatal(err)
	}
	r, err := NewRouter(RouterConfig{Workers: testWorkers(), Policy: policy, StaleAfter: time.Minute, Cache: index, CacheQueueLimit: queueLimit, MinCacheGain: time.Microsecond, Now: func() time.Time { return now }})
	if err != nil {
		t.Fatal(err)
	}
	for _, w := range testWorkers() {
		if err := r.Observe(w.ID, testStatus()); err != nil {
			t.Fatal(err)
		}
	}
	owner := kvcache.Owner{Worker: "b", Instance: "boot", Model: "m", Profile: "p", Tokenizer: "t", Namespace: index.Namespace()}
	epoch := "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	if err := index.Reset(kvcache.Reset{Owner: owner, Epoch: epoch}); err != nil {
		t.Fatal(err)
	}
	if err := index.Apply(kvcache.Batch{Owner: owner, Epoch: epoch, Source: kvcache.FixtureSource, Sequence: 0, Events: []kvcache.Event{{Type: "stored", Hashes: []string{"one", "two", "three", "four"}, Tokens: []int{1, 2, 3, 4, 5, 6, 7, 8}, BlockSize: 2, Salt: "tenant"}}}); err != nil {
		t.Fatal(err)
	}
	prefix, _ := index.Prepare("tenant", []int{1, 2, 3, 4, 5, 6, 7, 8, 9})
	return r, index, prefix, &now
}
func TestCacheAwareChoosesFreshPrefixAndTransfersBeforeDispatch(t *testing.T) {
	for _, policy := range []Policy{TokenWork, CacheAffinity, CacheAware} {
		t.Run(string(policy), func(t *testing.T) {
			r, _, p, _ := cacheRouter(t, policy, 50*time.Millisecond)
			res, err := r.ReserveWithPrefix("cold", Work{9, 10}, time.Second, p)
			if err != nil {
				t.Fatal(err)
			}
			want := "b"
			if policy == TokenWork {
				want = "a"
			}
			if res.Decision.WorkerID != want {
				t.Fatal(res.Decision)
			}
			res.Done()
			_ = r.Observe("b", testStatus(Invocation{ID: "long", Work: Work{400, 100}}))
			res, err = r.ReserveWithPrefix("hot", Work{9, 10}, time.Second, p)
			if err != nil {
				t.Fatal(err)
			}
			defer res.Done()
			want = "a"
			if policy == CacheAffinity {
				want = "b"
			}
			if res.Decision.WorkerID != want {
				t.Fatal(res.Decision)
			}
			if policy == CacheAware && res.Decision.RoutingReason != "cache_queue_limit" {
				t.Fatal(res.Decision)
			}
		})
	}
}
func TestCacheQueueCostComparedWithSavings(t *testing.T) {
	r, _, p, _ := cacheRouter(t, CacheAware, 2*time.Second)
	_ = r.Observe("b", testStatus(Invocation{ID: "long", Work: Work{10, 20}}))
	res, err := r.ReserveWithPrefix("call", Work{9, 10}, time.Second, p)
	if err != nil {
		t.Fatal(err)
	}
	defer res.Done()
	if res.Decision.WorkerID != "a" || res.Decision.RoutingReason != "queue_cost_exceeds_cache_saving" {
		t.Fatal(res.Decision)
	}
}
func TestCacheHintNeverDiscountsAdmissionAndFullWorkerIsExcluded(t *testing.T) {
	r, _, p, _ := cacheRouter(t, CacheAware, time.Second)
	if _, err := r.ReserveWithPrefix("too-short", Work{9, 10}, 2*time.Millisecond, p); err == nil {
		t.Fatal("cache optimism bypassed cold SLO gate")
	}
	status := testStatus()
	for n := 0; n < 8; n++ {
		status.Active = append(status.Active, Invocation{ID: fmt.Sprint(n), Work: Work{1, 1}})
	}
	_ = r.Observe("b", status)
	res, err := r.ReserveWithPrefix("full", Work{9, 10}, time.Second, p)
	if err != nil {
		t.Fatal(err)
	}
	defer res.Done()
	if res.Decision.WorkerID != "a" || res.Decision.RoutingReason != "cache_capacity_or_slo" {
		t.Fatal(res.Decision)
	}
}
func TestStaleIndexAndUnavailableTokenIDsFallBackToLoad(t *testing.T) {
	r, _, p, now := cacheRouter(t, CacheAware, time.Second)
	*now = now.Add(2 * time.Second)
	res, err := r.ReserveWithPrefix("stale", Work{9, 10}, time.Second, p)
	if err != nil {
		t.Fatal(err)
	}
	if res.Decision.WorkerID != "a" || res.Decision.EstimatedReusableTokens != 0 || res.Decision.RoutingReason != "load_no_fresh_prefix" {
		t.Fatal(res.Decision)
	}
	res.Done()
	res, err = r.Reserve("no-tokens", Work{9, 10}, time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer res.Done()
	if res.Decision.RoutingReason != "load_no_token_ids" {
		t.Fatal(res.Decision)
	}
}
func TestConcurrentCachePlacementStillUsesAtomicReservations(t *testing.T) {
	r, _, p, _ := cacheRouter(t, CacheAware, time.Second)
	var wg sync.WaitGroup
	held := make(chan *Reservation, 64)
	for n := 0; n < 64; n++ {
		wg.Add(1)
		go func(n int) {
			defer wg.Done()
			if res, err := r.ReserveWithPrefix(fmt.Sprint(n), Work{9, 10}, time.Second, p); err == nil {
				held <- res
			}
		}(n)
	}
	wg.Wait()
	close(held)
	total := 0
	for _, v := range r.Snapshot() {
		total += v.LocalReservations
		if v.LocalReservations > 8 {
			t.Fatal(v)
		}
	}
	if total != 16 {
		t.Fatal(total)
	}
	for res := range held {
		res.Done()
	}
	for _, v := range r.Snapshot() {
		if v.LocalReservations != 0 {
			t.Fatal(v)
		}
	}
}

func TestMissingHintsPreserveTokenWorkChoiceUnderHeterogeneousLoad(t *testing.T) {
	r, _, _, _ := cacheRouter(t, CacheAware, 50*time.Millisecond)
	r.byID["b"].worker.Profile.PrefillTokensPerSecond = 1
	_ = r.Observe("a", testStatus(Invocation{ID: "decode", Work: Work{1, 200}, FirstText: true}))
	res, err := r.Reserve("no-tokens", Work{9, 10}, 20*time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer res.Done()
	if res.Decision.WorkerID != "a" || res.Decision.RoutingReason != "load_no_token_ids" {
		t.Fatal("cache queue cap changed load-only fallback", res.Decision)
	}
}
