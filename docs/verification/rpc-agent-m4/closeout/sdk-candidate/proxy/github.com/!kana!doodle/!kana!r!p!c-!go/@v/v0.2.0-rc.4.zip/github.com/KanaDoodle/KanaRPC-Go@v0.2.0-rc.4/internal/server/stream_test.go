package server

import (
	"context"
	"net"
	"testing"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/internal/protocol"
	"github.com/KanaDoodle/KanaRPC-Go/internal/transport"
)

type dataWriteBarrier struct {
	net.Conn
	writes      int
	dataWriting chan struct{}
}

func (c *dataWriteBarrier) Write(body []byte) (int, error) {
	c.writes++
	if c.writes == 2 {
		close(c.dataWriting)
	} // ACCEPT precedes the first DATA
	return c.Conn.Write(body)
}

func TestCancelDuringFrameWriteDoesNotCorruptSharedStream(t *testing.T) {
	s, err := NewServer("127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer s.Close()
	canceled := make(chan struct{})
	if err := s.RegisterStream("test", "Wait", func(ctx context.Context, _ []byte, send func([]byte) error) error {
		stop := context.AfterFunc(ctx, func() { close(canceled) })
		defer stop()
		return send([]byte(`"data"`))
	}); err != nil {
		t.Fatal(err)
	}
	local, remote := net.Pipe()
	observed := &dataWriteBarrier{Conn: local, dataWriting: make(chan struct{})}
	peer := transport.NewTCPConnection(remote)
	done := make(chan struct{})
	go func() { s.Handle(transport.NewTCPConnection(observed)); close(done) }()
	defer func() { _ = peer.Close(); <-done }()
	if err := peer.Write(&protocol.Message{Header: &protocol.Header{RequestID: 1, Version: 1, Kind: protocol.StreamOpen, ServiceName: "test", MethodName: "Wait", Window: 1, TimeoutNanos: int64(time.Second)}, Body: []byte(`{}`)}); err != nil {
		t.Fatal(err)
	}
	if msg, err := peer.Read(); err != nil || msg.Header.Kind != protocol.StreamAccept {
		t.Fatal(msg, err)
	}
	<-observed.dataWriting
	// No peer read is active: the DATA frame cannot finish its socket write.
	if err := peer.Write(&protocol.Message{Header: &protocol.Header{RequestID: 1, Version: 1, Kind: protocol.StreamCancel}}); err != nil {
		t.Fatal(err)
	}
	select {
	case <-canceled:
	case <-time.After(time.Second):
		t.Fatal("cancel control was blocked by data write")
	}
	if msg, err := peer.Read(); err != nil || msg.Header.Kind != protocol.StreamData {
		t.Fatal("cancellation interrupted a frame", msg, err)
	}
	if msg, err := peer.Read(); err != nil || msg.Header.Kind != protocol.StreamEnd || msg.Header.Code != "canceled" {
		t.Fatal(msg, err)
	}
	if err := peer.Write(&protocol.Message{Header: &protocol.Header{RequestID: 2, Version: 1, Kind: protocol.StreamHello}}); err != nil {
		t.Fatal(err)
	}
	if msg, err := peer.Read(); err != nil || msg.Header.Kind != protocol.StreamHelloAck {
		t.Fatal(msg, err)
	}
}
