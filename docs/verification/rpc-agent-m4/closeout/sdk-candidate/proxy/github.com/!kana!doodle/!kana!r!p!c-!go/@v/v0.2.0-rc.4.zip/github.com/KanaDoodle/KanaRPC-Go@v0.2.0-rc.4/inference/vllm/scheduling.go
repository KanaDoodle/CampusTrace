package vllm

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"sort"
	"strings"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/inference/scheduler"
	"github.com/KanaDoodle/KanaRPC-Go/rpc"
)

type SchedulingConfig struct {
	ProfileID   string
	TokenizerID string
	BackendKind string
	MaxTracked  int
}
type activeState struct {
	invocation        scheduler.Invocation
	started, lastText time.Time
}
type runtimeStats struct {
	instance                    string
	revision, completed, failed uint64
	active                      map[string]*activeState
	ttft, gap                   time.Duration
	lastPrompt, lastOutput      int
}

func (a *Adapter) initScheduling(cfg *SchedulingConfig) error {
	if cfg == nil {
		return nil
	}
	copyConfig := *cfg
	if copyConfig.MaxTracked == 0 {
		copyConfig.MaxTracked = 256
	}
	if copyConfig.ProfileID == "" || copyConfig.TokenizerID == "" || copyConfig.MaxTracked < 1 || copyConfig.MaxTracked > 256 {
		return errors.New("invalid scheduling profile or tracking limit")
	}
	if copyConfig.BackendKind == "" {
		copyConfig.BackendKind = "configured-upstream"
	}
	id, err := NewInvocationID()
	if err != nil {
		return err
	}
	a.scheduling = &copyConfig
	a.stats = runtimeStats{instance: id, active: make(map[string]*activeState)}
	return nil
}
func NewInvocationID() (string, error) {
	var value [16]byte
	if _, err := rand.Read(value[:]); err != nil {
		return "", err
	}
	return hex.EncodeToString(value[:]), nil
}

// Tokenize includes the configured chat template and generation prompt at the
// upstream. There is deliberately no hidden character-count fallback.
func (a *Adapter) Tokenize(ctx context.Context, request ChatRequest) (int, error) {
	result, err := a.tokenize(ctx, request, false)
	return result.Count, err
}

type Tokenization struct {
	Count         int    `json:"count"`
	Tokens        []int  `json:"tokens,omitempty"`
	TokenIDsState string `json:"token_ids_state,omitempty"`
}

// TokenizeDetails returns upstream IDs only when complete and valid. Missing
// IDs disable cache hints, while a valid upstream count remains usable by M2.
func (a *Adapter) TokenizeDetails(ctx context.Context, request ChatRequest) (Tokenization, error) {
	return a.tokenize(ctx, request, true)
}

func (a *Adapter) tokenize(ctx context.Context, request ChatRequest, includeTokens bool) (Tokenization, error) {
	if err := ValidateRequest(&request); err != nil {
		return Tokenization{}, err
	}
	select {
	case a.tokenizerSlots <- struct{}{}:
	case <-ctx.Done():
		return Tokenization{}, ctx.Err()
	}
	defer func() { <-a.tokenizerSlots }()
	body, err := json.Marshal(struct {
		Model               string    `json:"model"`
		Messages            []Message `json:"messages"`
		AddGenerationPrompt bool      `json:"add_generation_prompt"`
	}{a.model, request.Messages, true})
	if err != nil {
		return Tokenization{}, err
	}
	response, err := a.doURL(ctx, http.MethodPost, strings.TrimSuffix(a.baseURL, "/v1")+"/tokenize", bytes.NewReader(body))
	if err != nil {
		return Tokenization{}, err
	}
	defer response.Body.Close()
	data, err := io.ReadAll(io.LimitReader(response.Body, (8<<20)+1))
	if err != nil {
		return Tokenization{}, err
	}
	if len(data) > 8<<20 {
		return Tokenization{}, errors.New("tokenization response too large")
	}
	var result struct {
		Count  int             `json:"count"`
		Tokens json.RawMessage `json:"tokens"`
	}
	if err := json.Unmarshal(data, &result); err != nil || result.Count < 1 || result.Count > 1<<20 {
		return Tokenization{}, errors.New("invalid tokenizer count")
	}
	details := Tokenization{Count: result.Count}
	if includeTokens {
		details.TokenIDsState = "unavailable"
		if len(result.Tokens) > 0 && string(result.Tokens) != "null" {
			var ids []int
			valid := json.Unmarshal(result.Tokens, &ids) == nil && len(ids) == result.Count
			for _, id := range ids {
				valid = valid && id >= 0 && int64(id) <= 1<<31-1
			}
			if valid {
				if len(ids) > 65536 {
					details.TokenIDsState = "too_large"
				} else {
					details.Tokens = ids
					details.TokenIDsState = "available"
				}
			} else {
				details.TokenIDsState = "invalid"
			}
		}
	}
	return details, nil
}

func (a *Adapter) begin(request ChatRequest, prompt int) (string, error) {
	id := request.InvocationID
	if id == "" {
		var err error
		id, err = NewInvocationID()
		if err != nil {
			return "", err
		}
	}
	if len(id) != 32 {
		return "", &rpc.StatusError{Code: "invalid_argument", Message: "invocation id must be 16-byte hex"}
	}
	if _, err := hex.DecodeString(id); err != nil {
		return "", &rpc.StatusError{Code: "invalid_argument", Message: "invocation id must be hex"}
	}
	a.statsMu.Lock()
	defer a.statsMu.Unlock()
	if len(a.stats.active) >= a.scheduling.MaxTracked {
		return "", &rpc.StatusError{Code: "resource_exhausted", Message: "worker tracking capacity reached"}
	}
	if a.stats.active[id] != nil {
		return "", &rpc.StatusError{Code: "invalid_argument", Message: "duplicate active invocation id"}
	}
	a.stats.active[id] = &activeState{invocation: scheduler.Invocation{ID: id, Work: scheduler.Work{PromptTokens: prompt, OutputTokens: request.MaxTokens}}, started: time.Now()}
	a.stats.revision++
	return id, nil
}
func ewma(old, next time.Duration) time.Duration {
	if old == 0 {
		return next
	}
	return old + (next-old)/5
}
func (a *Adapter) text(id string) {
	a.statsMu.Lock()
	defer a.statsMu.Unlock()
	entry := a.stats.active[id]
	if entry == nil {
		return
	}
	now := time.Now()
	if !entry.invocation.FirstText {
		entry.invocation.FirstText = true
		a.stats.ttft = ewma(a.stats.ttft, now.Sub(entry.started))
	} else {
		a.stats.gap = ewma(a.stats.gap, now.Sub(entry.lastText))
	}
	entry.lastText = now
	a.stats.revision++
}
func (a *Adapter) end(id string, err error, usage *Usage) {
	a.statsMu.Lock()
	defer a.statsMu.Unlock()
	delete(a.stats.active, id)
	a.stats.revision++
	if err == nil {
		a.stats.completed++
	} else {
		a.stats.failed++
	}
	if usage != nil {
		a.stats.lastPrompt, a.stats.lastOutput = usage.PromptTokens, usage.CompletionTokens
	}
}

func (a *Adapter) Status() scheduler.WorkerStatus {
	a.statsMu.Lock()
	defer a.statsMu.Unlock()
	status := scheduler.WorkerStatus{Model: a.model, InstanceID: a.stats.instance, Revision: a.stats.revision, Ready: a.scheduling != nil, Completed: a.stats.completed, Failed: a.stats.failed, TTFTEWMA: a.stats.ttft, GapEWMA: a.stats.gap, LastUsagePromptTokens: a.stats.lastPrompt, LastUsageOutputTokens: a.stats.lastOutput}
	if a.scheduling != nil {
		status.ProfileID = a.scheduling.ProfileID
		status.TokenizerID = a.scheduling.TokenizerID
		status.BackendKind = a.scheduling.BackendKind
		status.TokenSource = "upstream_tokenizer_api"
	}
	for _, entry := range a.stats.active {
		status.Active = append(status.Active, entry.invocation)
		if !entry.invocation.FirstText {
			status.WaitingForFirstText++
		}
	}
	sort.Slice(status.Active, func(i, j int) bool { return status.Active[i].ID < status.Active[j].ID })
	return status
}

// AdminHandler is a separate control listener. GET status remains readable when
// business RPC execution is full. Deploy it on a trusted/private interface.
func (a *Adapter) AdminHandler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /status", func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), time.Second)
		defer cancel()
		status := a.Status()
		if status.Ready {
			models, err := a.Models(ctx)
			found := false
			for _, id := range models {
				if id == a.model {
					found = true
				}
			}
			status.Ready = err == nil && found
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(status)
	})
	mux.HandleFunc("POST /tokenize", func(w http.ResponseWriter, r *http.Request) {
		if a.scheduling == nil {
			http.Error(w, "scheduling disabled", http.StatusServiceUnavailable)
			return
		}
		ctx, cancel := context.WithTimeout(r.Context(), 2*time.Second)
		defer cancel()
		var request ChatRequest
		decoder := json.NewDecoder(http.MaxBytesReader(w, r.Body, MaxPromptBytes+(16<<10)))
		decoder.DisallowUnknownFields()
		if err := decoder.Decode(&request); err != nil {
			http.Error(w, "invalid request", 400)
			return
		}
		details, err := a.tokenize(ctx, request, r.URL.Query().Get("include_tokens") == "1")
		if err != nil {
			http.Error(w, "tokenizer unavailable or request invalid", 503)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]any{"count": details.Count, "tokens": details.Tokens, "token_ids_state": details.TokenIDsState, "model": a.model, "profile_id": a.scheduling.ProfileID, "tokenizer_id": a.scheduling.TokenizerID, "source": "upstream_tokenizer_api"})
	})
	return mux
}
