package scheduler

import (
	"context"
	"errors"
	"sync"
	"testing"
	"time"
)

func testLimits() AdmissionConfig {
	return AdmissionConfig{Interactive: ClassLimit{1, 100, 2, 100}, Batch: ClassLimit{1, 100, 2, 100}}
}
func testAdmission(t *testing.T, cfg AdmissionConfig) *Admission {
	t.Helper()
	a, e := NewAdmission(cfg)
	if e != nil {
		t.Fatal(e)
	}
	t.Cleanup(a.Close)
	return a
}
func waitQueue(t *testing.T, a *Admission, class Class, count int) {
	t.Helper()
	until := time.Now().Add(time.Second)
	for time.Now().Before(until) {
		v := a.Snapshot()
		b := v.Batch
		if class == Interactive {
			b = v.Interactive
		}
		if b.Queued == count {
			return
		}
		time.Sleep(time.Millisecond)
	}
	t.Fatal("queue did not reach state", a.Snapshot())
}
func acquire(t *testing.T, a *Admission, c Class) *Permit {
	t.Helper()
	p, e := a.Acquire(context.Background(), c, Work{10, 10}, time.Now().Add(time.Second))
	if e != nil {
		t.Fatal(e)
	}
	return p
}

func TestClassIsolationComparedWithSharedFIFO(t *testing.T) {
	for _, shared := range []bool{false, true} {
		t.Run(map[bool]string{false: "isolated", true: "shared_fifo"}[shared], func(t *testing.T) {
			cfg := testLimits()
			cfg.SharedFIFO = shared
			a := testAdmission(t, cfg)
			first := acquire(t, a, Batch)
			defer first.Release()
			var second *Permit
			if shared {
				second = acquire(t, a, Batch)
				defer second.Release()
			}
			ctx, cancel := context.WithTimeout(context.Background(), 40*time.Millisecond)
			defer cancel()
			p, e := a.Acquire(ctx, Interactive, Work{10, 10}, time.Now().Add(time.Second))
			if shared {
				if !errors.Is(e, context.DeadlineExceeded) {
					t.Fatal(e)
				}
			} else {
				if e != nil {
					t.Fatal(e)
				}
				p.Release()
			}
		})
	}
}
func TestAdmissionFIFOAndBatchProgress(t *testing.T) {
	a := testAdmission(t, testLimits())
	held := acquire(t, a, Batch)
	granted := make(chan int, 2)
	release := make(chan struct{})
	var wg sync.WaitGroup
	for i := 0; i < 2; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			p, e := a.Acquire(context.Background(), Batch, Work{10, 10}, time.Now().Add(2*time.Second))
			if e != nil {
				t.Error(e)
				return
			}
			granted <- i
			<-release
			p.Release()
		}(i)
		waitQueue(t, a, Batch, i+1)
	}
	for i := 0; i < 20; i++ {
		p := acquire(t, a, Interactive)
		p.Release()
	}
	held.Release()
	if got := <-granted; got != 0 {
		t.Fatal("FIFO violated", got)
	}
	close(release)
	if got := <-granted; got != 1 {
		t.Fatal("batch did not progress", got)
	}
	wg.Wait()
}
func TestQueueCountsTokensAndExpiryPreventExecution(t *testing.T) {
	a := testAdmission(t, testLimits())
	held := acquire(t, a, Interactive)
	result := make(chan error, 1)
	go func() {
		p, e := a.Acquire(context.Background(), Interactive, Work{40, 40}, time.Now().Add(40*time.Millisecond))
		if p != nil {
			p.Release()
		}
		result <- e
	}()
	waitQueue(t, a, Interactive, 1)
	_, e := a.Acquire(context.Background(), Interactive, Work{20, 20}, time.Now().Add(time.Second))
	var typed *Error
	if !errors.As(e, &typed) || typed.Code != "resource_exhausted" {
		t.Fatal("queued token bound bypassed", e)
	}
	if e := <-result; !errors.As(e, &typed) || typed.Code != "queue_timeout" {
		t.Fatal(e)
	}
	held.Release()
	if v := a.Snapshot(); v.Interactive.Running != 0 || v.Interactive.QueuedTokens != 0 {
		t.Fatal(v)
	}
}
func TestCancelGrantAndCloseRacesReleaseExactlyOnce(t *testing.T) {
	for i := 0; i < 100; i++ {
		a := testAdmission(t, testLimits())
		held := acquire(t, a, Interactive)
		ctx, cancel := context.WithCancel(context.Background())
		result := make(chan *Permit, 1)
		go func() { p, _ := a.Acquire(ctx, Interactive, Work{10, 10}, time.Now().Add(time.Second)); result <- p }()
		waitQueue(t, a, Interactive, 1)
		var wg sync.WaitGroup
		wg.Add(3)
		go func() { defer wg.Done(); cancel() }()
		go func() { defer wg.Done(); held.Release(); held.Release() }()
		go func() { defer wg.Done(); a.Close() }()
		wg.Wait()
		if p := <-result; p != nil {
			p.Release()
			p.Release()
		}
		v := a.Snapshot()
		if v.Interactive.Running != 0 || v.Interactive.RunningTokens != 0 || v.Interactive.Queued != 0 || v.Interactive.QueuedTokens != 0 {
			t.Fatal(v)
		}
	}
}
