package client

import "net"

func NewDirectClient(address string, opts ...ClientOption) (*Client, error) {
	if _, _, err := net.SplitHostPort(address); err != nil {
		return nil, err
	}
	c, err := NewClient(nil, opts...)
	if err != nil {
		return nil, err
	}
	c.directAddress = address
	return c, nil
}
