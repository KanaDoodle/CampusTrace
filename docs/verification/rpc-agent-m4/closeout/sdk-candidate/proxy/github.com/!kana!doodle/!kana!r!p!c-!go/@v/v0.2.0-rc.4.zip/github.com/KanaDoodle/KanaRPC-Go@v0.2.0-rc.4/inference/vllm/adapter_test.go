package vllm

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/rpc"
)

func adapterRPC(t *testing.T, a *Adapter, capacity int, timeout time.Duration) (*rpc.Client, *rpc.Server) {
	t.Helper()
	s, err := rpc.NewServer(rpc.ServerConfig{Address: "127.0.0.1:0", MaxConcurrentRequests: capacity})
	if err != nil {
		t.Fatal(err)
	}
	if err := a.Register(s); err != nil {
		t.Fatal(err)
	}
	done := make(chan error, 1)
	go func() { done <- s.Start() }()
	until := time.Now().Add(3 * time.Second)
	for s.Addr() == nil && time.Now().Before(until) {
		time.Sleep(time.Millisecond)
	}
	if s.Addr() == nil {
		t.Fatal("RPC did not listen")
	}
	c, err := rpc.NewDirectClient(s.Addr().String(), rpc.ClientConfig{Timeout: timeout, StreamWindow: 2})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		c.Close()
		s.Shutdown()
		if err := <-done; err != nil {
			t.Error(err)
		}
	})
	return c, s
}
func fixtureAdapter(t *testing.T, h http.HandlerFunc) (*Adapter, *httptest.Server) {
	t.Helper()
	up := httptest.NewServer(h)
	t.Cleanup(up.Close)
	a, err := New(Config{BaseURL: up.URL, Model: "fixture-model", APIKey: "test-secret"})
	if err != nil {
		t.Fatal(err)
	}
	return a, up
}
func request() ChatRequest {
	return ChatRequest{Messages: []Message{{Role: "user", Content: "hello"}}, MaxTokens: 16}
}
func emit(w http.ResponseWriter, content string) {
	data, _ := json.Marshal(ChatChunk{Model: "fixture-model", Choices: []Choice{{Delta: Delta{Content: content}}}})
	fmt.Fprintf(w, "data: %s\n\n", data)
	w.(http.Flusher).Flush()
}

func TestAdapterStreamsBeforeUpstreamCompletes(t *testing.T) {
	release := make(chan struct{})
	defer close(release)
	a, _ := fixtureAdapter(t, func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/v1/chat/completions" || r.Header.Get("Authorization") != "Bearer test-secret" {
			t.Error("wrong upstream request")
		}
		var body struct {
			Model         string
			Stream        bool
			StreamOptions struct {
				IncludeUsage bool `json:"include_usage"`
			} `json:"stream_options"`
		}
		if err := json.NewDecoder(r.Body).Decode(&body); err != nil || body.Model != "fixture-model" || !body.Stream || !body.StreamOptions.IncludeUsage {
			t.Error(body, err)
		}
		w.Header().Set("Content-Type", "text/event-stream")
		emit(w, "hello")
		select {
		case <-release:
		case <-r.Context().Done():
			return
		}
		emit(w, " world")
		fmt.Fprint(w, "data: {\"choices\":[],\"usage\":{\"prompt_tokens\":1,\"completion_tokens\":2,\"total_tokens\":3}}\n\ndata: [DONE]\n\n")
	})
	c, _ := adapterRPC(t, a, 2, 3*time.Second)
	s, err := c.InvokeStream(context.Background(), ServiceName, MethodName, request())
	if err != nil {
		t.Fatal(err)
	}
	defer s.Close()
	var first ChatChunk
	if err := s.Recv(&first); err != nil || first.Choices[0].Delta.Content != "hello" {
		t.Fatal(first, err)
	}
	// This observation happens while the upstream is deliberately unfinished.
	release <- struct{}{}
	var rest ChatChunk
	if err := s.Recv(&rest); err != nil || rest.Choices[0].Delta.Content != " world" {
		t.Fatal(rest, err)
	}
	var usage ChatChunk
	if err := s.Recv(&usage); err != nil || usage.Usage == nil || usage.Usage.TotalTokens != 3 {
		t.Fatal(usage, err)
	}
	if err := s.Recv(&rest); err != io.EOF {
		t.Fatal(err)
	}
}

func TestAdapterRemoteCancellationClosesHTTPRequest(t *testing.T) {
	stopped := make(chan struct{})
	a, _ := fixtureAdapter(t, func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/event-stream")
		emit(w, "first")
		<-r.Context().Done()
		close(stopped)
	})
	c, _ := adapterRPC(t, a, 1, 3*time.Second)
	s, err := c.InvokeStream(context.Background(), ServiceName, MethodName, request())
	if err != nil {
		t.Fatal(err)
	}
	var chunk ChatChunk
	if err := s.Recv(&chunk); err != nil {
		t.Fatal(err)
	}
	_ = s.Close()
	select {
	case <-stopped:
	case <-time.After(time.Second):
		t.Fatal("RPC cancel did not cancel upstream HTTP request")
	}
	if err := s.Recv(&chunk); !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
}

func TestAdapterUpstreamFailuresRemainFailures(t *testing.T) {
	for _, scenario := range []string{"status", "content_type", "malformed", "truncated", "oversized", "error_event"} {
		t.Run(scenario, func(t *testing.T) {
			a, _ := fixtureAdapter(t, func(w http.ResponseWriter, r *http.Request) {
				if scenario == "status" {
					w.WriteHeader(429)
					fmt.Fprint(w, "test-secret private prompt")
					return
				}
				if scenario == "content_type" {
					w.Header().Set("Content-Type", "application/json")
					fmt.Fprint(w, `{}`)
					return
				}
				w.Header().Set("Content-Type", "text/event-stream")
				switch scenario {
				case "malformed":
					fmt.Fprint(w, "data: {invalid}\n\n")
				case "truncated":
					emit(w, "partial")
				case "oversized":
					fmt.Fprint(w, "data: "+strings.Repeat("x", MaxEventBytes+1)+"\n\n")
				case "error_event":
					fmt.Fprint(w, "data: {\"error\":{\"message\":\"test-secret\"}}\n\n")
				}
			})
			c, _ := adapterRPC(t, a, 2, 3*time.Second)
			s, err := c.InvokeStream(context.Background(), ServiceName, MethodName, request())
			if err != nil {
				t.Fatal(err)
			}
			defer s.Close()
			var chunk ChatChunk
			for i := 0; i < 3; i++ {
				err = s.Recv(&chunk)
				if err != nil {
					break
				}
			}
			if err == nil || err == io.EOF {
				t.Fatalf("%s incorrectly succeeded: %v", scenario, err)
			}
			if strings.Contains(err.Error(), "test-secret") {
				t.Fatal("upstream error exposed secret payload")
			}
		})
	}
}

func TestAdapterValidationAndModels(t *testing.T) {
	var chatCalls atomic.Int32
	a, _ := fixtureAdapter(t, func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/v1/models" {
			fmt.Fprint(w, `{"data":[{"id":"fixture-model"}]}`)
			return
		}
		chatCalls.Add(1)
	})
	models, err := a.Models(context.Background())
	if err != nil || len(models) != 1 || models[0] != "fixture-model" {
		t.Fatal(models, err)
	}
	c, _ := adapterRPC(t, a, 2, 3*time.Second)
	for _, input := range []any{ChatRequest{}, ChatRequest{Messages: []Message{{Role: "invalid", Content: "x"}}}, ChatRequest{Messages: request().Messages, MaxTokens: -1}, map[string]any{"model": "untrusted", "messages": request().Messages}} {
		s, err := c.InvokeStream(context.Background(), ServiceName, MethodName, input)
		if err != nil {
			t.Fatal(err)
		}
		var chunk ChatChunk
		if err := s.Recv(&chunk); err == nil || err == io.EOF {
			t.Fatal("invalid input accepted", input)
		}
	}
	if chatCalls.Load() != 0 {
		t.Fatal("invalid input reached model backend")
	}
	for _, endpoint := range []string{"", "file:///tmp/model", "https://user:secret@example.org", "http://localhost:8000/?key=secret"} {
		if _, err := New(Config{BaseURL: endpoint, Model: "model"}); err == nil {
			t.Fatal("invalid URL accepted", endpoint)
		}
	}
}

func TestAdapterDoesNotFollowCredentialRedirects(t *testing.T) {
	var reached atomic.Bool
	target := httptest.NewServer(http.HandlerFunc(func(http.ResponseWriter, *http.Request) { reached.Store(true) }))
	defer target.Close()
	a, _ := fixtureAdapter(t, func(w http.ResponseWriter, r *http.Request) { http.Redirect(w, r, target.URL, 307) })
	if _, err := a.Models(context.Background()); err == nil {
		t.Fatal("redirect accepted")
	}
	if reached.Load() {
		t.Fatal("credential request followed redirect")
	}
}

func TestSSEMultilineCommentsAndBoundaries(t *testing.T) {
	input := ": comment\r\nevent: message\r\ndata: {\"choices\":\r\ndata: []}\r\n\r\ndata: [DONE]\r\n\r\n"
	var got []string
	if err := readSSE(context.Background(), strings.NewReader(input), func(body []byte) error { got = append(got, string(body)); return nil }); err != nil {
		t.Fatal(err)
	}
	if len(got) != 1 || !json.Valid([]byte(got[0])) {
		t.Fatal(got)
	}
	if err := readSSE(context.Background(), strings.NewReader("data: {}\n\n"), func([]byte) error { return nil }); err != io.ErrUnexpectedEOF {
		t.Fatal("missing DONE accepted", err)
	}
	want := errors.New("consumer failed")
	if err := readSSE(context.Background(), strings.NewReader("data: {}\n\ndata: [DONE]\n\n"), func([]byte) error { return want }); err != want {
		t.Fatal(err)
	}
}

// This deliberately skips without a real, explicitly configured vLLM service.
// An SSE fixture is never treated as evidence of model execution or GPU benefit.
func TestRealVLLMThroughRPC(t *testing.T) {
	endpoint, model := os.Getenv("KANARPC_VLLM_BASE_URL"), os.Getenv("KANARPC_VLLM_MODEL")
	if endpoint == "" {
		t.Skip("real vLLM not configured; set KANARPC_VLLM_BASE_URL and KANARPC_VLLM_MODEL")
	}
	if model == "" {
		t.Fatal("KANARPC_VLLM_MODEL required")
	}
	a, err := New(Config{BaseURL: endpoint, Model: model, APIKey: os.Getenv("VLLM_API_KEY")})
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	models, err := a.Models(ctx)
	if err != nil {
		t.Fatal(err)
	}
	found := false
	for _, id := range models {
		if id == model {
			found = true
		}
	}
	if !found {
		t.Fatal("configured model not listed by backend")
	}
	c, _ := adapterRPC(t, a, 2, 90*time.Second)
	started := time.Now()
	s, err := c.InvokeStream(ctx, ServiceName, MethodName, ChatRequest{Messages: []Message{{Role: "user", Content: "Reply with a brief greeting."}}, MaxTokens: 16})
	if err != nil {
		t.Fatal(err)
	}
	defer s.Close()
	events, textEvents := 0, 0
	for {
		var chunk ChatChunk
		err := s.Recv(&chunk)
		if err == io.EOF {
			break
		}
		if err != nil {
			t.Fatal(err)
		}
		events++
		for _, choice := range chunk.Choices {
			if choice.Delta.Content != "" || choice.Delta.ReasoningContent != "" {
				textEvents++
			}
		}
	}
	if events == 0 || textEvents == 0 {
		t.Fatal("backend produced no text")
	}
	t.Logf("real vLLM: model=%s events=%d text_events=%d elapsed=%s", model, events, textEvents, time.Since(started))
}

func TestDiscoverySeparatesModelWorkers(t *testing.T) {
	endpoint := os.Getenv("KANARPC_TEST_ETCD")
	if endpoint == "" {
		t.Skip("requires isolated etcd")
	}
	r, err := rpc.NewRegistry([]string{endpoint})
	if err != nil {
		t.Fatal(err)
	}
	defer r.Close()
	prefix := fmt.Sprintf("test-model-%d-", time.Now().UnixNano())
	models := []string{prefix + "A", prefix + "B"}
	for _, model := range models {
		up := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, request *http.Request) {
			w.Header().Set("Content-Type", "text/event-stream")
			data, _ := json.Marshal(ChatChunk{Model: model, Choices: []Choice{{Delta: Delta{Content: model}}}})
			fmt.Fprintf(w, "data: %s\n\ndata: [DONE]\n\n", data)
		}))
		defer up.Close()
		a, err := New(Config{BaseURL: up.URL, Model: model})
		if err != nil {
			t.Fatal(err)
		}
		_, server := adapterRPC(t, a, 4, 3*time.Second)
		if err := r.Register(ServiceForModel(model), server.Addr().String(), 5); err != nil {
			t.Fatal(err)
		}
	}
	c, err := rpc.NewClient(r, rpc.ClientConfig{Timeout: 3 * time.Second})
	if err != nil {
		t.Fatal(err)
	}
	defer c.Close()
	for i := 0; i < 8; i++ {
		for _, model := range models {
			stream, err := c.InvokeStream(context.Background(), ServiceForModel(model), MethodName, request())
			if err != nil {
				t.Fatal(err)
			}
			var chunk ChatChunk
			if err := stream.Recv(&chunk); err != nil || chunk.Model != model {
				t.Fatal("wrong model selected", chunk.Model, model, err)
			}
			if err := stream.Recv(&chunk); err != io.EOF {
				t.Fatal(err)
			}
		}
	}
}
