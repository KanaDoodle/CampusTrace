package rpc

import (
	"context"
	"encoding/json"
	"errors"

	"github.com/KanaDoodle/KanaRPC-Go/internal/protocol"
	"github.com/KanaDoodle/KanaRPC-Go/internal/transport"
)

// StreamHandler sends JSON response chunks until it returns. It must observe
// ctx and wait for any goroutines it starts before returning.
type StreamHandler func(ctx context.Context, request json.RawMessage, stream *ServerStream) error

// ErrStreamingUnsupported reports a peer that did not negotiate stream v1.
var ErrStreamingUnsupported = transport.ErrStreamingUnsupported

type ServerStream struct{ send func([]byte) error }

func (s *ServerStream) Send(value any) error {
	body, err := json.Marshal(value)
	if err != nil {
		return err
	}
	return s.send(body)
}

func (s *Server) RegisterStream(service, method string, handler StreamHandler) error {
	if handler == nil {
		return errors.New("stream handler required")
	}
	return s.inner.RegisterStream(service, method, func(ctx context.Context, body []byte, send func([]byte) error) error {
		return handler(ctx, json.RawMessage(body), &ServerStream{send: send})
	})
}

// ClientStream is server-streaming: one JSON request, zero or more JSON chunks.
// Recv returns io.EOF after normal completion. Close cancels an abandoned stream.
// Receiving calls are serialized; callers must not use a response object before
// its Recv call returns. The context and configured timeout cover the whole stream.
type ClientStream struct{ inner *transport.ClientStream }

func (s *ClientStream) Recv(response any) error {
	body, err := s.inner.Recv()
	if err != nil {
		return publicStreamError(err)
	}
	if err := json.Unmarshal(body, response); err != nil {
		_ = s.Close()
		return err
	}
	return nil
}
func (s *ClientStream) Close() error { return s.inner.Close() }

type StreamError struct{ Code, Message string }

// StatusError lets a stream handler report a bounded, structured application
// status. Admission failures are distinct from transport/backend failures.
type StatusError struct{ Code, Message string }

func (e *StatusError) Error() string   { return e.Code + ": " + e.Message }
func (e *StatusError) RPCCode() string { return e.Code }

func (e *StreamError) Error() string { return e.Code + ": " + e.Message }
func (e *StreamError) Is(target error) bool {
	return (e.Code == "canceled" && target == context.Canceled) || (e.Code == "deadline_exceeded" && target == context.DeadlineExceeded)
}
func publicStreamError(err error) error {
	var remote *transport.StreamError
	if errors.As(err, &remote) {
		return &StreamError{Code: remote.Code, Message: remote.Message}
	}
	return err
}

func (c *Client) InvokeStream(ctx context.Context, service, method string, request any) (*ClientStream, error) {
	stream, err := c.inner.InvokeStream(ctx, service, method, request, c.streamWindow)
	if err != nil {
		return nil, publicStreamError(err)
	}
	return &ClientStream{inner: stream}, nil
}

func streamWindow(value int) (uint32, error) {
	if value == 0 {
		value = protocol.DefaultStreamWindow
	}
	if value < 1 || value > protocol.MaxStreamWindow {
		return 0, errors.New("stream window must be between 1 and 32")
	}
	return uint32(value), nil
}
