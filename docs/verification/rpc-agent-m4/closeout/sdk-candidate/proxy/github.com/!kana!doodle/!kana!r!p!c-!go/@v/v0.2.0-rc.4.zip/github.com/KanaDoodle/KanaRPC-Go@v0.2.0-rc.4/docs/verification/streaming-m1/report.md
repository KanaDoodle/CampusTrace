# M1 实施与验证报告

日期：2026-10-30。环境：Apple M5 / Darwin arm64 / Go 1.27.1；项目最低声明 Go 1.25.9，未增加依赖或升级 go.mod。开始时工作区干净，基线 HEAD 为 `79f5acf0da672651b28c63b4da94c0fcda19417b`。

## 交付范围与状态

**M1 实现及本地验证完成；真实 vLLM 服务/GPU 验收待环境。** 使用者已明确确认目前没有可用 vLLM，因此没有租用 GPU、运行真实模型或声称模型性能收益。

| 阶段 | 已交付 | 实际验证 |
| --- | --- | --- |
| 协议 | 显式能力探测、version 1、OPEN/ACCEPT/DATA/END/CANCEL/WINDOW_UPDATE、序号和剩余预算 | unary 编码兼容、旧端业务载荷隔离、版本拒绝、元数据 fuzz |
| 多路复用与生命周期 | 每流窗口、有界接收、逐流取消、终态一次发布、断连/关闭回收 | 真实 TCP 混合流/unary、慢消费者、满载取消、结束竞争、net.Pipe 半帧边界 |
| 公共 API | RegisterStream、InvokeStream、Recv/Close、结构化 StreamError；NewDirectClient | 真实 TCP API 调用、真实 etcd 发现、错误与取消语义 |
| vLLM adapter | Chat Completions HTTP/SSE、usage、输入/事件上限、模型固定与服务名隔离、Context 取消 | 本地可控 HTTP/SSE + 真实 RPC；模型隔离使用独立真实 etcd |
| 命令与验收 | inference-worker / inference-check / 明确无模型的 inference-fixture / verify-streaming.sh | 独立进程 direct、etcd discovery 两种模式：正常结束、提前取消、上游 HTTP 取消 |
| 真实推理入口 | Models 预检、真实服务 opt-in 测试及 CLI 验收命令 | **未执行模型推理；TestRealVLLMThroughRPC 明确跳过** |

完整计划见 [实施路线](../../implementation/ai-inference-roadmap.md)，API/协议/真实 vLLM 命令见 [M1 使用说明](../../implementation/streaming-m1.md)。M2 token 调度、M3 KV 路由、M4 CampusTrace/Agent 接入均尚未实施。

## 对现有代码的具体影响

- Header 新增字段为 omitempty，普通 Invoke 保持旧帧与处理器约定。流式调用先无业务载荷探测，再发送真实请求；旧端或版本不符快速返回不支持。
- TCPClient 新增独立流 map 和探测状态，Future 仍用于一次性 unary。流接收队列不会阻塞连接 readLoop。
- Server 新增显式流 handler；连接读结束前先取消所有流，再等待业务退出。逐流取消保持已开始的数据帧完整，避免损坏其他共享调用。
- 执行名额满时从等待改为快速拒绝，包含同步调用；这是为保证控制消息仍可读取而作出的明确行为变更，不宣称所有过载行为完全兼容旧版。
- vLLM Worker 固定模型，etcd 以模型 ID 的哈希服务名区分池；direct 调用也可显式指定模型服务。当前没有模型负载感知选择策略。
- 新 adapter 只依赖公共 rpc 包和标准库。CampusTrace 未在本轮改动；已有同步调用仍可继续使用。

## 最终检查

| 命令/场景 | 结果 | 证据 |
| --- | --- | --- |
| 改造前 `go test -race -count=1 ./...` | 通过；未设置 etcd，为旧测试基本回归，不代表集成全覆盖 | [基线](baseline-race.txt) |
| `KANARPC_TEST_ETCD=127.0.0.1:32379 go test -count=1 -timeout=120s -v ./...` | **89 项顶层 Test 通过，1 项真实 vLLM 跳过** | [最终普通测试](final-test.txt) |
| 同环境 `go test -race -count=1 -timeout=120s -v ./...` | **89 项通过，1 项跳过，无 race 报告**；etcd 用例实际运行 | [最终 race](final-race.txt) |
| `go vet ./...` | exit 0，无诊断 | [vet](final-vet.txt) |
| 分阶段 `-race -count=3/5` | transport/server/rpc/adapter 集合多轮通过 | [初轮压力](stress.txt)、[复查回归](review-regression.txt)、[取消竞争](race-cancel.txt)、[探测修复后](probe-fixed.txt) |
| 两模型独立发现 `-race -count=3 ./inference/vllm` | 通过，反复选址没有混到另一个模型 | [模型隔离](model-isolation-fixed.txt) |
| 取消与已开始写帧边界 `-race -count=30` | 通过 | [写入屏障回归](write-barrier-fixed.txt) |
| `FuzzStreamHeaderRoundTrip -fuzztime=10s` | **2,269,174 次执行，PASS** | [元数据 fuzz](fuzz-header.txt) |
| `FuzzDecodeNeverPanics -fuzztime=10s` | **2,635,575 次执行，PASS** | [解析 fuzz](fuzz-decode.txt) |
| 独立进程，无发现 | 正常 END、提前 Close、上游 HTTP 取消均通过 | [运行摘要](process-direct-delivery.txt)、[完成](direct-complete.json)、[取消](direct-cancel.json)、[上游记录](direct-fixture.jsonl) |
| 独立进程，真实 etcd 模型发现 | 同上通过；worker 注册成功后 SDK 按模型服务名发现 | [运行摘要](process-discovery.txt)、[完成](discovery-complete.json)、[取消](discovery-cancel.json)、[worker 就绪](discovery-worker.jsonl) |

顶层 Test 由 67 增至 90，新增 23 个，其中 22 个本轮实际通过，1 个需要真实 vLLM。fuzz 的 seed 用例不计入上述顶层 Test 数。

最终检查后没有再修改生产代码。验收脚本退出时已终止自己启动的 fixture/worker；本轮独立 etcd 也已停止，临时数据目录保留用于排查。

## 实现与验证中发现并解决的边界

1. **版本拒绝被当作迟到流帧丢弃。** 第一次实现把所有未登记流的 END 忽略，能力探测的 END 拒绝也因此被丢弃，变成等待超时。[最小复现确实失败](version-rejection-repro.txt)。现在 TCPClient 单独跟踪探测 ID，严格校验 HELLO_ACK 的 kind/version/error，立即返回不支持；定向测试和最终集合均通过。
2. **共享写入不能被逐流取消截断。** 若用流 Context 中断已经开始的 socket 写入，会损坏共享帧、影响其他请求。现在信用等待可取消，但实际数据帧写入使用连接 Context 和有限写超时；断连仍终止所有流。net.Pipe 测试验证 CANCEL 已被读取且逻辑请求已取消后，完整 DATA/END 与后续 HELLO 仍可通过同一连接。
3. **写锁等待必须消耗预算。** OPEN 在拿到写名额后重新编码预算，测试确认排队时间没有重新加给服务端。
4. **测试屏障本身需要确定性。** 首次全量运行时，写帧取消测试只等 handler 进入，取消可能早于 Send 开始，因此正确地只返回 END，测试错误期待 DATA 而失败。[初次输出保留](initial-validation.txt)。测试改为观测底层 DATA Write 入口，再发送 CANCEL；没有据此改动生产行为，之后 race 30 次和全量均通过。

## 微基准与证据边界

`go test ./rpc -run '^$' -bench '^BenchmarkStreamRoundTrip$' -benchmem -benchtime=1s -count=3` 使用单机真实 TCP；每流发送 32 个 256 字节文本块，包含能力探测与信用更新。三轮为约 1.274 / 0.746 / 0.749 ms/stream，约 368–371 KB 与 1,426–1,428 次分配。[原始结果](benchmark.txt)。

这是新增链路的初步烟雾基准，运行时有其他测试并发，不能用于严谨性能比较，也没有旧流式基线。它没有模型/GPU、跨机网络、token 调度或负载优势的结论；首次运行波动也不能删除。后续 M2 需要隔离环境、固定到达率、固定模型和真实后端对照。

独立进程证据中的首文本耗时来自可控 SSE fixture，**不是 vLLM TTFT**。fixture 的 purpose 是验证逐块到达、结束和取消，不是模拟模型准确的计算性能。

## 已知限制与后续工作

- 单请求/服务端响应流，仅 JSON；无双向业务流、持久恢复、自动重试。
- handler 必须协作取消；HTTP 取消不等于证明 GPU 计算立即停止或不会产生费用。
- TCP 队头阻塞、旧 unary 同步完成回调、全局连接/进程资源上限等仍有边界。5 秒控制写超时或半帧故障可使共享连接整体失败。
- Shutdown 取消流并关闭连接，仍未实现响应 drain 或统一关闭 deadline。
- 默认接收窗口 8，最多 32，每帧 64 KiB，每连接最多 64 流；这些不是全进程内存或 GPU 显存硬上限。
- M1 使用每流一次能力探测；模型隔离只有身份命名，真实推理调度和缓存事件索引待 M2/M3。
- 用户已确认没有真实 vLLM。下一次真实服务验收须记录引擎版本、模型、请求/终态、取消与后续调用结果；GPU 性能另做对照。
