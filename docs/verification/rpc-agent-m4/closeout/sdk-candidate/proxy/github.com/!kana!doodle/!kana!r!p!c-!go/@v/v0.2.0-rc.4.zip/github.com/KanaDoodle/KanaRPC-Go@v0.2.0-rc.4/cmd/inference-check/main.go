package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/inference/gateway"
	"github.com/KanaDoodle/KanaRPC-Go/inference/scheduler"
	"github.com/KanaDoodle/KanaRPC-Go/inference/vllm"
	"github.com/KanaDoodle/KanaRPC-Go/rpc"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
func run() error {
	address := flag.String("address", "127.0.0.1:9093", "RPC worker endpoint (without discovery)")
	etcd := flag.String("etcd", "", "use service discovery through this etcd endpoint instead of address")
	modelID := flag.String("model", "", "model ID; required for discovery, optional with an explicit address")
	prompt := flag.String("prompt", "Reply with a brief greeting.", "text prompt")
	maxTokens := flag.Int("max-tokens", 16, "maximum generated tokens")
	timeout := flag.Duration("timeout", 90*time.Second, "whole stream timeout")
	cancelFirst := flag.Bool("cancel-after-first", false, "cancel after receiving first nonempty text chunk")
	scheduled := flag.Bool("scheduled", false, "use the M2 gateway event API; requires model")
	class := flag.String("class", "interactive", "scheduled workload class: interactive or batch")
	queueBudget := flag.Duration("queue-budget", 0, "optional scheduled queue budget, within gateway limit")
	ttftTarget := flag.Duration("ttft-target", 0, "optional scheduled first-text target, at most 30s")
	cacheSalt := flag.String("cache-salt", "", "optional prefix-cache isolation salt; not authentication")
	flag.Parse()
	if (*etcd != "" || *scheduled) && *modelID == "" {
		return errors.New("-model is required with -etcd or -scheduled")
	}
	if *queueBudget < 0 || *ttftTarget < 0 || (*queueBudget > 0 && *queueBudget < time.Millisecond) || (*ttftTarget > 0 && *ttftTarget < time.Millisecond) {
		return errors.New("budgets must be zero or at least 1ms")
	}
	var c *rpc.Client
	var err error
	if *etcd != "" {
		r, e := rpc.NewRegistry([]string{*etcd})
		if e != nil {
			return e
		}
		defer r.Close()
		c, err = rpc.NewClient(r, rpc.ClientConfig{Timeout: *timeout})
	} else {
		c, err = rpc.NewDirectClient(*address, rpc.ClientConfig{Timeout: *timeout})
	}
	if err != nil {
		return err
	}
	defer c.Close()
	ctx, cancel := context.WithTimeout(context.Background(), *timeout)
	defer cancel()
	started := time.Now()
	service := vllm.ServiceName
	if *modelID != "" {
		service = vllm.ServiceForModel(*modelID)
	}
	chat := vllm.ChatRequest{Messages: []vllm.Message{{Role: "user", Content: *prompt}}, MaxTokens: *maxTokens, CacheSalt: *cacheSalt}
	var request any = chat
	if *scheduled {
		service = gateway.ServiceForModel(*modelID)
		request = gateway.Request{Chat: chat, Class: scheduler.Class(*class), QueueBudgetMS: int(queueBudget.Milliseconds()), TargetTTFTMS: int(ttftTarget.Milliseconds())}
	}
	s, err := c.InvokeStream(ctx, service, vllm.MethodName, request)
	if err != nil {
		return err
	}
	defer s.Close()
	events, textEvents := 0, 0
	var ttft time.Duration
	var usage *vllm.Usage
	model := ""
	terminal := ""
	var decision *scheduler.Decision
	var summary *gateway.Summary
	for {
		var raw json.RawMessage
		err := s.Recv(&raw)
		if err == io.EOF {
			terminal = "eof"
			break
		}
		if *cancelFirst && textEvents > 0 && errors.Is(err, context.Canceled) {
			terminal = "canceled"
			break
		}
		if err != nil {
			return err
		}
		if *scheduled {
			var event gateway.Event
			if err := json.Unmarshal(raw, &event); err != nil {
				return err
			}
			switch event.Type {
			case "scheduled":
				decision = event.Decision
				continue
			case "summary":
				summary = event.Summary
				continue
			case "chunk":
				raw = event.Chunk
			default:
				return errors.New("unknown scheduled event")
			}
		}
		var chunk vllm.ChatChunk
		if err := json.Unmarshal(raw, &chunk); err != nil {
			return err
		}
		events++
		if chunk.Model != "" {
			model = chunk.Model
		}
		if chunk.Usage != nil {
			usage = chunk.Usage
		}
		for _, choice := range chunk.Choices {
			if choice.Delta.Content != "" || choice.Delta.ReasoningContent != "" {
				textEvents++
				if ttft == 0 {
					ttft = time.Since(started)
				}
			}
		}
		if *cancelFirst && textEvents > 0 {
			_ = s.Close()
		}
	}
	if textEvents == 0 {
		return errors.New("stream returned no text")
	}
	if *scheduled && terminal == "eof" && (summary == nil || decision == nil) {
		return errors.New("scheduled stream missing decision or summary")
	}
	return json.NewEncoder(os.Stdout).Encode(map[string]any{"mode": "configured-upstream", "scheduled": *scheduled, "model": model, "terminal": terminal, "events": events, "text_events": textEvents, "first_text_ms": float64(ttft) / float64(time.Millisecond), "elapsed_ms": float64(time.Since(started)) / float64(time.Millisecond), "usage": usage, "decision": decision, "gateway_summary": summary})
}
