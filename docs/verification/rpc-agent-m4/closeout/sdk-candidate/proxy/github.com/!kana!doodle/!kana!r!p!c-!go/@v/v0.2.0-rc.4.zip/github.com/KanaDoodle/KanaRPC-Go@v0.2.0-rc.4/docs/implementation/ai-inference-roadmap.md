# AI 推理 RPC 升级实施计划

日期：2026-10-30。代码基线：`79f5acf0da672651b28c63b4da94c0fcda19417b`。本轮工作区开始时无未提交修改。

## 现有代码与改造入口

| 现状 | 改造入口 | 约束 |
| --- | --- | --- |
| Header 只有 requestID、方法、错误、codec、compression | `internal/protocol/header.go` | 同步调用的字段与帧格式保持兼容；流式调用先探测能力，旧端不能误执行业务 |
| TCPClient 只有一次性 pending Future | `internal/transport/tcp_client.go`、新增流状态 | 同连接按 ID 区分 unary/stream；读循环不能等待慢消费者 |
| Server 读循环等待全局 workerSem | `internal/server/server.go`、新增流会话 | 接纳须有界，满载快速拒绝；读循环持续处理取消/窗口控制消息 |
| 反射 handler 不接收 Context | 新增显式流式 handler 注册 | 保留旧 Register；流式 handler 使用 Context 与 Send |
| public facade 只暴露 Invoke | `rpc/stream.go` | 新增 InvokeStream / RegisterStream；不暴露 internal 类型 |
| 尚无模型后端 | 新增公开 `inference/vllm` adapter 和命令入口 | 标准 HTTP/SSE 协议、真实连接取消、输入与事件上限；不修改模型引擎 |

## 里程碑及验收门槛

### M1：流式 RPC 与 vLLM 接入（本轮实施）

状态：实现与本地验证完成，真实 vLLM/GPU 验收待可用服务。详见[验证报告](../verification/streaming-m1/report.md)。

1. 协议：能力探测 + version 1，OPEN/ACCEPT/DATA/END/CANCEL/WINDOW_UPDATE；每流序号、接收窗口、剩余预算、明确终态。
2. 接收信用：默认 8 帧、最多 32 帧、每帧最多 64 KiB、每连接最多 64 个流；消费一帧才归还信用。读循环非阻塞入队，违规超窗关闭协议连接。
3. 生命周期：完成/取消/断连一次性收敛；逐流取消不主动关闭共享连接；断连和 shutdown 取消服务器流 Context；服务满载拒绝新调用而不停止读取控制帧。
4. API：JSON 请求与 JSON 响应片段，先实现单请求/服务端响应流；双向业务流、持久恢复不在 M1。并发多个流与 unary 共用连接。
5. vLLM：Chat Completions streaming adapter，解析有界 SSE、处理 DONE/usage/错误/截断，取消向 HTTP 请求传播；worker 与验收客户端可独立运行。

模型身份在 M1 即按服务名隔离：etcd 注册使用模型 ID 对应的稳定哈希名，避免不同模型被普通轮询混用；模型负载感知选址仍属 M2。
6. 验证：协议边界；真实 TCP 混合多路复用；慢消费者/信用/满载取消；取消与结束竞态；断连/关闭/错误；HTTP SSE 集成；全项目普通/race/vet/fuzz；子进程本地链路演示。

兼容性说明：原同步请求仍以 version=0、kind=0 发送。新版流式客户端先发送无业务载荷的 HELLO，确认能力后才发送 OPEN；不能假定给旧端加 JSON 字段就等于协商成功。流式 API 第一版只支持 JSON；控制写入采用有限超时，底层半帧写错仍必须废弃整个字节流。TCP 本身仍有队头阻塞，没有承诺控制帧可越过已经写入的字节。

接纳行为变化：旧服务端满载时读循环等名额；新版同连接需要读取 CANCEL/WINDOW，因此满载时快速返回 resource_exhausted。此变化需明确记录、测试，M2 再提供有预算的独立排队层。

### M2：token 工作量路由与延迟目标治理

状态：实现与本地验证完成，真实双实例 vLLM/GPU 性能验收待做。详见 [M2 实施说明](scheduling-m2.md)与[验证报告](../verification/scheduling-m2/report.md)。

- 从 inference adapter 上报模型、HTTP active、等待首文本、精确输入 token、输出预留、首文本延迟与文本事件间隔；这些不是 GPU running/waiting/逐 token ITL。每种模型、引擎配置由部署者提供独立校准 profile。
- 对照 round-robin、最少在途请求、token 负载选址；增加交互/批量隔离、有界队列、过期拒绝和防饥饿策略。
- 验证固定到达率、长短混合、实例减速、指标陈旧与不可达；记录 TTFT/输出间隔、成功/拒绝/超时、延迟目标内有效吞吐及批量进度。
- 已完成状态/并发测试、实际路由实现的模拟对照、真实 TCP/HTTP fixture 与独立进程验收。模拟证明的是有限轨迹上的行为，不是一般正确性或性能保证。
- 尚未达到性能门槛：至少两个真实推理实例验证性能，不能用模拟结果声明 GPU 收益；M2 性能验收保持待验。

### M3：KV 缓存感知与饱和转移

状态：实现与本地分阶段验证完成；真实 KV 事件、实际缓存命中和双实例 GPU 性能验收待做。详见 [M3 实施与运行说明](kv-routing-m3.md)、[验证报告](../verification/kv-routing-m3/report.md)。

- 接引擎 KV 事件维护带 freshness 的前缀位置索引；缓存估计与真实事件分开标注，缺失时降级负载路由。
- 缓存亲和与排队成本比较；基于真实模型/硬件校准阈值，避免热点与跨租户错误复用。
- 验证重复/冷前缀、过载缓存热点、缓存淘汰、事件丢失/重建；给出消融对照和失效场景。
- 已实现有界事件索引、精确 token ID 前缀、失效/冷重建、cache_affinity 消融和 cache_aware 饱和改选；不放宽 M2 的冷接纳预算。转移是业务发送前的实例改选，不是 KV 数据搬运或运行中迁移。
- bridge 固定 vLLM v0.32.0 的纯文本/单 DP/单 FullAttention group/本地 GPU 子集；真实 TCP/HTTP/ZMQ fixture 和 63 组模拟通过。未连接真实引擎，不把事件提示当成实际命中；模拟没有显示普遍优于 token_work 的 p95 收益。

### M4：CampusTrace 与 Agent 边界接入

- 状态：经审阅的只读依据说明链路已实现并通过隔离进程与真实 Chromium 验收；真实 vLLM 未接入验收。详见 [M4 接入说明](campustrace-m4.md)。
- 复用 CampusTrace AgentExecution 的 owner、逻辑任务 ID、尝试 nonce、SQL lease、检查点与取消围栏；认证 SSE 读取最新草稿，刷新/重启不自动发起模型调用。
- 未额外引入 A2A/MCP 协议或自由执行权限：已有只读 skill 成功后，显式核对实际脱敏输入才生成独立说明。未知结果重试需重新认可可能重复调用；不承诺外部 exactly-once 或中断生成无损续写。

## 验证证据分级

- 单元测试：状态和边界。
- 本地集成：真实 TCP + 隔离 etcd + 可控 HTTP/SSE 后端，证明本项目链路行为。
- 真实 vLLM 验收：真实服务发现、模型列表、token 流与提前取消。使用者本轮确认尚无 vLLM 服务，因此此项需明确待验，提供命令与 opt-in 测试；不得把可控后端称作 vLLM 实测。
- GPU 性能：属于 M2/M3，需要独立推理实例和固定实验配置。
