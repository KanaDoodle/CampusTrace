package protocol

import "github.com/KanaDoodle/KanaRPC-Go/internal/codec"

// CodecType 编解码器类型
type CodecType byte

const (
	CodecTypeJSON CodecType = iota + 1
	CodecTypeProto
)

type Header struct {
	RequestID    uint64
	ServiceName  string
	MethodName   string
	Error        string
	CodecType    CodecType
	Compression  codec.CompressionType
	Version      uint8  `json:",omitempty"`
	Kind         Kind   `json:",omitempty"`
	Sequence     uint64 `json:",omitempty"`
	Window       uint32 `json:",omitempty"`
	TimeoutNanos int64  `json:",omitempty"`
	Code         string `json:",omitempty"`
}

// Zero kind/version is the existing unary protocol. Stream operations require
// an explicit capability probe before any business payload is transmitted.
type Kind uint8

const (
	Unary Kind = iota
	StreamHello
	StreamHelloAck
	StreamOpen
	StreamAccept
	StreamData
	StreamEnd
	StreamCancel
	StreamWindowUpdate
)

const (
	StreamVersion       = 1
	DefaultStreamWindow = 8
	MaxStreamWindow     = 32
	MaxStreamChunkSize  = 64 << 10
	MaxStreamsPerConn   = 64
)
