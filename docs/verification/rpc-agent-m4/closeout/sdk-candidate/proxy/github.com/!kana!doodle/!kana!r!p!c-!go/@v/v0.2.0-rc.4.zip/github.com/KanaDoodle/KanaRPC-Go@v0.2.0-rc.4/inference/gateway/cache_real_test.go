package gateway_test

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"os"
	"strings"
	"testing"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/inference/gateway"
	"github.com/KanaDoodle/KanaRPC-Go/inference/kvcache"
	"github.com/KanaDoodle/KanaRPC-Go/inference/scheduler"
	"github.com/KanaDoodle/KanaRPC-Go/inference/vllm"
	"github.com/KanaDoodle/KanaRPC-Go/rpc"
)

func TestRealVLLMKVEventRouting(t *testing.T) {
	address, admin, model := os.Getenv("KANARPC_KV_GATEWAY_ADDRESS"), os.Getenv("KANARPC_KV_GATEWAY_ADMIN"), os.Getenv("KANARPC_VLLM_MODEL")
	if address == "" {
		t.Skip("real KV-event vLLM gateway not configured; no model/GPU cache hits or gains validated")
	}
	if admin == "" || model == "" {
		t.Fatal("configured KV acceptance requires KANARPC_KV_GATEWAY_ADMIN and KANARPC_VLLM_MODEL")
	}
	c, err := rpc.NewDirectClient(address, rpc.ClientConfig{Timeout: 90 * time.Second})
	if err != nil {
		t.Fatal(err)
	}
	defer c.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Minute)
	defer cancel()
	request := gateway.Request{Class: scheduler.Interactive, TargetTTFTMS: 30000, Chat: vllm.ChatRequest{Messages: []vllm.Message{{Role: "user", Content: strings.Repeat("This is a shared prefix for KV event acceptance. ", 128) + "Respond with a brief greeting."}}, CacheSalt: "kanarpc-real-kv-acceptance", MaxTokens: 16}}
	observedHint, observedActual := false, false
	for n := 0; n < 4; n++ {
		s, err := c.InvokeStream(ctx, gateway.ServiceForModel(model), vllm.MethodName, request)
		if err != nil {
			t.Fatal(err)
		}
		text, summary := false, false
		for {
			var event gateway.Event
			err := s.Recv(&event)
			if err == io.EOF {
				break
			}
			if err != nil {
				s.Close()
				t.Fatal(err)
			}
			if event.Decision != nil && event.Decision.EstimatedReusableTokens > 0 && event.Decision.CacheEvidence == kvcache.EngineSource {
				observedHint = true
			}
			if event.Type == "chunk" {
				var chunk vllm.ChatChunk
				_ = json.Unmarshal(event.Chunk, &chunk)
				text = text || vllm.HasText(chunk)
			}
			if event.Summary != nil {
				summary = true
				usage := event.Summary.Usage
				if usage != nil && usage.PromptTokensDetails != nil && usage.PromptTokensDetails.CachedTokens > 0 {
					observedActual = true
				}
			}
		}
		_ = s.Close()
		if !text || !summary {
			t.Fatal("real KV flow missing text/summary")
		}
		if observedHint && observedActual {
			break
		}
		// Separate deliberate warm requests, never transport retries.
		if !labWait(ctx, 250*time.Millisecond) {
			t.Fatal(ctx.Err())
		}
	}
	requestHTTP, err := http.NewRequestWithContext(ctx, http.MethodGet, strings.TrimRight(admin, "/")+"/kv/status", nil)
	if err != nil {
		t.Fatal(err)
	}
	response, err := (&http.Client{Timeout: 3 * time.Second}).Do(requestHTTP)
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	if response.StatusCode != 200 {
		t.Fatal("real KV index status", response.StatusCode)
	}
	var views []kvcache.View
	if err := json.NewDecoder(io.LimitReader(response.Body, 1<<20)).Decode(&views); err != nil {
		t.Fatal(err)
	}
	if !observedHint || !observedActual {
		t.Fatalf("real KV acceptance incomplete: event_hint=%v upstream_reported_cached_tokens=%v; no performance gain established", observedHint, observedActual)
	}
	t.Logf("configured real upstream reported cached tokens and vLLM-event hints; index_workers=%d. Functional evidence only; no throughput/latency benefit established", len(views))
}
func labWait(ctx context.Context, d time.Duration) bool {
	timer := time.NewTimer(d)
	defer timer.Stop()
	select {
	case <-timer.C:
		return true
	case <-ctx.Done():
		return false
	}
}
