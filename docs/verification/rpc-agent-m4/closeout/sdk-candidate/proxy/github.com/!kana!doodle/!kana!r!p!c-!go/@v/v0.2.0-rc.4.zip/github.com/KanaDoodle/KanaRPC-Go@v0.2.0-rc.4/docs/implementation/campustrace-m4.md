# M4 CampusTrace / Agent 接入

后续：2026-10-31 已补齐迁移/测试隔离收尾与 [SDK 版本化打包和消费](sdk-release.md)。无需 workspace 的本地候选接入已可运行；公开发布和真实 vLLM 验证仍未执行。

实施入口为相邻 CampusTrace 的 `docs/rpc-agent-m4.md`。保留 M1–M3 传输与治理，以公开 SDK 对接 scheduled gateway，将用户已审阅的只读依据转成独立、可取消、可恢复读取的说明任务。

阶段：持久任务/权限边界 → 固定配置 RPC 文本流 → 认证订阅/取消 → 隔离服务与浏览器端到端。

新 SDK 尚未发布，联调使用本地 workspace + `kanarpc_stream`；本地验收不代表远端 tag 可安装性。真实 vLLM 暂未配置，fixture 不代表实际模型、缓存命中或性能收益。

2026-10-31 状态：四阶段本地实现/验收完成。[CampusTrace 完整说明](../../../campustrace/docs/rpc-agent-m4.md)提供生命周期、HTTP 边界、构建与运行命令；[验证报告](../../../campustrace/docs/verification/rpc-agent-m4/report.md)保留复现失败、回归例外、原始日志、浏览器截图和设计风险（以上为相邻工作区链接）。

RPC 本轮只扩展 `cmd/inference-fixture -mode narration`：提供足够长的无模型分片、恶意 HTML 文本和只读计数入口 `/fixture/status`，观察调用、完成、取消及不同 salt 作用域。默认 `stream` 模式保持原 M1/M2 行为，M1–M3 进程回归通过；wire format、路由算法及历史性能证据未改动。

完整进程：CampusTrace API → scheduled gateway → worker → HTTP fixture。真实 Chromium 验证用户审阅、流式展示、刷新复订阅、未知结果恢复提示、安全文本显示和停止生成。固定轨迹 7 次 fixture 调用、3 完成、4 取消、2 个用户 salt 作用域；重连和重复 nonce 不新增调用。数字仅用于边界验证，没有真实模型/GPU。

RPC 普通测试 202 pass / 3 live SKIP；串行包 race 同样通过。并发 race 首次有一项 100ms 预算断言返回另一超时拒绝码，完整失败日志保留在相邻报告；没有改测试断言来掩盖。真实 vLLM 验收继续待执行。
