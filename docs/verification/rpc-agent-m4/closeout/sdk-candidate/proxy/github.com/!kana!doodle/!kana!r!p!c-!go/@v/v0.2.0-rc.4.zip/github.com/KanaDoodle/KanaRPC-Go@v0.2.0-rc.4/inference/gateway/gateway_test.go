package gateway_test

import (
	"context"
	"errors"
	"io"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/KanaDoodle/KanaRPC-Go/inference/gateway"
	"github.com/KanaDoodle/KanaRPC-Go/inference/lab"
	"github.com/KanaDoodle/KanaRPC-Go/inference/scheduler"
	"github.com/KanaDoodle/KanaRPC-Go/inference/vllm"
	"github.com/KanaDoodle/KanaRPC-Go/rpc"
)

func setup(t *testing.T, b *lab.Backend, configure func(*gateway.Config)) (*gateway.Gateway, *rpc.Client, *lab.Worker) {
	t.Helper()
	w, err := lab.StartWorker("w0", b, 8)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(w.Close)
	cfg := gateway.Config{Model: lab.Model, Workers: []scheduler.Worker{w.Endpoint}, MetricsTTL: time.Minute, MaxRequestDuration: 3 * time.Second, QueueBudget: time.Second, InteractiveTTFT: time.Second, BatchTTFT: 2 * time.Second}
	if configure != nil {
		configure(&cfg)
	}
	g, err := gateway.New(cfg)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(g.Close)
	if err := g.Refresh(context.Background()); err != nil {
		t.Fatal(err)
	}
	server, closeServer, err := lab.StartRPC(32, g.Register)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(closeServer)
	client, err := rpc.NewDirectClient(server.Addr().String(), rpc.ClientConfig{Timeout: 4 * time.Second})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(client.Close)
	return g, client, w
}
func input(content string) gateway.Request {
	return gateway.Request{Chat: vllm.ChatRequest{Messages: []vllm.Message{{Role: "user", Content: content}}, MaxTokens: 16}, Class: scheduler.Interactive}
}
func collect(ctx context.Context, c *rpc.Client, request gateway.Request) ([]gateway.Event, error) {
	s, err := c.InvokeStream(ctx, gateway.ServiceForModel(lab.Model), vllm.MethodName, request)
	if err != nil {
		return nil, err
	}
	defer s.Close()
	var events []gateway.Event
	for {
		var event gateway.Event
		if err := s.Recv(&event); err != nil {
			if err == io.EOF {
				return events, nil
			}
			return events, err
		}
		events = append(events, event)
	}
}
func eventually(t *testing.T, check func() bool) {
	t.Helper()
	until := time.Now().Add(2 * time.Second)
	for !check() {
		if time.Now().After(until) {
			t.Fatal("condition did not settle")
		}
		time.Sleep(time.Millisecond)
	}
}
func code(err error) string {
	var e *rpc.StreamError
	if errors.As(err, &e) {
		return e.Code
	}
	if errors.Is(err, context.Canceled) {
		return "canceled"
	}
	return "other"
}
func drained(t *testing.T, g *gateway.Gateway, w *lab.Worker) {
	t.Helper()
	eventually(t, func() bool {
		s := g.Snapshot()
		return s.Admission.Interactive.Running == 0 && s.Admission.Batch.Running == 0 && s.Admission.Interactive.Queued == 0 && s.Admission.Batch.Queued == 0 && s.Workers[0].LocalReservations == 0 && len(w.Adapter.Status().Active) == 0
	})
}
func TestGatewayTracksTokenWorkAndUsageEndToEnd(t *testing.T) {
	b := &lab.Backend{Gap: time.Millisecond}
	g, c, w := setup(t, b, nil)
	events, err := collect(context.Background(), c, input("one two three"))
	if err != nil || len(events) != 5 {
		t.Fatal(len(events), err)
	}
	decision := events[0].Decision
	if events[0].Type != "scheduled" || decision.Work.PromptTokens != 6 || decision.Work.OutputTokens != 16 || decision.Policy != scheduler.TokenWork {
		t.Fatal(events[0])
	}
	summary := events[len(events)-1].Summary
	if summary == nil || !summary.TTFTMet || summary.Usage.PromptTokens != 6 || summary.Usage.CompletionTokens != 2 {
		t.Fatal(summary)
	}
	drained(t, g, w)
	if b.ChatCalls.Load() != 1 || b.TokenCalls.Load() != 2 {
		t.Fatal("expected exact tokenize at gateway and worker", b.ChatCalls.Load(), b.TokenCalls.Load())
	}
	if g.Snapshot().Completed != 1 {
		t.Fatal(g.Snapshot())
	}
}
func TestGatewayFirstTextDeadlineCancelsHTTPAndReleasesTokens(t *testing.T) {
	b := &lab.Backend{Delay: func(vllm.ChatRequest) time.Duration { return time.Second }}
	g, c, w := setup(t, b, nil)
	request := input("late")
	request.TargetTTFTMS = 100
	_, err := collect(context.Background(), c, request)
	if code(err) != "slo_exceeded" {
		t.Fatal(err)
	}
	eventually(t, func() bool { return b.Canceled.Load() == 1 })
	drained(t, g, w)
	if b.ChatCalls.Load() != 1 || g.Snapshot().Completed != 0 {
		t.Fatal("deadline triggered retry or false completion", g.Snapshot())
	}
}
func TestGatewayQueueExpiresWithoutDispatch(t *testing.T) {
	b := &lab.Backend{Delay: func(vllm.ChatRequest) time.Duration { return 250 * time.Millisecond }}
	g, c, w := setup(t, b, func(cfg *gateway.Config) {
		cfg.Admission = gateway.DefaultAdmission()
		cfg.Admission.Interactive.Running = 1
	})
	done := make(chan error, 1)
	go func() { _, err := collect(context.Background(), c, input("hold")); done <- err }()
	eventually(t, func() bool { return b.Active.Load() == 1 })
	req := input("expired")
	req.QueueBudgetMS = 35
	_, err := collect(context.Background(), c, req)
	if code(err) != "queue_timeout" {
		t.Fatal(err)
	}
	if err := <-done; err != nil {
		t.Fatal(err)
	}
	drained(t, g, w)
	if b.ChatCalls.Load() != 1 {
		t.Fatal("expired request reached inference", b.ChatCalls.Load())
	}
}
func TestGatewayStaleAndMismatchedWorkersFailClosed(t *testing.T) {
	for _, scenario := range []string{"stale", "profile", "unreachable"} {
		t.Run(scenario, func(t *testing.T) {
			b := &lab.Backend{}
			g, c, w := setup(t, b, func(cfg *gateway.Config) {
				if scenario == "stale" {
					cfg.MetricsTTL = 20 * time.Millisecond
				}
			})
			if scenario == "stale" {
				time.Sleep(30 * time.Millisecond)
			} else if scenario == "unreachable" {
				w.Close()
				if g.Refresh(context.Background()) == nil {
					t.Fatal("refresh succeeded after shutdown")
				}
			} else {
				bad := w.Endpoint
				bad.Profile.ID = "wrong-profile"
				mismatch, err := gateway.New(gateway.Config{Model: lab.Model, Workers: []scheduler.Worker{bad}})
				if err != nil {
					t.Fatal(err)
				}
				defer mismatch.Close()
				if mismatch.Refresh(context.Background()) == nil || mismatch.Snapshot().Ready {
					t.Fatal("profile mismatch admitted")
				}
				return
			}
			_, err := collect(context.Background(), c, input("must not dispatch"))
			if code(err) != "unavailable" {
				t.Fatal(err)
			}
			if b.ChatCalls.Load() != 0 {
				t.Fatal("invalid metrics dispatched inference")
			}
		})
	}
}
func TestGatewayCancellationAndShutdownDrainRunningAndQueued(t *testing.T) {
	b := &lab.Backend{Delay: func(vllm.ChatRequest) time.Duration { return time.Second }}
	g, c, w := setup(t, b, func(cfg *gateway.Config) {
		cfg.Admission = gateway.DefaultAdmission()
		cfg.Admission.Interactive.Running = 1
	})
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	var wg sync.WaitGroup
	for i := 0; i < 5; i++ {
		wg.Add(1)
		go func() { defer wg.Done(); _, _ = collect(ctx, c, input("cancel")) }()
	}
	eventually(t, func() bool {
		s := g.Snapshot()
		return s.Admission.Interactive.Running == 1 && s.Admission.Interactive.Queued == 4
	})
	cancel()
	g.Close()
	wg.Wait()
	drained(t, g, w)
	if g.Snapshot().Ready {
		t.Fatal("closed gateway still ready")
	}
	if b.ChatCalls.Load() > 1 {
		t.Fatal("queued cancellation reached inference", b.ChatCalls.Load())
	}
}
func TestGatewayNeverRetriesInferenceAfterDispatch(t *testing.T) {
	b := &lab.Backend{FailChat: true}
	g, c, w := setup(t, b, nil)
	_, err := collect(context.Background(), c, input("fail"))
	if err == nil {
		t.Fatal("upstream failure succeeded")
	}
	drained(t, g, w)
	if b.ChatCalls.Load() != 1 {
		t.Fatal("inference replayed", b.ChatCalls.Load())
	}
}
func TestGatewayRepeatedBudgetRejectionDoesNotOpenBreaker(t *testing.T) {
	g, c, w := setup(t, &lab.Backend{}, func(cfg *gateway.Config) { cfg.Workers[0].Profile.PrefillTokensPerSecond = 1000 })
	for i := 0; i < 24; i++ {
		r := input(strings.Repeat("token ", 6000))
		// 6000/1000 > 6s of predicted prefill cannot meet 2s. Leave wall-clock
		// room for local tokenization under race instrumentation so this case
		// exercises prediction rejection, rather than the separate elapsed budget.
		r.TargetTTFTMS = 2000
		_, err := collect(context.Background(), c, r)
		if code(err) != "slo_unachievable" {
			t.Fatalf("rejection %d: %v", i, err)
		}
	}
	if _, err := collect(context.Background(), c, input("valid")); err != nil {
		t.Fatal("rejections poisoned healthy connection breaker", err)
	}
	drained(t, g, w)
}

func TestGatewayElapsedTokenizationBudgetDoesNotOpenBreaker(t *testing.T) {
	g, c, w := setup(t, &lab.Backend{TokenizeDelay: 40 * time.Millisecond}, nil)
	for i := 0; i < 24; i++ {
		r := input("small prompt with a deliberately slow tokenizer")
		r.TargetTTFTMS = 10
		if _, err := collect(context.Background(), c, r); code(err) != "slo_exceeded" {
			t.Fatalf("elapsed-budget rejection %d: %v", i, err)
		}
	}
	if _, err := collect(context.Background(), c, input("valid with normal budget")); err != nil {
		t.Fatal("elapsed tokenization budgets poisoned a healthy worker", err)
	}
	drained(t, g, w)
}

func TestGatewayCallerCancelDuringTokenizationKeepsWorkerHealthy(t *testing.T) {
	g, c, w := setup(t, &lab.Backend{TokenizeDelay: 80 * time.Millisecond}, nil)
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Millisecond)
	defer cancel()
	_, err := collect(ctx, c, input("cancel tokenization"))
	if !errors.Is(err, context.DeadlineExceeded) {
		t.Fatal(err)
	}
	eventually(t, func() bool { return len(g.Snapshot().Outcomes) > 0 })
	if !g.Snapshot().Workers[0].Available {
		t.Fatal("caller cancellation invalidated a healthy worker")
	}
	if _, err := collect(context.Background(), c, input("still healthy")); err != nil {
		t.Fatal("healthy worker not usable after caller cancellation", err)
	}
	drained(t, g, w)
}
func TestGatewayTotalBudgetAppliesAfterFirstText(t *testing.T) {
	b := &lab.Backend{Gap: time.Second}
	g, c, w := setup(t, b, func(cfg *gateway.Config) { cfg.MaxRequestDuration = 150 * time.Millisecond })
	events, err := collect(context.Background(), c, input("first then stall"))
	if !errors.Is(err, context.DeadlineExceeded) {
		t.Fatal(err)
	}
	if len(events) < 2 || events[1].Type != "chunk" {
		t.Fatal("fixture never produced first text", events)
	}
	eventually(t, func() bool { return b.Canceled.Load() == 1 })
	drained(t, g, w)
}
func TestGatewayFirstTextTargetDoesNotLimitWholeStream(t *testing.T) {
	g, c, w := setup(t, &lab.Backend{Gap: 100 * time.Millisecond}, nil)
	request := input("first then continue")
	request.TargetTTFTMS = 100
	events, err := collect(context.Background(), c, request)
	if err != nil {
		t.Fatal(err)
	}
	summary := events[len(events)-1].Summary
	if summary == nil || !summary.TTFTMet || summary.Elapsed < 200*time.Millisecond {
		t.Fatal(summary)
	}
	drained(t, g, w)
}
