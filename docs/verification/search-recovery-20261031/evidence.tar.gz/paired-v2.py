import argparse,json,os,sys,threading,time,subprocess
from pathlib import Path
ROOT=Path('/Users/kana/Projects/campustrace')
TASK=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts/performance'))
import lab
from diagnose import Diagnosis

def competitors():
    rows=[]
    raw=subprocess.check_output(['ps','-axo','pid=,ppid=,comm=,args='],text=True)
    for line in raw.splitlines():
        bits=line.split(None,3)
        if len(bits)<4: continue
        pid,ppid,command,args=bits
        name=Path(command).name
        subcommand=args.split()[1] if len(args.split())>1 else ''
        if name in ('compile','link','vet','k6') or name=='go' and subcommand in ('test','build','vet','run','tool'):
            rows.append({'pid':int(pid),'ppid':int(ppid),'executable':name,'subcommand':subcommand if name=='go' else ''})
    return rows

def quiet_host(seconds):
    quiet=None
    while quiet is None or time.monotonic()-quiet<seconds:
        quiet=None if competitors() else (quiet or time.monotonic())
        time.sleep(1)

class ObservedDiagnosis(Diagnosis):
    def load(self,label,mode,seconds=None):
        for attempt in range(3):
            quiet_host(10 if attempt==0 else 60)
            stop=threading.Event();observed={};start=time.time_ns()
            def observe():
                while not stop.is_set():
                    for row in competitors(): observed[row['pid']]=row
                    stop.wait(.5)
            observer=threading.Thread(target=observe);observer.start()
            try:
                summary=super().load(label,mode,seconds)
            finally:
                stop.set();observer.join()
            summary.update(started_ns=start,ended_ns=time.time_ns(),observed_host_competitors=list(observed.values()))
            (self.evidence/label/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
            self.save()
            # Never retry an application/load-contract error, even with host competition.
            if summary['exit_code']!=0 or not observed:
                return summary
            excluded=f'excluded-host-{attempt+1}-{label}'
            (self.evidence/label).rename(self.evidence/excluded)
            self.report.setdefault('excluded_host_attempts',[]).append({'directory':excluded,'label':label,'summary':summary})
            self.report['phases'].pop(label)
            self.save()
            print('Preserved host-interfered attempt: '+excluded,flush=True)
        raise RuntimeError('Host competition repeated three times; no timing accepted for this phase')

state={'status':'waiting-for-quiet-host','scales':[]}
def save(): (TASK/'state.json').write_text(json.dumps(state,indent=2)+'\n')
save()
quiet=None
while quiet is None or time.monotonic()-quiet<60:
    busy=competitors()
    quiet=None if busy else (quiet or time.monotonic())
    time.sleep(2)
lab.LIMITS={**lab.LIMITS,'mysql':(1,'1536m')}
for n in (1000,10000):
    state.update(status='running',current_scale=n);save()
    args=argparse.Namespace(source=TASK/'baseline',candidate=TASK/'candidate',jobs=n-1,seconds=40,rate=12,
        output=TASK/f'accepted-{n}',diagnostics=False,revision=None,write_rate=1,max_vus=16)
    try:
        ObservedDiagnosis(args).execute()
    except BaseException as error:
        state.update(status='failed',failure=str(error));save();raise
    state['scales'].append(n);save()
state.update(status='complete');save()
