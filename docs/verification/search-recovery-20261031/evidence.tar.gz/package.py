from pathlib import Path
import csv,hashlib,json,shutil,sys,tarfile
TASK=Path(__file__).resolve().parent
REPO=Path('/Users/kana/Projects/campustrace')
OUT=REPO/'docs/verification/search-recovery-20261031'
sys.path.insert(0,str(TASK/'harness'))
from diagnosis_report import summarize
from lab import digest

def v(s,k):return s['metrics'].get(k,{}).get('values',{})
def write(name,data): (OUT/name).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
assert json.loads((TASK/'state.json').read_text())['status']=='complete'
source=json.loads((TASK/'source-verification.json').read_text())
rows=[];aggregates=[];reports={};totals={'baseline':{'attempts':0,'failures':0,'dropped':0},'candidate':{'attempts':0,'failures':0,'dropped':0}}
for n in (1000,10000):
 d=json.loads((TASK/f'final-{n}'/'report.json').read_text());reports[n]=d
 assert d['status']=='recorded' and d['dataset_and_generation_preserved'] and len(d['phases'])==8
 assert d['seeded_jobs']==n and d['order']==['baseline','candidate','candidate','baseline']
 assert d['source']['runtime_sha256']==source['baseline_fingerprint']
 assert d['candidate_source']['runtime_sha256']==source['candidate_fingerprint']
 for r in summarize(d):r['jobs']=n;rows.append(r)
 for label,s in d['phases'].items():
  assert not s['observed_host_competitors']
  variant='candidate' if 'candidate' in label else 'baseline'
  r={'jobs':n,'run':label,'mode':s['mode'],'variant':variant,'attempts':v(s,'attempts')['count'],
     'failures':v(s,'failures')['count'],'dropped':v(s,'dropped_iterations').get('count',0),'p50_ms':v(s,'latency_ms')['med'],
     'p95_ms':v(s,'latency_ms')['p(95)'],'p99_ms':v(s,'latency_ms')['p(99)'],'k6_exit':s['exit_code'],
     'probe_fallbacks':s['metrics_after'].get('campustrace_search_query_probe_fallback_total',0)-s['metrics_before'].get('campustrace_search_query_probe_fallback_total',0)}
  if variant=='candidate':assert r['failures']==r['dropped']==r['k6_exit']==0
  for k in ('attempts','failures','dropped'):totals[variant][k]+=r[k]
  aggregates.append(r)
 assert d['validation']['candidate_runs']==4 and d['validation']['candidate_passed']
 for e in d.get('excluded_host_attempts',[]):assert e['summary']['exit_code']==0
assert reports[1000]['environment']==reports[10000]['environment']
assert reports[1000]['workload']['load_script_sha256']==reports[10000]['workload']['load_script_sha256']
# Fixed broad engineering guard, not a statistical significance test.
fulltext=[]
for n in (1000,10000):
 b=[r['p95_ms'] for r in aggregates if r['jobs']==n and r['variant']=='baseline' and r['mode']=='fulltext']
 c=[r['p95_ms'] for r in aggregates if r['jobs']==n and r['variant']=='candidate' and r['mode']=='fulltext']
 fulltext.append({'jobs':n,'baseline_p95_max_ms':max(b),'candidate_p95_max_ms':max(c),'threshold_ms':max(b)*1.5+25,'passed':max(c)<=max(b)*1.5+25})
assert all(r['passed'] for r in fulltext)
tr=[json.loads(l) for l in (TASK/'paired-1000/traces.jsonl').read_text().splitlines()]
nodes={(r['trace_id'],r['span_id']):r for r in tr};traces=[]
for r in tr:
 if r['name']!='search.query.probe':continue
 parent=nodes[(r['trace_id'],r['parent_id'])]
 assert parent['name']=='search.core'
 traces.append({'probe':r,'foreground_core':parent,'probe_outlives_foreground':r['start_ns']+r['duration_ms']*1e6>parent['start_ns']+parent['duration_ms']*1e6})
assert traces and all(r['probe_outlives_foreground'] for r in traces)
result={'status':'PASS','kind':'single-host-synthetic-recovery-probe-comparison','totals':totals,'aggregates':aggregates,'rows':rows,
 'fulltext_engineering_guard':fulltext,'source':source,'excluded_host_attempts':{str(n):len(d.get('excluded_host_attempts',[])) for n,d in reports.items()},
 'entire_initial_timing_attempt_excluded':True,'diagnostic_probe_count':len(traces),
 'limits':['Not production capacity or SLA.','Per-run quantiles; no pooled quantiles or statistical significance claim.',
 'Raw workload.write_rate=1 is an inherited fixture field; the archived diagnosis k6 script is read-only and has no writer scenario.']}
write('results.json',result);write('recovery-traces.json',traces)
with (OUT/'results.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
for name in ('optimization.patch','source-verification.json','source-file-sha256.json'):
 shutil.copy2(TASK/name,OUT/name)
# Source archive excludes neither baseline failures nor unrelated original source.
with tarfile.open(OUT/'source-snapshots.tar.gz','w:gz') as tar:
 for name in ('baseline','candidate'):tar.add(TASK/name,arcname=name)
raw=[]
for name in ('paired-1000','accepted-1000','final-1000','final-10000','harness'):
 raw.extend(p for p in (TASK/name).rglob('*') if p.is_file())
raw.extend(p for p in TASK.iterdir() if p.is_file() and p.name not in ('source-file-sha256.json',))
raw=sorted(set(raw));hashes={p.relative_to(TASK).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in raw}
write('raw-file-sha256.json',hashes)
with tarfile.open(OUT/'evidence.tar.gz','w:gz') as tar:
 for p in raw:tar.add(p,arcname=p.relative_to(TASK).as_posix())
print(json.dumps({'totals':totals,'raw_files':len(hashes),'rows':len(rows),'probe_spans':len(traces)},indent=2))
