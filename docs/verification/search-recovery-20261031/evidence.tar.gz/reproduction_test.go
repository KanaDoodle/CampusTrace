package searchapi

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

// Hold the actual query response behind a barrier: recovery must let the
// foreground caller fall back before the remote query has completed.
func TestQueryRecoveryDoesNotWaitForBlockedProbe(t *testing.T) {
	entered, release := make(chan struct{}), make(chan struct{})
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		io.Copy(io.Discard, r.Body)
		if calls.Add(1) == 1 {
			w.WriteHeader(http.StatusServiceUnavailable)
			return
		}
		close(entered)
		select {
		case <-release:
			json.NewEncoder(w).Encode(Result{Protocol: Protocol, Generation: "generation"})
		case <-r.Context().Done():
		}
	}))
	defer server.Close()
	defer close(release)
	client, err := NewClient(server.URL, strings.Repeat("q", 32), "")
	if err != nil {
		t.Fatal(err)
	}
	policy := DefaultQueryPolicy()
	policy.FailureThreshold = 1
	if err = client.ConfigureQueries(policy, nil); err != nil {
		t.Fatal(err)
	}
	var now atomic.Int64
	now.Store(time.Now().UnixNano())
	client.guard.now = func() time.Time { return time.Unix(0, now.Load()) }
	q := Query{Generation: "generation", Limit: 10}
	if _, err = client.Query(context.Background(), q); !errors.Is(err, ErrUnavailable) {
		t.Fatal(err)
	}
	now.Add(int64(policy.OpenFor))
	done := make(chan error, 1)
	go func() { _, err := client.Query(context.Background(), q); done <- err }()
	select {
	case <-entered:
	case <-time.After(time.Second):
		t.Fatal("recovery query did not start")
	}
	select {
	case err = <-done:
		if !errors.Is(err, ErrCircuitOpen) {
			t.Fatal("recovery caller must use authoritative fallback", err)
		}
	case <-time.After(75 * time.Millisecond):
		t.Fatal("recovery caller is still waiting for the remote probe")
	}
}
