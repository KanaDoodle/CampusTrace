import argparse,json,os,sys,threading,time,subprocess
from pathlib import Path
ROOT=Path('/Users/kana/Projects/campustrace')
TASK=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts/performance'))
import lab
from diagnose import Diagnosis

def competitors():
    rows=[]
    raw=subprocess.check_output(['ps','-axo','pid=,ppid=,comm=,args='],text=True)
    for line in raw.splitlines():
        bits=line.split(None,3)
        if len(bits)<4: continue
        pid,ppid,command,args=bits
        name=Path(command).name
        if name in ('go','compile','link','vet','k6'):
            rows.append({'pid':int(pid),'ppid':int(ppid),'executable':name})
    return rows

class ObservedDiagnosis(Diagnosis):
    def load(self,label,mode,seconds=None):
        stop=threading.Event();observed={};start=time.time_ns()
        def observe():
            while not stop.is_set():
                for row in competitors(): observed[row['pid']]=row
                stop.wait(.5)
        observer=threading.Thread(target=observe);observer.start()
        try:
            summary=super().load(label,mode,seconds)
        finally:
            stop.set();observer.join()
        summary.update(started_ns=start,ended_ns=time.time_ns(),observed_host_competitors=list(observed.values()))
        (self.evidence/label/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
        self.save()
        if observed: raise RuntimeError('Native host competition observed; preserve this attempt without promoting it')
        return summary

state={'status':'waiting-for-quiet-host','scales':[]}
def save(): (TASK/'state.json').write_text(json.dumps(state,indent=2)+'\n')
save()
quiet=None
while quiet is None or time.monotonic()-quiet<60:
    busy=competitors()
    quiet=None if busy else (quiet or time.monotonic())
    time.sleep(2)
lab.LIMITS={**lab.LIMITS,'mysql':(1,'1536m')}
for n in (1000,10000):
    state.update(status='running',current_scale=n);save()
    args=argparse.Namespace(source=TASK/'baseline',candidate=TASK/'candidate',jobs=n-1,seconds=40,rate=12,
        output=TASK/f'paired-{n}',diagnostics=n==1000,revision=None,write_rate=1,max_vus=16)
    try:
        ObservedDiagnosis(args).execute()
    except BaseException as error:
        state.update(status='failed',failure=str(error));save();raise
    state['scales'].append(n);save()
state.update(status='complete');save()
